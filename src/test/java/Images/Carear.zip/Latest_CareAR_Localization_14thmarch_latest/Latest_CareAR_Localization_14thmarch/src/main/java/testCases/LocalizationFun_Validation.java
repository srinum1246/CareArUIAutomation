package testCases;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.security.KeyException;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;
import libraryFunctions.JSONRead;
import libraryFunctions.WebFunctions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import webElements.*;

public class LocalizationFun_Validation {

    static String URL,uname,passwd,langname=null;
    static String jsonPath =null;
    static String choice=null;
    static String s = null;
    static int choicecount=0;
    public static WebDriverWait driverWait;
    public static String localizationVocabsPath = "./src//main//java//localizationVocabs//";
    public static String searchEmail;
    public static String searchKPIQuestion;
    public static ExtentReports extent;
    public static ExtentTest test;
    public static void main(String args[]) throws Exception {

        String paths[]= {"./src//main//java//localizationVocabs//Frenchnew.json", "./src//main//java//localizationVocabs//Germannew.json","./src//main//java//localizationVocabs//Italiannew.json","./src//main//java//localizationVocabs//Portuguesenew.json","./src//main//java//localizationVocabs//Spanishnew.json","./src//main//java//localizationVocabs//Indonesiannew.json","./src//main//java//localizationVocabs//Japanesenew.json","./src//main//java//localizationVocabs//Malaynew.json","./src//main//java//localizationVocabs//Chinesenew.json" };
        //String i=1;
        Scanner scanner = new Scanner(System.in);
        //  prompt for the URL
        System.out.print("Enter your URL: ");
        // get their input as a String
        URL = scanner.next();
        Scanner un = new Scanner(System.in);
        System.out.print("Enter your username: ");
        uname = un.next();
        Scanner pwd = new Scanner(System.in);
        System.out.print("Enter your password: ");
        passwd = pwd.next();
        Scanner lname = new Scanner(System.in);
        System.out.print("Enter your language: ");
        langname = lname.next();
        Scanner opt = new Scanner(System.in);
        System.out.print("Enter your Option 1 to 9: ");
        s = opt.next();
        WebDriverManager.chromedriver().setup();
        ChromeOptions options= new ChromeOptions();
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        //options.addArguments("--headless");
        options.addArguments("--disable-gpu");
        options.addArguments("--allow-insecure-localhost");
        String reportPath = System.getProperty("user.dir")+"\\reports\\reports.html";
        ExtentSparkReporter es = new ExtentSparkReporter(reportPath);
        es.config().setDocumentTitle("CareAR");
        es.config().setReportName("Localization");
        extent = new ExtentReports();
        extent.attachReporter(es);
        //extent.setSystemInfo("Tester", "XYZ");
        //String all = null;
        if(s.equals("0"))
        {
            int i=1;
            while(i<=9){

                jsonPath = paths[i - 1];
                choicecount = i;

                //System.setProperty("webdriver.chrome.driver","./src//main//java//configuration//chromedriver.exe");
                WebDriver driver = new ChromeDriver(options);
                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                validateLocalizationall(driver, i,jsonPath);
                System.out.println("\n\n\n\n" + "-X-X-X-X-X-X-X-X-X-X-X-X-X-X");
                i++;
                Thread.sleep(5000);

            }
        }

        //while(i<=9) {

        // if(i<=1) {
        else{


            int i = Integer.parseInt(s);
            jsonPath = paths[i - 1];
            choice = langname;

            //System.setProperty("webdriver.chrome.driver","./src//main//java//configuration//chromedriver.exe");
            WebDriver driver = new ChromeDriver(options);
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            driver.manage().window().maximize();
            Thread.sleep(2000);
            validateLocalization(driver, langname, jsonPath);
            System.out.println("\n\n\n\n" + "-X-X-X-X-X-X-X-X-X-X-X-X-X-X");
            //i++;
            Thread.sleep(5000);
			/*  }
			  else
			  {
				  break;
			  }*/
            // }


            //i=1;
            /*
             * while(i<=1) { jsonPath=paths[i-1]; choice=i;
             *
             * //System.setProperty("webdriver.chrome.driver",
             * "./src//main//java//configuration//chromedriver.exe"); WebDriver driver = new
             * ChromeDriver(options); driver.manage().timeouts().implicitlyWait(20,
             * TimeUnit.SECONDS);
             * UserPortalLocalisation.userPortalLocalisation(driver,jsonPath,choice);
             * System.out.println("\n\n\n\n"+"-X-X-X-X-X-X-X-X-X-X-X-X-X-X"); i++; }
             */
        }
    }
    public static void validateLocalization(WebDriver driver, String langName, String jsonPath) throws Exception {

        switch (langName.toLowerCase()) {
            case "english":
                test = extent.createTest("English");
                break;
            case "french":
                test = extent.createTest("French");
                break;
            case "german":
                test = extent.createTest("German");
                break;
            case "italian":
                test = extent.createTest("Italian");
                break;
            case "portugese":
                test = extent.createTest("Portugese");
                break;
            case "spanish":
                test = extent.createTest("Spanish");
                break;
            case "indonesian":
                test = extent.createTest("Indonesian");
                break;
            case "japanese":
                test = extent.createTest("Japanese");
                break;
            case "malay":
                test = extent.createTest("Malay");
                break;
            case "chinese":
                test = extent.createTest("Chinese");
                break;
        }

        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        driver.get(URL);
        Thread.sleep(3000);
        driver.manage().window().maximize();
        driverWait = new WebDriverWait(driver,60);
        driver.findElement(LoginPage.Ad_Email).sendKeys(uname);
        driver.findElement(LoginPage.Ad_Password).sendKeys(passwd);
        driver.findElement(LoginPage.Ad_LoginButton).click();
        System.out.println("clicked on login button");
        WebFunctions.explicitWait(driver, 20, "Visibility", Admin_WelcomePage.waitElement);
        Thread.sleep(8000);
        //
        // //test.pass("User logged in successfully with email id: " + uname);

        driver.findElement(Admin_WelcomePage.languageChange).click();
        Thread.sleep(2000);
        Dictionary languageLocator = new Hashtable();
        languageLocator.put("english", Admin_WelcomePage.selectEnglish);
        languageLocator.put("french", Admin_WelcomePage.selectFrench);
        languageLocator.put("german", Admin_WelcomePage.selectGerman);
        languageLocator.put("italian", Admin_WelcomePage.selectItalian);
        languageLocator.put("portugese", Admin_WelcomePage.selectPortugese);
        languageLocator.put("spanish", Admin_WelcomePage.selectSpanish);
        languageLocator.put("indonesian", Admin_WelcomePage.selectIndonesian);
        languageLocator.put("japanese", Admin_WelcomePage.selectJapanese);
        languageLocator.put("malay", Admin_WelcomePage.selectMalay);
        languageLocator.put("chinese", Admin_WelcomePage.selectChinese);

        if(languageLocator.get(choice.toLowerCase()) != null){
            driver.findElement((By) languageLocator.get(choice.toLowerCase())).click();
            System.out.println("\n\n\n Selected " + choice.toUpperCase() + " language \n\n");
        }
        else{
            throw new KeyException(choice.toUpperCase() + " language not configured");
        }

        Thread.sleep(2000);
        //
        // //test.pass(choice + " Language selected");

        driver.findElement(Admin_WelcomePage.saveLanguage).click();
        Thread.sleep(3000);

        System.out.println("\n\n");
        //System.out.println("------------INITIATING VALIDATION FOR Users, Role Management, KPIs ,Session Activity, Session Map,Dashboard Modules, My Profile , My Company---------");
        System.out.println("\n");

        FileInputStream fis=new FileInputStream(localizationVocabsPath + "NewUserModified.xlsx");
        XSSFWorkbook wb = new XSSFWorkbook(fis);
        XSSFSheet sheet = wb.getSheetAt(0);

        //USER PAGE TEST
        System.out.println("------------INITIATING VALIDATION FOR Users, KPIs ,Session Activity, Session Map,Dashboard Modules----------");
        testUsersPage(driver, sheet);

        //ROLE MANAGEMENT
        testRoleManagementPage(driver);

        //KPI PAGE TEST
        testKPIPage(driver);

        //SESSION ACTIVITY PAGE TEST
        sessionActivity(driver);

        //SESSION MAPS PAGE TEST
        sessionMaps(driver);

        //MY PROFILE PAGE
        testMyProfilePage(driver);

        //MY COMPANY PAGE
        testMyCompanyPage(driver);

        //DASHBOARD PAGE TEST
        dashboards(driver);

        System.out.println("-------USERS VALIDATION CONCLUDED-------");
        //test.info("------- CONCLUDED VALIDATION FOR Users, Role Management, KPIs ,Session Activity, Session Map,Dashboard Modules, My Profile , My Company -------");
        System.out.println("------------INITIATING VALIDATION FOR LEFT PANEL NAVIGATION BUTTONS----------");
        test.info("------------INITIATING VALIDATION FOR LEFT PANEL NAVIGATION BUTTONS----------");
        System.out.println("\n");
        String elements[] = { "users","roleManagement", "kpis", "sessionActivity", "sessionMap", "dashboard", "myProfile", "myCompany" };

        for (int i = 1; i <= 8; i++) {
            String index = Integer.toString(i);
            String path = Admin_WelcomePage.navigate1 + index + Admin_WelcomePage.navigate2;
            Thread.sleep(2000);
            String portalText = driver.findElement(By.xpath(path)).getText();

            //String paths[]= {"./src//main//java//localizationVocabs//Frenchnew.json", "./src//main//java//localizationVocabs//Germannew.json","./src//main//java//localizationVocabs//Italiannew.json","./src//main//java//localizationVocabs//Portuguesenew.json","./src//main//java//localizationVocabs//Spanishnew.json","./src//main//java//localizationVocabs//Indonesiannew.json","./src//main//java//localizationVocabs//Japanesenew.json","./src//main//java//localizationVocabs//Malaynew.json","./src//main//java//localizationVocabs//Chinesenew.json" };
            //String jsonPath1 = paths[i-1];
            String savedText = JSONRead.readJSON(jsonPath, elements[i - 1]);
            textValidation(portalText, savedText, elements[i - 1]);
        }
        //extent.flush();
        validateFooter(driver);
        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR MY COMPANY PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR MY COMPANY PAGE----------"+"\n");

        //testUsersScreen(driver);

        //myCompanyValidation(driver);

        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR USERS PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR USERS PAGE----------"+"\n");
        testUsersScreen(driver);

        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR KPI PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR KPI PAGE----------"+"\n");
        validateKPI(driver);

        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR SESSION ACTIVITY PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR SESSION ACTIVITY PAGE----------"+"\n");
        sessionActivityValidation(driver);

        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR SESSION MAP PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR SESSION MAP PAGE----------"+"\n");
        sessionMapValiation(driver);


        //System.out.println("\n\n"+"------------INITIATING VALIDATION FOR DASHBOARD ITEMS----------"+"\n");
        //test.info("\n\n"+"------------INITIATING VALIDATION FOR DASHBOARD ITEMS----------"+"\n");
        //LocalizationValidation.dashboardValidation(driver);

        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR MY PROFILE PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR MY PROFILE PAGE----------"+"\n");
        myProfileValidation(driver);

        System.out.println("-------VALIDATION CONCLUDED-------");
        test.info("-------VALIDATION CONCLUDED-------");

        driver.close();
        //if (langCount == j) {
        extent.flush();
        //}
    }


    public static void testUsersPage(WebDriver driver, XSSFSheet sheet) throws Exception {
        //test.info("------------------------- USER PAGE VALIDATION INITIATED -------------------------");
        testNewUserCreation(driver, sheet);
        //testRowsPerPageForUserData(driver);
        testUserEdit(driver);
        //test.info("------------- Test: Search User And Disable, Enable, Delete Functionalities -------------");
        testSearchUserAndDisable(driver);
        testSearchUserAndEnable(driver);
        testSearchUserAndDelete(driver);
        //test.info("------------- Test: User Disable, Enable, Delete Functionalities -------------");
        testUserDisable(driver);
        testUserEnable(driver);
        testUserDelete(driver);
        //test.info("------------- USER PAGE VALIDATION CONCLUDED -------------");
        extent.flush();
    }


    public static void testKPIPage(WebDriver driver) throws Exception {
        //test.info("------------------------- KPI PAGE VALIDATION INITIATED -------------------------");
        testNewKPICreation(driver);
        testRowsPerPageForKPIData(driver);
        testFilterKPIDataByUserType(driver);
        testKPIEdit(driver);
        //test.info("------------- Test: Search KPI And Disable, Enable, Delete Functionalities -------------");
        testSearchKPIAndDisable(driver);
        testSearchKPIAndEnable(driver);
        testSearchKPIAndDelete(driver);
        //test.info("------------- Test: KPI Disable, Enable, Delete Functionalities -------------");
        testKPIDisable(driver);
        testKPIEnable(driver);
        testKPIDelete(driver);
        //test.info("------------- KPI PAGE VALIDATION CONCLUDED-------------");
        extent.flush();
    }


    public static void testRoleManagementPage(WebDriver driver) throws Exception{

        //test.info("------------------------- ROLE MANAGEMENT PAGE VALIDATION INITIATED-------------------------");
        testRoleManagementCheckAndUncheck(driver);
        //test.info("------------------------- ROLE MANAGEMENT PAGE VALIDATION CONCLUDED-------------------------");
        extent.flush();
    }


    public static void testMyProfilePage(WebDriver driver) throws Exception{

        //test.info("------------------------- MY PROFILE PAGE VALIDATION INITIATED-------------------------");
        testMyProfilePictureUpload(driver);
        testMyProfileInfo(driver);
        //test.info("------------------------- MY PROFILE PAGE VALIDATION CONCLUDED-------------------------");
        extent.flush();
    }


    public static void testMyCompanyPage(WebDriver driver) throws Exception{

        //test.info("------------------------- MY COMPANY PAGE VALIDATION INITIATED -------------------------");
        testMyCompanyLogoUpload(driver);
        testMyCompanyAddGroup(driver);
        testMyCompanyGroupEdit(driver);
        testMyCompanyGroupDelete(driver);
        testMyCompanyGroupImportExport(driver);
        testMyCompanySignalingSection(driver);
        testMyCompanyJoinControlsSection(driver);
        //test.info("------------------------- MY COMPANY PAGE VALIDATION CONCLUDED -------------------------");
        extent.flush();
    }


    public static void testNewUserCreation(WebDriver driver, XSSFSheet sheet) throws Exception {
        String jsonTranslation="";
        //test.info("-------------------- Test:  New User Creation --------------------");
        driver.findElement(UsersPage.users).click();
        Thread.sleep(2000);
        String frstLabel= driver.findElement(By.xpath("//*[@class=\'add-user\']//h4")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "addNewUser");
        textValidation(frstLabel, jsonTranslation, "addNewUser");
        String sndLabel=driver.findElement(By.xpath("/html/body/div/div[2]/div/main/div/div[2]/div/div/div/div/div[2]/div/div[2]/div[1]/button")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "exportAll");
        textValidation(sndLabel, jsonTranslation, "exportAll");
        String thrdLabel=driver.findElement(By.id("bulkEditBtn")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "bulkEdit");
        textValidation(thrdLabel, jsonTranslation, "bulkEdit");
        String headLabel1=driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[3]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "name");
        textValidation(headLabel1, jsonTranslation, "name");
        String headLabel2=driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[4]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "emailAddress");
        textValidation(headLabel2, jsonTranslation, "emailAddress");
        String headLabel3=driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[5]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "role");
        textValidation(headLabel3, jsonTranslation, "role");
        String headLable4=driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[6]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "group");
        textValidation(headLable4, jsonTranslation, "group");
        String headLable5=driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[7]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "status");
        textValidation(headLable5, jsonTranslation, "status");
        String headLable6=driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[8]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "primaryPhoneNumber");
        textValidation(headLable6, jsonTranslation, "primaryPhoneNumber");
        String headLable7=driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[9]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "secondaryPhoneNumber");
        textValidation(headLable7, jsonTranslation, "secondaryPhoneNumber");
        String headLable8=driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[10]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "joinedDate");
        textValidation(headLable8, jsonTranslation, "joinedDate");
        String headLable9=driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[11]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "lastLoggedIn");
        textValidation(headLable9, jsonTranslation, "lastLoggedIn");
        String headLablel10=driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[12]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "lastLoggedInPortal");
        textValidation(headLablel10, jsonTranslation, "lastLoggedInPortal");
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        Random random = new Random();
        String reportMsg;
        for(int row=1; row<sheet.getLastRowNum() + 1; row++)
        {
            String email = "test" + random.nextInt(9999999) + sheet.getRow(row).getCell(0).getStringCellValue().trim();
            String firstName = sheet.getRow(row).getCell(1).getStringCellValue().trim();
            String lastName = sheet.getRow(row).getCell(2).getStringCellValue().trim();
            String phoneNumber = sheet.getRow(row).getCell(3).getStringCellValue().trim();
            String secondaryNumber = sheet.getRow(row).getCell(4).getStringCellValue().trim();
            String description = sheet.getRow(row).getCell(5).getStringCellValue().trim();
            String group = sheet.getRow(row).getCell(6).getStringCellValue().trim();

            driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.addNewUserButton)).click();
            driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.emailInput)).sendKeys(email);
            driver.findElement(UsersPage.firstNameInput).sendKeys(firstName);
            driver.findElement(UsersPage.lastNameInput).sendKeys(lastName);
            driver.findElement(UsersPage.phoneNumberInput).sendKeys(phoneNumber);
            driver.findElement(UsersPage.secondaryNumberInput).sendKeys(secondaryNumber);
            driver.findElement(UsersPage.descriptionInput).sendKeys(description);
            driver.findElement(UsersPage.groupInput).sendKeys(group);
            driver.findElement(UsersPage.createButton).click();
            driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
            Thread.sleep(2000);
            List<WebElement> emailError = driver.findElements(UsersPage.emailError);
            List<WebElement> alertTitle = driver.findElements(UsersPage.alertTitle);
            List<WebElement> errors = driver.findElements(UsersPage.errorMsg);
            if (emailError.size() >0 && emailError.get(0).isDisplayed()) {
                //reportMsg = String.format("User with first name '%s' is unable to add due to invalid email format", firstName);
                driver.findElement(UsersPage.cancelButton).click();
            }
            else if (alertTitle.size() > 0) {
                String title = alertTitle.get(0).getText().trim();
                driver.findElement(UsersPage.alertOkButton).click();
                Thread.sleep(1000);
                driver.findElement(UsersPage.cancelButton).click();
                //reportMsg = String.format("User with email ID '%s' is unable to add due to %s", firstName, title.toLowerCase());
            }
            else if(errors.size() > 0 && errors.get(0).isDisplayed()){
                //reportMsg = "Unable to add new user due to invalid data";
                driver.findElement(UsersPage.cancelButton).click();
            }
            else{
                searchEmail = email;
                //reportMsg = String.format("User with email ID '%s' is added successfully", email);
            }
            driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));

            //test.pass(reportMsg);
        }

        //Test User group with invalid data
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driver.findElement(UsersPage.addNewUserButton).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.groupInput)).click();
        driver.findElement(UsersPage.groupInput).sendKeys("InvalidGroup");
        String msg = driver.findElement(By.cssSelector("div[role='list'].react-dropdown-select-dropdown")).getText().trim();
        //System.out.println("new user: "+msg);
        //Assert.assertEquals("No data", msg);

        //test.pass("Entered 'InvalidGroup' group is not available for selection");
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));

    }


    public static void testSearchUserAndDisable(WebDriver driver) throws Exception {
        String jsonTranslation="";
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.searchUserInput)).click();
        driver.findElement(UsersPage.searchUserInput).clear();
        driver.findElement(UsersPage.searchUserInput).sendKeys(searchEmail);
        driver.findElement(By.id("disableUser_0")).click();
        String msg=driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertMessage)).getText().replace('?',' ').trim();
        jsonTranslation=JSONRead.readJSON(jsonPath, "confirmDisableUser").replace("?"," ").trim();
        textValidation(msg, jsonTranslation, "confirmDisableUser");
        Thread.sleep(2000);
        //System.out.println("user enable: "+msg);

        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertOkButton)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();

        //test.pass(String.format("User '%s' got disabled successfully by search", searchEmail));
        Thread.sleep(1000);
    }


    public static void testSearchUserAndEnable(WebDriver driver) throws Exception {
        String jsonTranslation="";
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.searchUserInput)).click();
        driver.findElement(UsersPage.searchUserInput).clear();
        driver.findElement(UsersPage.searchUserInput).sendKeys(searchEmail);
        driver.findElement(By.id("enableUser_0")).click();
        String msg=driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertMessage)).getText().replace("?"," ").trim();;
        jsonTranslation=JSONRead.readJSON(jsonPath, "confirmEnableUser").replace("?"," ").trim();
        textValidation(msg, jsonTranslation, "confirmEnableUser");
        Thread.sleep(2000);
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertOkButton)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();

        //test.pass(String.format("User '%s' got disabled successfully by search", searchEmail));
        Thread.sleep(1000);
    }


    public static void testSearchUserAndDelete(WebDriver driver) throws Exception{
        String jsonTranslation="";
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.searchUserInput)).click();
        driver.findElement(UsersPage.searchUserInput).clear();
        driver.findElement(UsersPage.searchUserInput).sendKeys(searchEmail);
        driver.findElement(By.id("deleteUser_0")).click();
        //String msg=driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertMessage)).getText();
        String msg=driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertMessage)).getText().replace("?"," ").trim();;
        jsonTranslation=JSONRead.readJSON(jsonPath, "confirmDeleteUser").replace("?"," ").trim();
        textValidation(msg, jsonTranslation, "confirmDeleteUser");
        Thread.sleep(2000);
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertOkButton)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();

        //test.pass(String.format("User '%s' got deleted successfully by search", searchEmail));
        Thread.sleep(1000);
    }


    public static void testUserDisable(WebDriver driver) throws Exception {
        String jsonTranslation="";
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.users)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#userInfo i[id^='disableUser']"))).click();
        String message = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertMessage)).getText();
       // System.out.print("testUserDisable: "+message);
        driver.findElement(UsersPage.alertOkButton).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        jsonTranslation=JSONRead.readJSON(jsonPath, "confirmDisableUser");
        textValidation(message, jsonTranslation, "confirmDisableUser");
        Thread.sleep(2000);
        //
        // //test.pass(message[1].replace('?', ' ').trim() + " User got disabled successfully");
    }


    public static void testUserEnable(WebDriver driver) throws Exception {
        String jsonTranslation="";
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#userInfo i[id^='enableUser']"))).click();
        String uenabl = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertMessage)).getText();
        //System.out.println("testUserEnable"+uenabl);
        driver.findElement(UsersPage.alertOkButton).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        jsonTranslation=JSONRead.readJSON(jsonPath, "confirmEnableUser");
        textValidation(uenabl, jsonTranslation, "confirmEnableUser");
        Thread.sleep(2000);
        //
        // //test.pass(message[1].replace('?', ' ').trim() + " User got enabled successfully");
    }


    public static void testUserDelete(WebDriver driver) throws Exception{
        String jsonTranslation = "";
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#userInfo i[id^='deleteUser']"))).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.notificationMsg));
        String userdel = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertMessage)).getText();
        driver.findElement(UsersPage.alertOkButton).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        jsonTranslation=JSONRead.readJSON(jsonPath, "confirmDeleteUser");
        textValidation(userdel, jsonTranslation, "confirmDeleteUser");
        Thread.sleep(2000);
        //
        // //test.pass(userdel.replace('?', ' ').trim() + " User got deleted successfully");
    }


    public static void testRowsPerPageForUserData(WebDriver driver) throws Exception{
        //test.info("------------- Test: Rows Per Page Selection Functionality For Users Data -------------");
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        String pages[] = {"10", "25", "50", "100"};
        for(String page: pages){
            Select rowPage = new Select(driver.findElement(By.xpath("//*[@class='form-control dropDown-select']")));
            rowPage.selectByVisibleText(page);
            Thread.sleep(2000);
            List<WebElement> totalUsers = driver.findElements(UsersPage.userDataRows);
            int expectedRows = Integer.valueOf(page);
            //Assert.assertEquals(expectedRows, totalUsers.size());
            //
            // //test.pass("Rows per page " + page + " is selected and actual user data rows are " + page);
        }
        driver.findElement(UsersPage.importButton).isDisplayed();
        driver.findElement(UsersPage.bulkEdit).isDisplayed();
        Thread.sleep(2000);
    }


    public static void testUserEdit(WebDriver driver) throws Exception{
        //test.info("------------- Test : User Edit Functionality -------------");
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.searchUserInput)).clear();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.searchUserInput)).sendKeys(searchEmail);
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.editUser)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        Thread.sleep(2000);
        String description = "Test Description " + new Random().nextInt(55555);
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.descriptionInput)).click();
        Thread.sleep(2000);
        driver.findElement(UsersPage.descriptionInput).clear();
        driver.findElement(UsersPage.descriptionInput).sendKeys(description);
        driver.findElement(UsersPage.createButton).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();

        //test.pass(String.format("Updated '%s' user description as '%s'", searchEmail, description));
    }


    public static void testUserSearchAndEdit(WebDriver driver) throws Exception{

        //test.info("------------- TEST: USER SEARCH, EDIT AND ROLE CHANGE FUNCTIONALITIES -------------");

        String email = "test2022portal@gmail.com";
        String password = "Password1";

        driver.findElement(UsersPage.users).click();
        changeUserRole(driver, email, "Normal");
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.userLogout)).click();
        driver.findElement(LoginPage.Ad_Email).sendKeys(email);
        driver.findElement(LoginPage.Ad_Password).sendKeys(password);
        driver.findElement(LoginPage.Ad_LoginButton).click();
        String errorMsg = driver.findElement(By.cssSelector("p.errorMessage")).getText().trim();
        //Assert.assertEquals("User is not a Tenant Admin", errorMsg);

        //test.pass(email + " is Normal user since can not be logged in admin page");
        driver.get("https://carear-development.web.app/#/admin/login");
        driver.findElement(LoginPage.Ad_Email).sendKeys("kumarvikramg16@gmail.com");
        driver.findElement(LoginPage.Ad_Password).sendKeys("@Pandu123");
        driver.findElement(LoginPage.Ad_LoginButton).click();
        driver.findElement(UsersPage.users).click();
        changeUserRole(driver, email, "Administrator");
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.userLogout)).click();
        driver.findElement(LoginPage.Ad_Email).sendKeys(email);
        driver.findElement(LoginPage.Ad_Password).sendKeys(password);
        driver.findElement(LoginPage.Ad_LoginButton).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.userLogout)).click();

        //test.pass(email + " user successfully logged as Administrator");
        driver.findElement(LoginPage.Ad_Email).sendKeys("kumarvikramg16@gmail.com");
        driver.findElement(LoginPage.Ad_Password).sendKeys("@Pandu123");
        driver.findElement(LoginPage.Ad_LoginButton).click();
    }


    public static  void changeUserRole(WebDriver driver, String user, String role) throws Exception{

        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.users)).click();
        Thread.sleep(3000);
        driver.findElement(UsersPage.searchInput).sendKeys(user);
        Thread.sleep(2000);
        driver.findElement(UsersPage.editUser).click();
        Thread.sleep(3000);
        Select roleElement = new Select(driver.findElement(UsersPage.userRole));
        String currentRole = roleElement.getFirstSelectedOption().getText();
        roleElement.selectByVisibleText(role);
        if(currentRole.equals(user)) {
            //test.info(user + " User already in " + role);
        }
        else{
            driver.findElement(UsersPage.updateUser).click();

            //test.pass(user + " User successfully switched from " + currentRole + " to " + role);
        }
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.notificationMsg));
        Thread.sleep(9000);
    }


    public static void testNewKPICreation(WebDriver driver) throws Exception{
        String jsonTranslation="";
        //test.info("------------- Test: New KPI Creation Functionality -------------");

        String[] required = {"Mandatory", "Optional", "Mandatory", "Optional"};
        String[] type = {"Rating", "Dropdown", "Singleline", "Multiline"};
        String[] userType = {"Host", "Guest", "Host", "Guest"};

        driver.findElement(KPIPage.clickKPI).click();
        Thread.sleep(2000);
        String kpiTitle= driver.findElement(By.xpath("//*[@class=\"add-surveys \"]//h4")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "addNewKPI");
        textValidation(kpiTitle, jsonTranslation, "addNewKPI");
        String kpiIDLabel= driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[1]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "kpiId");
        textValidation(kpiIDLabel, jsonTranslation, "kpiId");
        String kpiLabel2= driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[3]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "userType");
        textValidation(kpiLabel2, jsonTranslation, "userType");
        String kpiLabel3= driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[4]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "kpiQuestions");
        textValidation(kpiLabel3, jsonTranslation, "kpiQuestions");
        String kpiLabel4= driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[5]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "mandatory");
        textValidation(kpiLabel4, jsonTranslation, "mandatory");
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        //Positive data
        for(int index=0; index<required.length; index++){
            driver.findElement(KPIPage.addNewKPIButton).click();
            String questionIndex = driver.findElement(By.id("inputIndex")).getAttribute("value").trim();
            String question = "Test Question " + questionIndex;
            driver.findElement(KPIPage.questionInput).sendKeys(question);
            driver.findElement(By.cssSelector("input[name='RequiredType'][value='" + required[index].toLowerCase() + "']")).click();
            driver.findElement(By.cssSelector("input[name='answerType'][value='" + type[index].toLowerCase() + "']")).click();
            if(type[index].equals("Dropdown")){
                driver.findElement(By.id("additionalData")).sendKeys("Test addition data");
            }
            driver.findElement(By.cssSelector("input[name='userType'][value='" + userType[index].toLowerCase() + "']")).click();
            driver.findElement(By.cssSelector("#surveyForm button.btn-primary")).click();
            driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
            Thread.sleep(3000);
            //String //reportMsg = String.format("New KPI question added with [Question=%s; Required=%s; Type=%s; User Type=%s]",
              //      question, required[index], type[index], userType[index]);

            //test.pass(reportMsg);
            searchKPIQuestion = question;
        }

        //Negative Data - Without question
        driver.findElement(KPIPage.addNewKPIButton).click();
        driver.findElement(By.cssSelector("input[name='answerType'][value='rating']")).click();
        driver.findElement(By.cssSelector("#surveyForm button.btn-primary")).click();
        Thread.sleep(2000);
        String errorMsg = driver.findElement(By.cssSelector("#inputQuestion + div.invalid-feedback")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "enterQuestionMsg");
        textValidation(errorMsg, jsonTranslation, "enterQuestionMsg");
        Thread.sleep(2000);

        //Negative Data - Without question
        driver.findElement(KPIPage.questionInput).sendKeys("Test Question");
        driver.findElement(By.cssSelector("input[name='answerType'][value='dropdown']")).click();
        driver.findElement(By.cssSelector("#surveyForm button.btn-primary")).click();
        Thread.sleep(2000);
        errorMsg = driver.findElement(By.cssSelector("#additionalData + div.invalid-feedback")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "enterChoice");
        textValidation(errorMsg, jsonTranslation, "enterChoice");
        driver.findElement(By.cssSelector("#surveyForm button.btn-danger")).click();
    }


    public static void testFilterKPIDataByUserType(WebDriver driver) throws Exception{
        //test.info("------------- Test: KPI Data Filter Functionality By User Types -------------");
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        String [] userTypes = {"host", "guest"};
        Select pages = new Select(driver.findElement(KPIPage.pagesDropDown));
        pages.selectByVisibleText("10");
        for(String type: userTypes){
            Select userType = new Select(driver.findElement(KPIPage.userTypeDropDown));
            userType.selectByValue(type);
            Thread.sleep(3000);
            List<WebElement> typeCellElements = driver.findElements(KPIPage.userTypeTableCell);
            for(WebElement cell: typeCellElements){
                ////Assert.assertEquals(cell.getText().trim(), type);
                String opVal = cell.getText();
                String savedText = JSONRead.readJSON(jsonPath, type);
                textValidation(opVal, savedText,type);

            }

            //test.pass(String.format("%s option selected from user type dropdown and only Host KPI data filtered", type));
        }
        //Select Host and Guest
        Select userType = new Select(driver.findElement(KPIPage.userTypeDropDown));
        userType.selectByIndex(0);
        Thread.sleep(3000);
        List<WebElement> typeCellElements = driver.findElements(KPIPage.userTypeTableCell);
        //Assert.assertTrue(typeCellElements.size() > 0);

        //test.pass("Host / Guest option selected from user type dropdown and Host and Guest KPI data listed");
    }


    public static void testKPIEdit(WebDriver driver) throws Exception{
        //test.info("------------- Test: New KPI Edit Functionality -------------");
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        String searchText = JSONRead.readJSON(jsonPath, "search");
        driver.findElement(By.cssSelector("#surveysInfo input[placeholder=" + searchText+"]")).sendKeys(searchKPIQuestion);
        Thread.sleep(2000);
        driver.findElement(By.id("editSurvey_0")).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("div.block-ui-overlay")));
        driver.findElement(KPIPage.questionInput).clear();
        String newQuestion = searchKPIQuestion + " Updated";
        driver.findElement(KPIPage.questionInput).sendKeys(newQuestion);
        driver.findElement(By.cssSelector("#surveyForm button.btn-primary")).click();
        driverWait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(KPIPage.addNewKPIButton));
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.notificationMsg));

        //test.pass(String.format("KPI question '%s' updated successfully as '%s'", searchKPIQuestion, newQuestion));
        searchKPIQuestion = newQuestion;
    }


    public static void testSearchKPIAndDisable(WebDriver driver) throws Exception{
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(KPIPage.searchKPIInput)).click();
        driver.findElement(KPIPage.searchKPIInput).clear();
        driver.findElement(KPIPage.searchKPIInput).sendKeys(searchKPIQuestion);
        driver.findElement(By.id("disableSurvey_0")).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertOkButton)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();

        //test.pass(String.format("KPI question '%s' got disabled successfully by search", searchKPIQuestion));
        Thread.sleep(1000);
    }


    public static void testSearchKPIAndEnable(WebDriver driver) throws Exception{
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(KPIPage.searchKPIInput)).click();
        driver.findElement(KPIPage.searchKPIInput).clear();
        driver.findElement(KPIPage.searchKPIInput).sendKeys(searchKPIQuestion);
        driver.findElement(By.id("enableSurvey_0")).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertOkButton)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();

        //test.pass(String.format("KPI question '%s' got enabled successfully by search", searchKPIQuestion));
        Thread.sleep(1000);
    }


    public static void testSearchKPIAndDelete(WebDriver driver) throws Exception{
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(KPIPage.searchKPIInput)).click();
        driver.findElement(KPIPage.searchKPIInput).clear();
        driver.findElement(KPIPage.searchKPIInput).sendKeys(searchKPIQuestion);
        driver.findElement(By.id("deleteSurvey_0")).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertOkButton)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();

        //test.pass(String.format("KPI question '%s' got deleted successfully by search", searchKPIQuestion));
        Thread.sleep(1000);
    }


    public static void testKPIDisable(WebDriver driver) throws Exception{
        String jsonTranslation="";
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driver.findElement(By.cssSelector("[id^='disableSurvey']")).click();
        String kpiNot = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertMessage)).getText().replace('?',' ').trim();
        driver.findElement(UsersPage.alertOkButton).click();
        jsonTranslation=JSONRead.readJSON(jsonPath, "confirmDisableSurvey").replace('?',' ').trim();
        textValidation(kpiNot, jsonTranslation, "confirmDisableSurvey");
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        //
        // //test.pass(String.format("KPI question '%s' got disabled successfully", message[1].replace('?', ' ').trim()));
    }


    public static void testKPIEnable(WebDriver driver) throws Exception{
        String jsonTranslation="";
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driver.findElement(By.cssSelector("[id^='enableSurvey_']")).click();
        String KPIen = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertMessage)).getText().replace('?',' ').trim();;
        driver.findElement(UsersPage.alertOkButton).click();
        jsonTranslation=JSONRead.readJSON(jsonPath, "confirmEnableSurvey").replace('?',' ').trim();
        textValidation(KPIen, jsonTranslation, "confirmEnableSurvey");
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        //
        // //test.pass(String.format("KPI question '%s' got enabled successfully", message[1].replace('?', ' ').trim()));
    }


    public static void testKPIDelete(WebDriver driver) throws Exception{
        String jsonTranslation="";
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driver.findElement(By.id("deleteSurvey_0")).click();
        String KPIDel = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertMessage)).getText().replace('?',' ').trim();;
        driver.findElement(UsersPage.alertOkButton).click();
        jsonTranslation=JSONRead.readJSON(jsonPath, "confirmDeleteSurvey").replace('?',' ').trim();;
        textValidation(KPIDel, jsonTranslation, "confirmDeleteSurvey");
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        //
        // //test.pass(String.format("KPI question '%s' got deleted successfully", message[1].replace('?', ' ').trim()));
    }


    public static void testRowsPerPageForKPIData(WebDriver driver) throws Exception{
        //test.info("------------- Test: Rows Per Page Selection Functionality For KPI's Data -------------");
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("div.block-ui-overlay")));
        String[] pages = {"10", "25", "50", "100"};
        for(String page: pages){
            Select rowPage = new Select(driver.findElement(By.xpath("//*[@class='form-control dropDown-select']")));
            rowPage.selectByVisibleText(page);
            Thread.sleep(2000);
            //List<WebElement> total_data = driver.findElements(KPIPage.kpiDataRows);
            //int expectedRows = Integer.parseInt(page);
            ////Assert.assertEquals(expectedRows, total_data.size());
            //
            // //test.pass("Rows per page " + page + " is selected and actual KPI data rows are " + page);
        }
    }


    public static void sessionActivity(WebDriver driver)throws Exception {
        String jsonTranslation="";
        driver.findElement(SessionActivityPage.sessionActivityNav).click();
        Thread.sleep(2000);
        String sessLable1=driver.findElement(By.xpath("//*[@id=\"sessionsCard\"]/div/div[2]/div/span/h4")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "sessionActivity");
        textValidation(sessLable1, jsonTranslation, "sessionActivity");
        //test.pass("Session Activity page open successfully");
        String sessLable2=driver.findElement(By.xpath("//*[@id=\"sessionsCard\"]/div/ul/li[1]/a/h6")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "today");
        textValidation(sessLable2, jsonTranslation, "today");
        String sessLable3=driver.findElement(By.xpath("//*[@id=\"sessionsCard\"]/div/ul/li[2]/a/h6")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "thisWeek");
        textValidation(sessLable3, jsonTranslation, "thisWeek");
        String sessLable4=driver.findElement(By.xpath("//*[@id=\"sessionsCard\"]/div/ul/li[3]/a/h6")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "thisMonth");
        textValidation(sessLable4, jsonTranslation, "thisMonth");
        String sessLable5=driver.findElement(By.xpath("//*[@id=\"sessionsCard\"]/div/ul/li[4]/a/h6")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "customDate");
        textValidation(sessLable5, jsonTranslation, "customDate");
        for(int i=1;i<=4;i++)
        {
            if(i>1)
            {
                driver.findElement(By.xpath("//*[@class='nav nav-tabs']/li["+i+"]/a")).click();
            }

            String s="(//*[@class='form-control dropDown-select'])["+2*i+"]";
            rowPerPage(driver,s);
            driver.findElement(By.xpath("(//*[@class='btn btn-primary button-leftMargin'])["+i+"]")).click();

            //test.pass("Exported All successfully");
            Thread.sleep(3000);
        }
        driver.findElement(By.xpath("(//*[@class='btn btn-primary  searchButton'])[2]")).click();

        //test.pass("Activity on Map Selected successfully");
    }


    public static void sessionMaps(WebDriver driver)throws Exception {
        String jsonTranslation="";
        driver.findElement(SessionMapPage.clickSessionMap).click();
        Thread.sleep(2000);
        String sessLable1=driver.findElement(By.xpath("//*[@id=\"sessionsCard\"]/div/div[1]/div/span/h4")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "sessionMap");
        textValidation(sessLable1, jsonTranslation, "sessionMap");
        //test.pass("Session Activity page open successfully");
        String sessLable2=driver.findElement(By.xpath("//*[@id=\"sessionsCard\"]/div/ul/li[1]/a/h6")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "today");
        textValidation(sessLable2, jsonTranslation, "today");
        String sessLable3=driver.findElement(By.xpath("//*[@id=\"sessionsCard\"]/div/ul/li[2]/a/h6")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "thisWeek");
        textValidation(sessLable3, jsonTranslation, "thisWeek");
        String sessLable4=driver.findElement(By.xpath("//*[@id=\"sessionsCard\"]/div/ul/li[3]/a/h6")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "thisMonth");
        textValidation(sessLable4, jsonTranslation, "thisMonth");
        String sessLable5=driver.findElement(By.xpath("//*[@id=\"sessionsCard\"]/div/ul/li[4]/a/h6")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "customDate");
        textValidation(sessLable5, jsonTranslation, "customDate");
        //test.pass("Session Map page open successfully");
        for(int i=1;i<=4;i++)
        {
            if(i>1)
            {
                driver.findElement(By.xpath("//*[@class='nav nav-tabs']/li["+i+"]/a")).click();
            }
            String s="(//*[@class='form-control dropDown-select'])["+i+"]";
            Thread.sleep(3000);
            Select s1=new Select(driver.findElement(By.xpath(s)));
            s1.selectByIndex(0);
        }
        driver.findElement(By.xpath("(//*[@class='fa fa-calendar'])[1]")).click();
        driver.findElement(By.xpath("//*[contains(@class,'react-datepicker__day--today')]")).click();

        //test.pass("From Date  Selected successfully");
        driver.findElement(By.xpath("(//*[@class='fa fa-calendar'])[2]")).click();
        driver.findElement(By.xpath("//*[contains(@class,'react-datepicker__day--today')]")).click();

        //test.pass("To Date  Selected successfully");
        driver.findElement(By.xpath("(//*[@class='btn btn-primary  searchButton'])[4]")).click();

        //test.pass("See Activity Selected successfully");
    }


    public static void cancelFE()throws Exception {
        Robot r = new Robot();
        r.keyPress(KeyEvent.VK_ALT);
        r.keyPress(KeyEvent.VK_SPACE);
        r.keyPress(KeyEvent.VK_C);
        r.keyRelease(KeyEvent.VK_ALT);
        r.keyRelease(KeyEvent.VK_SPACE);
        r.keyRelease(KeyEvent.VK_C);
    }


    public static void rowPerPage(WebDriver driver,String s)throws Exception {
        Select s1=new Select(driver.findElement(By.xpath(s)));
        s1.selectByVisibleText("10");

        //test.pass("10 rows per page got selected successfully");
        Thread.sleep(2000);
        s1.selectByVisibleText("25");

        //test.pass("25 rows per page got selected successfully");
        Thread.sleep(2000);
        s1.selectByVisibleText("50");
        Thread.sleep(2000);

        //test.pass("50 rows per page got selected successfully");
        s1.selectByVisibleText("100");
        Thread.sleep(2000);

        //test.pass("100 rows per page got selected successfully");

    }


    public static void dashboards(WebDriver driver)throws Exception {
        //test.info("------------------------- DASHBOARD PAGE VALIDATION INITIATED-------------------------");
        //driver.findElement(DashboardPages.dashboardClick).click();
        String portalText;
        String savedText;
        driver.findElement(DashboardPages.dashboardClick).click();
        driver.findElement(DashboardPages.dashboardUsers).click();
        WebFunctions.explicitWait(driver, 20, "Visibility", DashboardPages.totalActiveUsers);


        portalText = driver.findElement(DashboardPages.totalActiveUsers).getText();
        savedText = JSONRead.readJSON(jsonPath, "totalActiveUsers");
        textValidation(portalText, savedText, "totalActiveUsers");

        portalText = driver.findElement(DashboardPages.totalMinutesUsed).getText();
        savedText = JSONRead.readJSON(jsonPath, "totalMinutesUsed");
        textValidation(portalText, savedText, "totalMinutesUsed");

        portalText = driver.findElement(DashboardPages.top10ActiveUsers).getText().trim();
        savedText = JSONRead.readJSON(jsonPath, "topTenActiveUsers");
        textValidation(portalText, savedText.trim(), "topTenActiveUsers");

        String elements1[] = { "host","totalNumOfCalls","totalNumOfMins"};
        for (int i = 1; i <= 3; i++) {
            String index = Integer.toString(i);
            String path = DashboardPages.tableNav1 + index + DashboardPages.tableNav2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements1[i - 1]);
            textValidation(portalText, savedText, elements1[i - 1]);
        }

        driver.findElement(DashboardPages.dashboardUsage).click();
        Thread.sleep(3000);

        /*
         * portalText = driver.findElement(DashboardPages.totalActiveUsers).getText();
         * savedText = JSONRead.readJSON(jsonPath, "totalActiveUsers");
         * textValidation(portalText, savedText, "totalActiveUsers");
         */

        portalText = driver.findElement(DashboardPages.totalMinutesUsed).getText();
        savedText = JSONRead.readJSON(jsonPath, "totalMinutesUsed");
        textValidation(portalText, savedText, "totalMinutesUsed");


        driver.findElement(DashboardPages.dashboardKPI).click();
        Thread.sleep(3000);

        //host

        /*
         * portalText = driver.findElement(DashboardPages.avgRatingScoreHost).getText();
         * savedText =JSONRead.readJSON(jsonPath, "avgRatingsScore");
         * if(portalText.toUpperCase().contains(savedText.toUpperCase()))
         * textValidation(savedText,savedText, "avgRatingsScore"); else
         * textValidation(portalText,savedText, "avgRatingsScore");
         *
         *
         * portalText = driver.findElement(DashboardPages.totalRatingHost).getText();
         * savedText = JSONRead.readJSON(jsonPath, "totalRatings");
         * if(portalText.toUpperCase().contains(savedText.toUpperCase()))
         * textValidation(savedText, savedText, "totalRatings"); else
         * textValidation(portalText, savedText, "totalRatings");
         *
         * //guest
         * portalText=driver.findElement(DashboardPages.avgRatingScoreGuest).getText();
         * savedText =JSONRead.readJSON(jsonPath, "avgRatingsScore");
         * if(portalText.toUpperCase().contains(savedText.toUpperCase()))
         * textValidation(savedText,savedText, "avgRatingsScore"); else
         * textValidation(portalText,savedText, "avgRatingsScore");
         *
         * portalText = driver.findElement(DashboardPages.totalRatingGuest).getText();
         * savedText = JSONRead.readJSON(jsonPath, "totalRatings");
         * if(portalText.toUpperCase().contains(savedText.toUpperCase()))
         * textValidation(savedText, savedText, "totalRatings"); else
         * textValidation(portalText, savedText, "totalRatings");
         *
         *
         *
         * portalText = driver.findElement(DashboardPages.export).getText(); savedText =
         * JSONRead.readJSON(jsonPath, "export"); textValidation(portalText, savedText,
         * "export");
         */

        String elements2[] = {"lastSevenDays","lastThirtyDays","lastTwelveMonths","currentBillingCycle",
                "customDate"};
        for (int i = 1; i <= 5; i++) {
            String index = Integer.toString(i);
            String path = DashboardPages.navCustom1 + index + DashboardPages.navCustom2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements2[i - 1]);
            textValidation(portalText,savedText, elements2[i - 1]); }

        validateFooter(driver);
        //test.info("------------------------- DASHBOARD PAGE VALIDATION CONCLUDED-------------------------");
        extent.flush();


    }


    public static void testRoleManagementCheckAndUncheck(WebDriver driver) throws Exception{
        //test.info("------------------------- Test Role Management Check and Uncheck -------------------------");
        String jsonTranslation="";
        driverWait.until(ExpectedConditions.elementToBeClickable(RoleManagementPage.clickRoleManagement)).click();
        Thread.sleep(2000);
        String frstLabel= driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[2]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "role");
        textValidation(frstLabel, jsonTranslation, "role");
        String secondLabel= driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[3]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "allowsnapshot");
        textValidation(secondLabel, jsonTranslation, "allowsnapshot");
        String thirdLabel= driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[4]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "allowmediadownload");
        textValidation(thirdLabel, jsonTranslation, "allowmediadownload");
        String fourthLabel= driver.findElement(By.xpath("//*[@id=\"tableHeader\"]/div/table/thead/tr/th[5]/div")).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "allowrecording");
        textValidation(fourthLabel, jsonTranslation, "allowrecording");
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(RoleManagementPage.roleTableRows));
        List<WebElement> roleRows = driver.findElements(RoleManagementPage.roleTableRows);
        for (WebElement roleRow: roleRows) {
            String roleName = roleRow.findElement(By.cssSelector("td:nth-child(2)")).getText().trim();
            //Uncheck the role checkbox if already checked
            WebElement roleCheckBox = roleRow.findElement(By.cssSelector("td:nth-child(1) input[type='checkbox']"));
            if(!roleCheckBox.isSelected()){
                roleCheckBox.click();
            }

            //uncheck the role and verify role checkbox is unchecked
            roleCheckBox.click();
            Thread.sleep(2000);
            //String //reportMsg = String.format("Click on %s role checkbox and %s role permission should be disabled", roleName, roleName);
            //Assert.assertFalse(reportMsg, roleCheckBox.isSelected());

            //test.pass(reportMsg);

            //Click on Allow Snapshot check and Allow Snapshot permission should be enabled
            WebElement allowSnapshot = roleRow.findElement(By.cssSelector("td:nth-child(3) input[type='checkbox']"));
            allowSnapshot.click();
            Thread.sleep(2000);
            //reportMsg = String.format("Click on Allow Snapshot checkbox for %s role and Allow Snapshot permission should be enabled", roleName);
            //Assert.assertTrue(reportMsg, allowSnapshot.isDisplayed());

            //test.pass(reportMsg);

            //Click on Allow Media Download check and Allow Media Download permission should be enabled
            WebElement allowMediaDownload = roleRow.findElement(By.cssSelector("td:nth-child(4) input[type='checkbox']"));
            allowMediaDownload.click();
            Thread.sleep(2000);
            //reportMsg = String.format("Click on Allow Media Download checkbox for %s role and Allow Media Download permission should be enabled", roleName);
            //Assert.assertTrue(reportMsg, allowMediaDownload.isSelected());

            //test.pass(reportMsg);

            //Skip Allow Recording functionality for Gust role.
            if(roleName.equals("Guest")){
                continue;
            }

            //Click on Allow Recording check and Allow Recording permission should be disabled
            List<WebElement> allowRecording = roleRow.findElements(By.cssSelector("td:nth-child(5) input[type='checkbox']"));
            //allowRecording.click();
            int count=0;
            for (WebElement label : allowRecording) {
                Thread.sleep(2000);
                //reportMsg = String.format("Click on Allow Recording checkbox for %s role and Allow Recording permission should be disabled", roleName);
                //Assert.assertFalse(reportMsg, label.isSelected());

                //test.pass(reportMsg);
            }
        }

    }


    public static void testMyProfilePictureUpload(WebDriver driver) throws Exception{

        driverWait.until(ExpectedConditions.elementToBeClickable(MyProfilePage.myprofileLink)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        //driver.findElement(MyProfilePage.chooseFile).click();
        Thread.sleep(5000);
        fileUpload(System.getProperty("user.dir")+"/src/main/java/configuration/user.jpg",driver);
        Thread.sleep(5000);
        driver.findElement(MyProfilePage.upload).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();

        //test.pass("New profile picture uploaded successfully");
    }


    public static void testMyProfileInfo(WebDriver driver) throws Exception{

        driverWait.until(ExpectedConditions.elementToBeClickable(MyProfilePage.myprofileLink)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
       // String emailId = driver.findElement(MyProfilePage.userEmailID).getText().trim();
       // emailId = emailId.replace(":", "").replace("\n", "");
       // //Assert.assertEquals("Verify user email ID in my profile page", emailId, emailId);
       //
        // //test.pass(String.format("User email ID %s is displayed in My Profile page", emailId));
//        List<String> expectedLabels = new ArrayList<>();
//        expectedLabels.add("Email");
//        expectedLabels.add("Name");
//        expectedLabels.add("Job Description");
//        expectedLabels.add("Primary Phone Number");
//        expectedLabels.add("Secondary Phone Number");
//        List<String> actualLabels = new ArrayList<>();
//        List<WebElement> userLabels = driver.findElements(MyProfilePage.userInfoLabels);
//        for (WebElement label: userLabels) {
//            actualLabels.add(label.getText().trim());
//        }
//        //Assert.assertEquals(expectedLabels, actualLabels);
//
//        //test.pass("Verify Email, Name, Job Description, Primary Phone Number, Secondary Phone Number labels are displayed in My Profile page");
    }


    public static void testMyCompanyLogoUpload(WebDriver driver) throws Exception{

        //test.info("------------- Test My Company Logo Upload Functionality -------------");

        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.clickMyCompany)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        //driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.fileLocation)).click();
        Thread.sleep(5000);
        fileUpload(System.getProperty("user.dir")+"/src/main/java/configuration/company.jpg",driver);
        Thread.sleep(5000);
        driver.findElement(MyCompanyPage.upload).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();

        //test.pass("New company logo uploaded successfully");
    }


    public static void testMyCompanyAddGroup(WebDriver driver) throws Exception{

        //test.info("------------- Test Add New Group Functionality -------------");

        Random random = new Random();
        String groupName = "TestGroup" + random.nextInt(9999);
        String expectedMsg = "Group name should start with alphanumeric character and should contain only alphanumeric characters, underscore and hyphen";
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.clickMyCompany)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));

        //Negative input1: Empty group
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupAdd)).click();
        driver.findElement(MyCompanyPage.groupNameAdd).click();
        String alertMsg = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.notificationMsg)).getText();
        ////Assert.assertEquals("Cannot add empty group", alertMsg);
        String emptyGroup = JSONRead.readJSON(jsonPath, "emptyGroupError");
        textValidation(alertMsg, emptyGroup, "emptyGroupError");
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        //
        // //test.pass("New group not added due to empty group name");

        //Negative input2: Group Name with space
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupAdd)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupName)).sendKeys("Test Group123");
        driver.findElement(MyCompanyPage.groupNameAdd).click();
        alertMsg = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.notificationMsg)).getText();
        //System.out.println("Group with namspace"+alertMsg);
        String spacError = JSONRead.readJSON(jsonPath, "groupNameFormatError");
        textValidation(alertMsg, spacError, "groupNameFormatError");
        ////Assert.assertEquals(expectedMsg, alertMsg);
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();

        //test.pass("New group [Test Group123] not added due to space in name");

        //Negative input3: Group Name start with special character
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupAdd)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupName)).sendKeys("#TestGroup");
        driver.findElement(MyCompanyPage.groupNameAdd).click();
        alertMsg = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.notificationMsg)).getText();
        String spChar = JSONRead.readJSON(jsonPath, "groupNameFormatError");
        textValidation(alertMsg, spChar, "groupNameFormatError");
        ////Assert.assertEquals(expectedMsg, alertMsg);
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();

        //test.pass("New group [#TestGroup] not added due to name start with special character");

        //Positive input: Group Name: TestGroup
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupAdd)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupName)).sendKeys(groupName);
        driver.findElement(MyCompanyPage.groupNameAdd).click();
        alertMsg = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.notificationMsg)).getText();
        String testGrp = JSONRead.readJSON(jsonPath, "tenantGroupAddSuccess");
        textValidation(alertMsg, testGrp, "tenantGroupAddSuccess");
        //System.out.println("psotive TestGroup with namspace"+alertMsg);
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();

        //test.pass(String.format("New group [%s] has been added successfully", groupName));

        //Negative input: Duplicate group name
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupAdd)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupName)).sendKeys(groupName);
        driver.findElement(MyCompanyPage.groupNameAdd).click();
        alertMsg = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.notificationMsg)).getText();
        String dupGrp = JSONRead.readJSON(jsonPath, "duplicateGroupName");
        textValidation(alertMsg, dupGrp, "duplicateGroupName");
        //System.out.println("Dup TestGroup with namspace"+alertMsg);
        ////Assert.assertEquals("Group names should not be repeated", alertMsg);
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();

        //test.pass(String.format("New group [%s] not added due to duplicate name", groupName));
    }


    public static void testMyCompanyGroupEdit(WebDriver driver) throws Exception {

        //test.info("------------- Test Edit Group Functionality -------------");

        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.clickMyCompany)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
       // Thread.sleep(5000);
       // ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,1000)");
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.firstGroupName)).click();
        driver.findElement(MyCompanyPage.editGroup).click();
        String groupName = driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupName)).getAttribute("value");
        driver.findElement(MyCompanyPage.groupName).clear();
        driver.findElement(MyCompanyPage.groupName).sendKeys(groupName +  "0");
        driver.findElement(MyCompanyPage.groupNameAdd).click();
        String alertMsg = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.notificationMsg)).getText();
        String testeditGrp = JSONRead.readJSON(jsonPath, "tenantGroupUpdateSuccess");
        textValidation(alertMsg, testeditGrp, "tenantGroupUpdateSuccess");
        //System.out.println("Test Edit Group"+alertMsg);
        ////Assert.assertTrue(alertMsg.startsWith("Group has been updated successfully"));
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();

        //test.pass(String.format("Group [%s] has been updated successfully as [%s]", groupName, groupName + "0"));
    }


    public static void testMyCompanyGroupDelete(WebDriver driver) throws Exception {

        //test.info("------------- Test Delete Group Functionality -------------");

        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.clickMyCompany)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        Thread.sleep(5000);
        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,1000)");
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.firstGroupName)).click();
        String groupName = driver.findElement(MyCompanyPage.firstGroupName).getText().trim();
        driver.findElement(MyCompanyPage.groupDelete).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertOkButton)).click();
        String alertMsg = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.notificationMsg)).getText();
        String testdelGrp = JSONRead.readJSON(jsonPath, "groupDeleteSuccess");
        textValidation(alertMsg, testdelGrp, "groupDeleteSuccess");
        //System.out.println("TestdeleteGroup"+alertMsg);
        ////Assert.assertTrue(alertMsg.startsWith("Group has been deleted successfully"));
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();

        //test.pass(String.format("Group [%s] has been deleted successfully", groupName));
    }


    public static void testMyCompanyGroupImportExport(WebDriver driver) throws Exception {

        //test.info("------------- Test Groups Import And Export Functionality -------------");

        //Import Groups
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.clickMyCompany)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        //driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.importGroups)).click();
        Thread.sleep(5000);
        fileUpload(System.getProperty("user.dir") + "/src/main/java/configuration/Template_Import_Groups.csv",driver);
        String alertMsg = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.notificationMsg)).getText();
        String testGrpImp = JSONRead.readJSON(jsonPath, "uploadOnlyJpg");
        textValidation(alertMsg, testGrpImp, "uploadOnlyJpg");
        //System.out.println("TestGroup with Import "+alertMsg);
       // //Assert.assertEquals("Groups has been imported successfully", alertMsg);
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();

        //test.pass("Groups has been imported successfully");

        //Export Groups
        driver.findElement(MyCompanyPage.exportGroups).click();
        Thread.sleep(5000);

        //test.pass("Groups has been exported successfully");
    }


    public static void testMyCompanySignalingSection(WebDriver driver) throws Exception{

        //test.info("------------- Test Signaling And Media Controls Section-------------");

        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.clickMyCompany)).click();
        Thread.sleep(5000);
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        //String labels[] = {"Host Media Region *", "Guest Media Region *", "Host Proxy *", "Guest Proxy *", "Encryption *"};
        //List<String> expectedLabels = Arrays.asList(labels);
        WebElement hostMedia = driver.findElement(By.id("hostMediaRegionLabel"));
        String label1=hostMedia.getText().replace('*',' ').trim();
        WebElement guestMedia = driver.findElement(By.id("guestMediaRegionLabel"));
        String label2= guestMedia.getText().replace('*',' ').trim();
        WebElement hostProxy = driver.findElement(By.xpath("(//*[@id=\"readOnly\"]/div[1]/label/strong)[24]"));
        String label3=hostProxy.getText().replace('*',' ').trim();;
        WebElement encryption=driver.findElement(By.xpath("(//*[@id=\"readOnly\"]/div[1]/label/strong)[26]"));
        String label4=encryption.getText().replace('*',' ').trim();
        WebElement guestProxy=driver.findElement(By.xpath("(//*[@id=\"readOnly\"]/div[1]/label/strong)[25]"));
        String label5=guestProxy.getText().replace('*',' ').trim();
        String hM = JSONRead.readJSON(jsonPath, "hostMediaRegion");
        textValidation(label1, hM, "hostMediaRegion");
        String gM = JSONRead.readJSON(jsonPath, "guestMediaRegion");
        textValidation(label2,gM,"guestMediaRegion");
        String hP= JSONRead.readJSON(jsonPath, "hostProxy");
        textValidation(label3,hP,"hostProxy");
        String enCryp= JSONRead.readJSON(jsonPath, "encryption");
        textValidation(label4,enCryp,"encryption");
        String gP=JSONRead.readJSON(jsonPath, "guestProxy");
        textValidation(label5,gP,"guestProxy");
        ////Assert.assertEquals(expectedLabels, actualLabels);

        //test.pass("Verify [Host Media Region *, Guest Media Region *, Host Proxy *, Guest Proxy *, Encryption *] dropdowns are displayed in Signaling and Media Controls section");
    }


    public static void testMyCompanyJoinControlsSection(WebDriver driver) throws Exception{

        //test.info("------------- Test Join Controls Section-------------");

        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.clickMyCompany)).click();
        Thread.sleep(5000);
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        WebElement guestJB=driver.findElement(By.xpath("(//*[@id=\"readOnly\"]/div[1]/label/strong)[27]"));
        String label6= guestJB.getText().replace('*',' ').trim();
        WebElement guestSG=driver.findElement(By.xpath("(//*[@id=\"readOnly\"]/div[1]/label/strong)[28]"));
        String label7=guestSG.getText().replace('*',' ').trim();
        String gJB=JSONRead.readJSON(jsonPath, "guestJoinByBrowser");
        textValidation(label6,gJB,"guestJoinByBrowser");
        String gSG=JSONRead.readJSON(jsonPath, "guestJoinBySmartGlasses");
        textValidation(label7,gSG,"guestJoinBySmartGlasses");
        //test.pass("Verify [Guest join by browser, Guest join by smart glasses] dropdowns are displayed in Join Controls section");
    }


    public static void fileUpload(String filePath,WebDriver driver) throws Exception {
        //String path = new StringSelection(filePath);
        //WebDriver driver = null;
        System.out.println("path for upload"+filePath);
        WebElement element = driver.findElement(By.id("logoUploaderRef"));
        element.sendKeys(filePath);
//        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(path, null);
//        Robot robot = new Robot();
//        robot.keyPress(KeyEvent.VK_ENTER);
//        robot.keyRelease(KeyEvent.VK_ENTER);
//        robot.keyPress(KeyEvent.VK_CONTROL);
//        robot.keyPress(KeyEvent.VK_V);
//        robot.keyRelease(KeyEvent.VK_V);
//        robot.keyRelease(KeyEvent.VK_CONTROL);
//        Thread.sleep(2000);
//        robot.keyPress(KeyEvent.VK_ENTER);
//        robot.keyRelease(KeyEvent.VK_ENTER);
    }

    public static void textValidation(String portalText, String savedText, String target) {

        String portalText1[] = portalText.split("\n");
        portalText = portalText1[0];
        portalText = portalText.trim();
        if (portalText.equalsIgnoreCase(savedText)) {
            System.out.println("SUCCESSFUL. Portal text is-> " + portalText + " ||  Saved text is-> " + savedText);
            //test.log(, "Portal text is-> " + portalText + " ||  Saved text is-> " + savedText);
            ////test.info("SUCCESSFUL. Portal text is-> " + portalText + " ||  Saved text is-> " + savedText);

            test.pass("SUCCESSFUL. Portal text is-> " + portalText + " ||  Saved text is-> " + savedText);
            //test.log
        } else {
            System.out.println("UNSUCCESSFUL. Portal text is-> " + portalText + "||  Saved text is-> " + savedText);
            ////test.info("UNSUCCESSFUL. Portal text is-> " + portalText + "||  Saved text is-> " + savedText);
            test.fail("UNSUCCESSFUL. Portal text is-> " + portalText + "||  Saved text is-> " + savedText);
        }

    }

    public static void validateFooter(WebDriver driver)
    {
        String portalText=null;
        String savedText=null;

        portalText = driver.findElement(SessionActivityPage.careAR).getText();
        savedText = "CAREAR";
        textValidation(portalText, savedText, "termsOfService");

        portalText = driver.findElement(SessionActivityPage.termsOfService).getText();
        savedText = JSONRead.readJSON(jsonPath, "termsOfService");
        textValidation(portalText, savedText, "termsOfService");

        portalText = driver.findElement(SessionActivityPage.privacyPolicy).getText();
        savedText = JSONRead.readJSON(jsonPath, "privacyPolicy");
        textValidation(portalText, savedText, "privacyPolicy");

        portalText = driver.findElement(SessionActivityPage.poweredByCareAr).getText();
        savedText = JSONRead.readJSON(jsonPath, "poweredByCareAR");
        if(portalText.contains(savedText))
            textValidation(savedText, savedText, "poweredByCareAR");
    }

    public static String removeEndChar(String a)
    {
        if (a.endsWith("*") || a.endsWith(":"))
        {
            a=a.substring(0, a.length()-1);		}
        return a;
    }
    public static void deleteUserValidation(WebDriver driver)throws Exception{

        //driver.findElement(UsersPage.users).click();
        Thread.sleep(2000);
        String jsonTranslation="";
        String alertMessage="";
        String requiredText="";

        driver.findElement(UsersPage.addNewUserButton).click();
        Thread.sleep(2000);
        driver.findElement(UsersPage.createButton).click();
        Thread.sleep(3000);

        requiredText=driver.findElement(UsersPage.emailRequired).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "emailRequired");
        textValidation(requiredText, jsonTranslation, "emailRequired");

        requiredText=driver.findElement(UsersPage.firstNameRequired).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "firstNameRequired");
        textValidation(requiredText, jsonTranslation, "firstNameRequired");

        requiredText=driver.findElement(UsersPage.lastNameRequired).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "lastNameRequired");
        textValidation(requiredText, jsonTranslation, "lastNameRequired");
        driver.findElement(UsersPage.cancelButton1).click();
        Thread.sleep(2000);


        driver.findElement(UsersPage.imgDelete).click();
        Thread.sleep(2000);


        alertMessage=driver.findElement(By.xpath("//*[@class='modal-body']//div")).getText().split("\\n")[0];
        jsonTranslation=JSONRead.readJSON(jsonPath, "confirmDeleteUser");
        textValidation(alertMessage, jsonTranslation, "confirmDeleteUser");
        driver.findElement(UsersPage.btnCancel).click();

        driver.findElement(UsersPage.imgDisable).click();
        Thread.sleep(1000);
        alertMessage=driver.findElement(By.xpath("//*[@class='modal-body']//div")).getText().split("\\n")[0];
        jsonTranslation=JSONRead.readJSON(jsonPath, "confirmDisableUser");
        textValidation(alertMessage, jsonTranslation, "confirmDisableUser");
        Thread.sleep(2000);
        driver.findElement(UsersPage.confirm).click();

        driver.findElement(UsersPage.imgEnable).click();
        Thread.sleep(1000);

        alertMessage=driver.findElement(By.xpath("//*[@class='modal-body']//div")).getText().split("\\n")[0];
        jsonTranslation=JSONRead.readJSON(jsonPath, "confirmEnableUser");
        textValidation(alertMessage, jsonTranslation, "confirmEnableUser");
        driver.findElement(UsersPage.confirm).click();


    }
    public static void myCompanyValidation(WebDriver driver) {
        String elements[] = { "companyName", "joinDate", "expirationDate", "tierLevel","maximumSubscribers","noOfVideoRecordingUsers","createdBy",
                "customerStatus","tenantPhysicalAddress","customerCRMID","resellerOfRecord","customerSuccessManager","zQuoteID",
                "referralCode", "servicenowControl","amazonS3Configuration","tenantAdmin", "groups"};
        //,"hostRegion", "guestRegion", "hostProxy", "guestProxy", "encryption" };
        String portalTranslation="";
        String jsonTranslation="";
        String path;
        WebFunctions.explicitWait(driver, 20, "Visibility", MyCompanyPage.lastTextWait1);

        for (int i = 1; i <= 18; i++) {
            String index = Integer.toString(i);
            if(i>=5 && i<=14) {
                //continue;
                path = MyCompanyPage.myCompanyNav1 + index + MyCompanyPage.myCompanyNav2;

            }
            if (i>=15 && i<17) {
                path = MyCompanyPage.myCompanyNav1 + index + MyCompanyPage.myCompanyNav3;
            }
            else if (i>=17) {
                index = Integer.toString(i+1);
                path = MyCompanyPage.myCompanyNav1 + index + MyCompanyPage.myCompanyNav2;
            }
            else {
                path = MyCompanyPage.myCompanyNav1 + index + MyCompanyPage.myCompanyNav2;

            }
            String portalText = driver.findElement(By.xpath(path)).getText();
            String savedText = JSONRead.readJSON(jsonPath, elements[i - 1]);
            textValidation(portalText, savedText, elements[i - 1]);
        }
        //portalTranslation=driver.findElement(MyCompanyPage.maximumSubscribers).getText();
        //jsonTranslation=JSONRead.readJSON(jsonPath, "maximumSubscribers");
        //textValidation(portalTranslation, jsonTranslation, "maximumSubscribers");

        //pavan code start
        portalTranslation=driver.findElement(MyCompanyPage.serviceNowAPIUsername).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "serviceNowAPIUsername");
        textValidation(portalTranslation, jsonTranslation, "serviceNowAPIUsername");

        portalTranslation=driver.findElement(MyCompanyPage.serviceNowAPIPassword).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "serviceNowAPIPassword");
        textValidation(portalTranslation, jsonTranslation, "serviceNowAPIPassword");

        portalTranslation=driver.findElement(MyCompanyPage.amazonAccessKeyId).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "amazonAccessKeyId");
        textValidation(portalTranslation, jsonTranslation, "amazonAccessKeyId");

        portalTranslation=driver.findElement(MyCompanyPage.amazonSecretAccessKey).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "amazonSecretAccessKey");
        textValidation(portalTranslation, jsonTranslation, "amazonSecretAccessKey");

        portalTranslation=driver.findElement(MyCompanyPage.amazonS3BucketName).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "amazonS3BucketName");
        textValidation(portalTranslation, jsonTranslation, "amazonS3BucketName");

        portalTranslation=driver.findElement(MyCompanyPage.bucketRegion).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "bucketRegion");
        textValidation(portalTranslation, jsonTranslation, "bucketRegion");

        portalTranslation=driver.findElement(MyCompanyPage.enableVideoRecording).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "enableVideoRecording");
        textValidation(portalTranslation, jsonTranslation, "enableVideoRecording");

        portalTranslation=driver.findElement(MyCompanyPage.encryption).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "encryption");
        textValidation(portalTranslation, jsonTranslation, "encryption");

        portalTranslation=driver.findElement(MyCompanyPage.guestJoinByBrowser).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "guestJoinByBrowser");
        textValidation(portalTranslation, jsonTranslation, "guestJoinByBrowser");

        portalTranslation=driver.findElement(MyCompanyPage.guestJoinBySmartGlasses).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "guestJoinBySmartGlasses");
        textValidation(portalTranslation, jsonTranslation, "guestJoinBySmartGlasses");

        //pavan code end



        portalTranslation=driver.findElement(MyCompanyPage.hostMediaRegion).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "hostMediaRegion");
        textValidation(portalTranslation, jsonTranslation, "hostMediaRegion");

        portalTranslation=driver.findElement(MyCompanyPage.guestMediaRegion).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "guestMediaRegion");
        textValidation(portalTranslation, jsonTranslation, "guestMediaRegion");

        portalTranslation=driver.findElement(MyCompanyPage.hostProxy).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "hostProxy");
        textValidation(portalTranslation, jsonTranslation, "hostProxy");

        portalTranslation=driver.findElement(MyCompanyPage.guestProxy).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "guestProxy");
        textValidation(portalTranslation, jsonTranslation, "guestProxy");


        List<WebElement> hostReg=driver.findElements(MyCompanyPage.hostRegion);
        //String countries[]= {"global","asia","china","europe","india","japan","northAmerica"};
        String countries[]= {"global","asia","europe","india","japan","northAmerica"};
        for(int i=0;i<hostReg.size();i++)
        {
            String nameFromPortal=hostReg.get(i).getText();
            String savedText = JSONRead.readJSON(jsonPath, countries[i]);
            textValidation(nameFromPortal, savedText, countries[i]);
        }

        List<WebElement> guestReg=driver.findElements(MyCompanyPage.guestRegion);
        for(int i=0;i<guestReg.size();i++)
        {
            String nameFromPortal=guestReg.get(i).getText();
            String savedText = JSONRead.readJSON(jsonPath, countries[i]);
            textValidation(nameFromPortal, savedText, countries[i]);
        }

        String entries[]= {"on","off"};
        List<WebElement> hostProxy=driver.findElements(MyCompanyPage.hostProxydd);
        List<WebElement> guestProxy=driver.findElements(MyCompanyPage.guestProxydd);
        //List<WebElement> encryption=driver.findElements(MyCompanyPage.encryption);

        for(int i=0;i<hostProxy.size();i++)
        {
            String nameFromPortal=hostProxy.get(i).getText();
            String savedText = JSONRead.readJSON(jsonPath, entries[i]);
            textValidation(nameFromPortal, savedText, entries[i]);

            nameFromPortal=guestProxy.get(i).getText();
            savedText = JSONRead.readJSON(jsonPath, entries[i]);
            textValidation(nameFromPortal, savedText, entries[i]);

            /*
             * nameFromPortal=encryption.get(i).getText(); savedText =
             * JSONRead.readJSON(jsonPath, entries[i]); textValidation(nameFromPortal,
             * savedText, entries[i]);
             */
        }

        //reloginToRefresh
        String nameFromPortal=driver.findElement(MyCompanyPage.lastTextWait1).getText();
        String savedText = JSONRead.readJSON(jsonPath, "reloginToRefresh");
        if(nameFromPortal.contains(savedText))
            textValidation(savedText, savedText,"reloginToRefresh");
        else
            textValidation(nameFromPortal, savedText,"reloginToRefresh");

        validateFooter(driver);
    }

    public static void myProfileValidation(WebDriver driver) throws Exception {
        driver.findElement(MyProfilePage.myprofileLink).click();
        WebFunctions.explicitWait(driver, 20, "CLICKABLE", MyProfilePage.userPortal);
        //WebFunctions.explicitWait(driver, 20, "CLICKABLE", MyProfilePage.saveButton);
        Thread.sleep(3000);
        String elements[] = { "email", "name", "jobDescription", "phoneNumber","secondaryPhoneNumber" };

        for (int i = 1; i <= 5; i++) {
            String index = Integer.toString(i);
            //String path = MyProfilePage.myProfileNav1 + index + MyProfilePage.myProfileNav2;
            String path=MyProfilePage.myProfileNav3+ index+MyProfilePage.myProfileNav4;
            String portalText = driver.findElement(By.xpath(path)).getText();
            String savedText = JSONRead.readJSON(jsonPath, elements[i - 1]);
            textValidation(portalText, savedText, elements[i - 1]);
        }
        String portalText = driver.findElement(MyProfilePage.saveButton).getText();
        String savedText = JSONRead.readJSON(jsonPath, "save");
        if(portalText.contains(savedText))
            textValidation(savedText, savedText, "Save");

        portalText = driver.findElement(MyProfilePage.versionButton).getText();
        savedText = JSONRead.readJSON(jsonPath, "version");
        if(portalText.contains(savedText))
            textValidation(savedText, savedText, "version");
        else
            textValidation(portalText, savedText, "version");

        portalText = driver.findElement(MyProfilePage.userPortal).getText();
        savedText = JSONRead.readJSON(jsonPath, "userPortal");
        textValidation(portalText, savedText, "userPortal");

        portalText = driver.findElement(MyProfilePage.logout).getText();
        savedText = JSONRead.readJSON(jsonPath, "logout");
        textValidation(portalText, savedText, "logout");

        portalText = driver.findElement(MyProfilePage.chooseFile).getText();
        savedText = JSONRead.readJSON(jsonPath, "chooseFile");
        textValidation(portalText, savedText, "chooseFile");

        /*
         * portalText = driver.findElement(MyProfilePage.noFileChosen).getText();
         * savedText = JSONRead.readJSON(jsonPath, "chooseFile");
         * textValidation(portalText, savedText, "chooseFile");
         */

        portalText = driver.findElement(MyProfilePage.upload).getText();
        savedText = JSONRead.readJSON(jsonPath, "upload");
        textValidation(portalText, savedText, "upload");
        validateFooter(driver);
    }

    public static void sessionActivityValidation(WebDriver driver) throws Exception {
        driver.findElement(SessionActivityPage.sessionActivityNav).click();
        WebFunctions.explicitWait(driver, 20, "CLICKABLE", SessionActivityPage.userPortal);
        WebFunctions.explicitWait(driver, 20, "Visibility", SessionActivityPage.poweredByCareAr);
        Thread.sleep(3000);

        // navtabs validation : Today/This week/This Month/Custom Date
        String elements[] = { "today", "thisWeek", "thisMonth", "customDate" };

        for (int i = 1; i <= 4; i++) {
            String index = Integer.toString(i);
            String path = SessionActivityPage.navTabs1 + index + SessionActivityPage.navTabs2;
            String portalText = driver.findElement(By.xpath(path)).getText();
            String savedText = JSONRead.readJSON(jsonPath, elements[i - 1]);
            textValidation(portalText, savedText, elements[i - 1]);
        }

        String elements1[] = { "startTime", "duration", "host", "guests", "group" };
        for (int i = 2; i <= 6; i++) {
            String index = Integer.toString(i);
            String path = SessionActivityPage.tableHeader1 + index + SessionActivityPage.tableHeader2;
            String portalText = driver.findElement(By.xpath(path)).getText();
            String savedText = JSONRead.readJSON(jsonPath, elements1[i - 2]);
            textValidation(portalText, savedText, elements1[i - 2]);
        }

        String portalText = driver.findElement(SessionActivityPage.rowsPerPage).getText();
        String savedText = JSONRead.readJSON(jsonPath, "rowsPerPage");
        if(portalText.contains(savedText))
            textValidation(savedText, savedText, "rowsPerPage");

        portalText = driver.findElement(SessionActivityPage.termsOfService).getText();
        savedText = JSONRead.readJSON(jsonPath, "termsOfService");
        textValidation(portalText, savedText, "termsOfService");

        portalText = driver.findElement(SessionActivityPage.privacyPolicy).getText();
        savedText = JSONRead.readJSON(jsonPath, "privacyPolicy");
        textValidation(portalText, savedText, "privacyPolicy");

        portalText = driver.findElement(SessionActivityPage.poweredByCareAr).getText();
        savedText = JSONRead.readJSON(jsonPath, "poweredByCareAR");
        if(portalText.contains(savedText))
            textValidation(savedText, savedText, "poweredByCareAR");

        portalText = driver.findElement(SessionActivityPage.sessionImages).getText();
        savedText = JSONRead.readJSON(jsonPath, "sessionImages");
        textValidation(portalText, savedText, "sessionImages");

        // userPortal
        portalText = driver.findElement(SessionActivityPage.userPortal).getText();
        savedText = JSONRead.readJSON(jsonPath, "userPortal");
        textValidation(portalText, savedText, "userPortal");

        /*
         * validating CUSTOM DATE SECTION
         *
         */

        System.out.println("\n");
        System.out.println("------------INITIATING VALIDATION FOR SESSION ACTIVITY > CUSTOM DATE SECTION----------");
        System.out.println("\n");
        driver.findElement(SessionActivityPage.CustomDate).click();
        Thread.sleep(3000);

        portalText = driver.findElement(SessionActivityPage.from).getText();
        savedText = JSONRead.readJSON(jsonPath, "from");
        textValidation(portalText, savedText, "from");

        portalText = driver.findElement(SessionActivityPage.to).getText();
        savedText = JSONRead.readJSON(jsonPath, "to");
        textValidation(portalText, savedText, "to");

        portalText = driver.findElement(SessionActivityPage.search).getText();
        savedText = JSONRead.readJSON(jsonPath, "search");
        textValidation(portalText, savedText, "search");

        portalText = driver.findElement(SessionActivityPage.clear).getText();
        savedText = JSONRead.readJSON(jsonPath, "clear");
        textValidation(portalText, savedText, "clear");

        portalText = driver.findElement(SessionActivityPage.seeActivityInMap).getText();
        savedText = JSONRead.readJSON(jsonPath, "seeActivityInMap");
        textValidation(portalText, savedText, "seeActivityInMap");

        Thread.sleep(2000);
        validateFooter(driver);
    }

    public static void validateKPI(WebDriver driver) throws InterruptedException {
        driver.findElement(KPIPage.clickKPI).click();
        WebFunctions.explicitWait(driver, 20, "Visibility", KPIPage.addNewKPI);
        WebFunctions.explicitWait(driver, 20, "Clickable", KPIPage.addNewKPIButton);
        Thread.sleep(3000);
        // tableValidation
        String elements1[] = { "kpiId", "index", "userType", "kpiQuestions", "required", "type", "action" };
        for (int i = 1; i <8; i++) {
            String index = Integer.toString(i);
            String path = KPIPage.tableHeaders1 + index + KPIPage.tableHeaders2;
            String portalText = driver.findElement(By.xpath(path)).getText();
            String savedText = JSONRead.readJSON(jsonPath, elements1[i - 1]);
            textValidation(portalText, savedText, elements1[i - 1]);
        }

        String portalText = driver.findElement(KPIPage.addNewKPI).getText();
        String savedText = JSONRead.readJSON(jsonPath, "addNewKPI");
        textValidation(portalText, savedText, "addNewKPI");

        // clicking on add new KPI button

        driver.findElement(KPIPage.addNewKPIButton).click();
        Thread.sleep(3000);

        String elements2[] = { "index", "kpiQuestion", "required", "type", "userType" };
        for (int i = 1; i <= 5; i++) {
            String index = Integer.toString(i);
            String path = KPIPage.labelsOnAddKPI1 + index + KPIPage.labelsOnAddKPI2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements2[i - 1]);
            if(portalText.contains(savedText))
                textValidation(savedText, savedText, elements2[i - 1]);
            else
                textValidation(portalText, savedText, elements2[i - 1]);
        }

        String elements3[] = { "submit", "cancel" };
        for (int i = 1; i <= 2; i++) {
            String index = Integer.toString(i);
            String path = KPIPage.submitCancel1 + index + KPIPage.submitCancel2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements3[i - 1]);
            textValidation(portalText, savedText, elements3[i - 1]);
        }

        String elements4[] = { "mandatory", "optional" };
        for (int i = 1; i <= 2; i++) {
            String index = Integer.toString(i);
            String path = KPIPage.mandatoryOptional1 + index + KPIPage.mandatoryOptional2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements4[i - 1]);
            textValidation(portalText, savedText, elements4[i - 1]);
        }

        String elements5[] = { "rating", "dropdown", "singleline", "multiline" };
        for (int i = 1; i <= 4; i++) {
            String index = Integer.toString(i);
            String path = KPIPage.type1 + index + KPIPage.type2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements5[i - 1]);
            textValidation(portalText, savedText, elements5[i - 1]);
        }

        String elements6[] = { "host", "guest" };
        for (int i = 1; i <= 2; i++) {
            String index = Integer.toString(i);
            String path = KPIPage.userType1 + index + KPIPage.userType2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements6[i - 1]);
            textValidation(portalText, savedText, elements6[i - 1]);
        }
        validateFooter(driver);
    }

    public static void testUsersScreen(WebDriver driver) throws Exception
    {
        Thread.sleep(3000);
        /*
         * Actions action =new Actions(driver);
         * action.moveToElement(driver.findElement(UsersPage.clickUsers)).click().build(
         * ).perform();
         */
        driver.findElement(UsersPage.clickUsers).click();
        WebFunctions.explicitWait(driver, 20, "Visibility", UsersPage.exportAll);
        WebFunctions.explicitWait(driver, 20, "Clickable", UsersPage.addNewUserButton);
        Thread.sleep(5000);

        //pavan code starts
        deleteUserValidation(driver);
        //pavan code ends


        String portalText = driver.findElement(UsersPage.addNewUser).getText();
        String savedText = JSONRead.readJSON(jsonPath, "addNewUser");
        textValidation(portalText, savedText, "addNewUser");

        portalText = driver.findElement(UsersPage.exportAll).getText();
        savedText = JSONRead.readJSON(jsonPath, "exportAll");
        textValidation(portalText, savedText, "exportAll");

        portalText = driver.findElement(UsersPage.importButton).getText();
        savedText = JSONRead.readJSON(jsonPath, "import");
        textValidation(portalText, savedText, "import");

        String elements[] = { "name","email","role","group","status","phoneNumber","secondaryPhoneNumber","joinedDate","lastLoggedIn" };
        for (int i = 3; i <= 11; i++) {
            String index = Integer.toString(i);
            String path = UsersPage.userTableHeader1 + index + UsersPage.userTableHeader2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements[i - 3]);
            textValidation(portalText, savedText, elements[i - 3]);
        }

        portalText = driver.findElement(UsersPage.actionColumn).getText();
        savedText = JSONRead.readJSON(jsonPath, "action");
        textValidation(portalText, savedText, "action");

        driver.findElement(UsersPage.addNewUserButton).click();
        WebFunctions.explicitWait(driver, 20, "Visibility", UsersPage.cancelButton);

        List<WebElement> webElements=driver.findElements(UsersPage.elementsOnAddUser);
        String elements1[] = { "email","firstName","lastName","phoneNumber","secondaryPhoneNumber","jobDescription","group"};
        int j=0;
        Iterator listItr=webElements.iterator();
        while(listItr.hasNext())
        {
            WebElement e1=(WebElement) listItr.next();
            portalText =e1.getText();
            savedText=JSONRead.readJSON(jsonPath, elements1[j]);
            if(portalText.contains("*") && portalText.contains(savedText))
                textValidation(savedText, savedText, elements[j]);
            else
                textValidation(portalText, savedText, elements[j]);
            j++;
        }

        portalText = driver.findElement(UsersPage.createButton).getText();
        savedText = JSONRead.readJSON(jsonPath, "create");
        textValidation(portalText, savedText, "create");

        portalText = driver.findElement(UsersPage.cancelButton).getText();
        savedText = JSONRead.readJSON(jsonPath, "cancel");
        textValidation(portalText, savedText, "cancel");
        driver.findElement(UsersPage.cancelButton).click();

        WebFunctions.explicitWait(driver, 20, "VISIBILITY",UsersPage.disableEnable);
        //driver.findElement(UsersPage.disableEnable).click();
        WebElement togg = driver.findElement(UsersPage.disableEnable);
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("arguments[0].click();", togg);
        WebFunctions.explicitWait(driver, 20, "VISIBILITY", UsersPage.attention);

        portalText = driver.findElement(UsersPage.attention).getText();
        savedText = JSONRead.readJSON(jsonPath, "caution");
        textValidation(portalText, savedText, "caution");

        portalText = driver.findElement(UsersPage.message).getText();
        savedText = JSONRead.readJSON(jsonPath, "confirmDisableUser");
        textValidation(portalText, savedText, "confirmDisableUser");

        portalText = driver.findElement(UsersPage.confirm).getText();
        savedText = JSONRead.readJSON(jsonPath, "yes");
        textValidation(portalText, savedText, "yes");

        portalText = driver.findElement(UsersPage.cancel).getText();
        savedText = JSONRead.readJSON(jsonPath, "cancel");
        textValidation(portalText, savedText, "cancel");

        driver.findElement(UsersPage.cancel).click();
        Thread.sleep(2000);
        validateFooter(driver);
    }

    public static void sessionMapValiation(WebDriver driver) throws Exception
    {
        String portalText;
        String savedText;

        driver.findElement(SessionMapPage.clickSessionMap).click();
        /*
         * WebFunctions.explicitWait(driver, 20, "Visibility",
         * SessionMapPage.seeActivityInTable); WebFunctions.explicitWait(driver, 20,
         * "Clickable", SessionMapPage.custom);
         */
        Thread.sleep(3000);


        portalText = driver.findElement(SessionMapPage.sessionMap).getText();
        savedText = JSONRead.readJSON(jsonPath, "sessionMap");
        textValidation(portalText, savedText, "sessionMap");

        portalText = driver.findElement(SessionMapPage.seeActivityInTable).getText();
        savedText = JSONRead.readJSON(jsonPath, "seeActivityInTable");
        textValidation(portalText, savedText, "seeActivityInTable");

        portalText = driver.findElement(SessionMapPage.host).getText();
        savedText = JSONRead.readJSON(jsonPath, "host");
        textValidation(portalText, savedText, "host");

        portalText = driver.findElement(SessionMapPage.guest).getText();
        savedText = JSONRead.readJSON(jsonPath, "guest");
        textValidation(portalText, savedText, "guest");

        portalText = driver.findElement(SessionMapPage.groupMarkers).getText();
        savedText = JSONRead.readJSON(jsonPath, "groupMarkers");
        textValidation(portalText, savedText, "groupMarkers");

        //mapZoomInstruction

        portalText = driver.findElement(SessionMapPage.controlScrollText).getText();
        savedText = JSONRead.readJSON(jsonPath, "mapZoomInstruction");
        textValidation(portalText, savedText, "mapZoomInstruction");


        String elements[] = { "today","thisWeek","thisMonth","customDate"};
        for (int i = 1; i <= 4; i++) {
            String index = Integer.toString(i);
            String path = SessionMapPage.navTabs1 + index + SessionMapPage.navTabs2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements[i - 1]);
            textValidation(portalText, savedText, elements[i - 1]);

            if(i==4)
            {
                driver.findElement(By.xpath(path)).click();
            }
        }

        //driver.findElement(SessionMapPage.custom).click();
        Thread.sleep(3000);

        portalText = driver.findElement(SessionMapPage.from).getText();
        savedText = JSONRead.readJSON(jsonPath, "from");
        textValidation(portalText, savedText, "from");

        portalText = driver.findElement(SessionMapPage.to).getText();
        savedText = JSONRead.readJSON(jsonPath, "to");
        textValidation(portalText, savedText, "to");


        String elements1[] = { "search","clear"};
        for (int i = 1; i <= 2; i++) {
            String index = Integer.toString(i);
            String path = SessionMapPage.searchClear1 + index + SessionMapPage.searchClear2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements1[i - 1]);
            textValidation(portalText, savedText, elements1[i - 1]);
        }
        validateFooter(driver);
    }

    public static void validateLocalizationall(WebDriver driver, int langCount, String jsonPath) throws Exception {

        switch (langCount) {
            case 1:
                test = extent.createTest("French");
                break;
            case 2:
                test = extent.createTest("German");
                break;
            case 3:
                test = extent.createTest("Italian");
                break;
            case 4:
                test = extent.createTest("Portugese");
                break;
            case 5:
                test = extent.createTest("Spanish");
                break;
            case 6:
                test = extent.createTest("Indonesian");
                break;
            case 7:
                test = extent.createTest("Japanese");
                break;
            case 8:
                test = extent.createTest("Malay");
                break;
            case 9:
                test = extent.createTest("Chinese");
                break;

        }

        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        driver.get(URL);
        Thread.sleep(3000);
        driver.manage().window().maximize();
        driverWait = new WebDriverWait(driver,60);
        driver.findElement(LoginPage.Ad_Email).sendKeys(uname);
        driver.findElement(LoginPage.Ad_Password).sendKeys(passwd);
        driver.findElement(LoginPage.Ad_LoginButton).click();
        System.out.println("clicked on login button");
        WebFunctions.explicitWait(driver, 20, "Visibility", Admin_WelcomePage.waitElement);
        Thread.sleep(8000);
        //
        // //test.pass("User logged in successfully with email id: " + uname);

        driver.findElement(Admin_WelcomePage.languageChange).click();
        Thread.sleep(2000);
        if(choicecount==1)
        {
            driver.findElement(Admin_WelcomePage.selectFrench).click();
            System.out.println("\n\n\n Selected FRENCH \n\n");
        }
        else if(choicecount==2)
        {
            driver.findElement(Admin_WelcomePage.selectGerman).click();
            System.out.println("\n\n\n Selected GERMAN \n\n");
        }
        else if(choicecount==3)
        {
            driver.findElement(Admin_WelcomePage.selectItalian).click();
            System.out.println("\n\n\n Selected ITALIAN \n\n");
        }
        else if(choicecount==4)
        {
            driver.findElement(Admin_WelcomePage.selectPortugese).click();
            System.out.println("\n\n\n Selected PORTUGUESE \n\n");
        }
        else if(choicecount==5)
        {
            driver.findElement(Admin_WelcomePage.selectSpanish).click();
            System.out.println("\n\n\n Selected SPANISH \n\n");
        }
        else if(choicecount==6)
        {
            driver.findElement(Admin_WelcomePage.selectIndonesian).click();
            System.out.println("\n\n\n Selected INDONESIAN \n\n");
        }
        else if(choicecount==7)
        {
            driver.findElement(Admin_WelcomePage.selectJapanese).click();
            System.out.println("\n\n\n Selected JAPANESE \n\n");
        }
        else if(choicecount==8)
        {
            driver.findElement(Admin_WelcomePage.selectMalay).click();
            System.out.println("\n\n\n Selected MALAY \n\n");
        }
        else if(choicecount==9)
        {
            driver.findElement(Admin_WelcomePage.selectChinese).click();
            System.out.println("\n\n\n Selected CHINESE \n\n");
        }

        Thread.sleep(2000);
        //Thread.sleep(2000);
        //
        // //test.pass(choice + " Language selected");

        driver.findElement(Admin_WelcomePage.saveLanguage).click();
        Thread.sleep(3000);

        System.out.println("\n\n");
        //System.out.println("------------INITIATING VALIDATION FOR Users, Role Management, KPIs ,Session Activity, Session Map,Dashboard Modules, My Profile , My Company---------");
        System.out.println("\n");

        FileInputStream fis=new FileInputStream(localizationVocabsPath + "NewUserModified.xlsx");
        XSSFWorkbook wb = new XSSFWorkbook(fis);
        XSSFSheet sheet = wb.getSheetAt(0);

        //USER PAGE TEST
        System.out.println("------------INITIATING VALIDATION FOR Users, KPIs ,Session Activity, Session Map,Dashboard Modules----------");
        testUsersPage(driver, sheet);

        //ROLE MANAGEMENT
        testRoleManagementPage(driver);

        //KPI PAGE TEST
       testKPIPage(driver);

        //SESSION ACTIVITY PAGE TEST
       sessionActivity(driver);

        //SESSION MAPS PAGE TEST
       sessionMaps(driver);

        //MY PROFILE PAGE
      testMyProfilePage(driver);

        //MY COMPANY PAGE
      testMyCompanyPage(driver);

        //DASHBOARD PAGE TEST
      dashboards(driver);

        System.out.println("-------USERS VALIDATION CONCLUDED-------");
        //test.info("------- CONCLUDED VALIDATION FOR Users, Role Management, KPIs ,Session Activity, Session Map,Dashboard Modules, My Profile , My Company -------");
        System.out.println("------------INITIATING VALIDATION FOR LEFT PANEL NAVIGATION BUTTONS----------");
        test.info("------------INITIATING VALIDATION FOR LEFT PANEL NAVIGATION BUTTONS----------");
        System.out.println("\n");
        String elements[] = { "users","roleManagement", "kpis", "sessionActivity", "sessionMap", "dashboard", "myProfile", "myCompany" };

        for (int i = 1; i <= 8; i++) {
            String index = Integer.toString(i);
            String path = Admin_WelcomePage.navigate1 + index + Admin_WelcomePage.navigate2;
            Thread.sleep(2000);
            String portalText = driver.findElement(By.xpath(path)).getText();

            //String paths[]= {"./src//main//java//localizationVocabs//Frenchnew.json", "./src//main//java//localizationVocabs//Germannew.json","./src//main//java//localizationVocabs//Italiannew.json","./src//main//java//localizationVocabs//Portuguesenew.json","./src//main//java//localizationVocabs//Spanishnew.json","./src//main//java//localizationVocabs//Indonesiannew.json","./src//main//java//localizationVocabs//Japanesenew.json","./src//main//java//localizationVocabs//Malaynew.json","./src//main//java//localizationVocabs//Chinesenew.json" };
            //String jsonPath1 = paths[i-1];
            String savedText = JSONRead.readJSON(jsonPath, elements[i - 1]);
            textValidation(portalText, savedText, elements[i - 1]);
        }
        //extent.flush();
        validateFooter(driver);
        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR MY COMPANY PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR MY COMPANY PAGE----------"+"\n");

        //testUsersScreen(driver);

        //myCompanyValidation(driver);

        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR USERS PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR USERS PAGE----------"+"\n");
        testUsersScreen(driver);

        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR KPI PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR KPI PAGE----------"+"\n");
        validateKPI(driver);

        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR SESSION ACTIVITY PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR SESSION ACTIVITY PAGE----------"+"\n");
        sessionActivityValidation(driver);

        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR SESSION MAP PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR SESSION MAP PAGE----------"+"\n");
        sessionMapValiation(driver);


        //System.out.println("\n\n"+"------------INITIATING VALIDATION FOR DASHBOARD ITEMS----------"+"\n");
        //test.info("\n\n"+"------------INITIATING VALIDATION FOR DASHBOARD ITEMS----------"+"\n");
        //LocalizationValidation.dashboardValidation(driver);

        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR MY PROFILE PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR MY PROFILE PAGE----------"+"\n");
        myProfileValidation(driver);

        System.out.println("-------VALIDATION CONCLUDED-------");
        test.info("-------VALIDATION CONCLUDED-------");

        driver.close();
        //if (langCount == j) {
        extent.flush();
        //}
    }


}
