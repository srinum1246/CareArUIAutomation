package webElements;
import org.openqa.selenium.By;

public interface MyCompanyPage {
    public static final String myCompNav1 = "//*[@id='tenantCompany']/div[4]";
    public static final String myCompNav2 = "//*[@id='tenantCompany']/div[5]";
    public static final String myCompNav3 = "//*[@id='tenantCompany']/div[6]";
    public static final String myCompNav4 = "//*[@id='tenantCompany']/div[7]";
    public static final String myCompNav5 = "//*[@id='tenantCompany']/div[9]";
    public static final String myCompNav6= "//*[@id='tenantCompany']/div[10]";
    public static final String myCompNav7= "//*[@id='tenantCompany']/div[11]";

    //from 1 to 11
    public static final String myCompanyNav1="//div[@id='tenantCompany']/div[";
    public static final String myCompanyNav2="]/div/label/strong";
    public static final String myCompanyNav3="]/label/strong";

    //New elements Mownima code
    public static final By company=By.xpath("//div[@id='tenantCompany']/div[1]/div[1]/label/strong");
    public static final By date=By.xpath("//div[@id='tenantCompany']/div[4]/div[2]/div[1]/label/strong");
    public static final By expirationDate=By.xpath("//div[@id='tenantCompany']/div[4]/div[4]/div[1]/label/strong");
    public static final By maximumSubscribers=By.xpath("//div[@id='tenantCompany']/div[4]/div[6]/div[1]/label/strong");
    public static final By createdBy =By.xpath("//div[@id='tenantCompany']/div[4]/div[7]/div[1]/label/strong");
    public static final By tenantPhysicalAddress=By.xpath("//div[@id='tenantCompany']/div[2]/div[1]/label/strong");
    public static final By customerCRMID=By.xpath("//div[@id='tenantCompany']/div[4]/div[8]/div[1]/label/strong");
    public static final By resellerOfRecord=By.xpath("//div[@id='tenantCompany']/div[4]/div[9]/div[1]/label/strong");
    public static final By customerSuccessManager=By.xpath("//div[@id='tenantCompany']/div[4]/div[10]/div[1]/label/strong");
    public static final By referralCode=By.xpath("//div[@id='tenantCompany']/div[4]/div[12]/div[1]/label/strong");


    //Service now controls
    public static final By serviceNowAPIUsername=By.xpath("//div[@id='tenantCompany']/div[6]/form/div[1]/div[1]/label/strong");
    public static final By serviceNowAPIPassword=By.xpath("//div[@id='tenantCompany']/div[6]/form/div[2]/div[1]/label/strong");

    //Amazon S3 Configuration
    public static final By amazonAccessKeyId=By.xpath("//div[@id='tenantCompany']/div[7]/form/div[1]/div[1]/label/strong");
    public static final By amazonSecretAccessKey=By.xpath("//div[@id='tenantCompany']/div[7]/form/div[2]/div[1]/label/strong");
    public static final By amazonS3BucketName=By.xpath("//div[@id='tenantCompany']/div[7]/form/div[3]/div[1]/label/strong");
    public static final By tbxAmazonS3BucketName=By.xpath("//div[@id='tenantCompany']/div[7]/form/div[3]/div[2]/input");

    public static final By bucketRegion=By.xpath("//div[@id='tenantCompany']/div[7]/form/div[4]/div[1]/label/strong");
    public static final By enableVideoRecording=By.xpath("//div[@id='tenantCompany']/div[7]/form/div[5]/div[1]/label/strong");


    //Media Geo Fencing Controls
    public static final By hostMediaRegion=By.xpath("//div[@id='tenantCompany']/div[10]/div[1]/div[1]/label/strong");
    public static final By guestMediaRegion=By.xpath("//div[@id='tenantCompany']/div[10]/div[2]/div[1]/label/strong");

    public static final By hostProxy=By.xpath("//div[@id='tenantCompany']/div[10]/div[3]/div[1]/label/strong");
    //public static final By guestProxy=By.xpath("//*[@class='mediaGeofenceSettingContainer']/following::div[1]/following::div[1]/div/label/strong");
    public static final By guestProxy=By.xpath("//div[@id='tenantCompany']/div[10]/div[4]/div[1]/label/strong");
    public static final By encryption=By.xpath("//div[@id='tenantCompany']/div[10]/div[5]/div[1]/label/strong");
    public static final By guestJoinByBrowser=By.xpath("//div[@id='tenantCompany']/div[11]/div[1]/div[1]/label/strong");
    public static final By guestJoinBySmartGlasses=By.xpath("//div[@id='tenantCompany']/div[11]/div[2]/div[1]/label/strong");

    public static final By lastTextWait=By.xpath("//*[@style='display: flex; flex: 1 1 0%;']/div[1]/label");
    public static final By lastTextWait1=By.xpath("//*[@class='text-muted']");

    ////div[@id='tenantCompany']/div[12]/div/label

    public static final By hostRegion=By.xpath("//div[@class='mediaGeofenceSettingContainer']/div[1]/div[2]/select/option");
    public static final By guestRegion=By.xpath("//div[@class='mediaGeofenceSettingContainer']/div[2]/div[2]/select/option");
    public static final By hostProxydd=By.xpath("//*[@class='mediaGeofenceSettingContainer']/following::div[1]/div[2]/select/option");
    public static final By guestProxydd=By.xpath("//*[@class='mediaGeofenceSettingContainer']/following::div[1]/following::div[1]/div[2]/select/option");
    // public static final By encryption=By.xpath("//div[@id='tenantCompany']/div[11]/div[2]/select/option");

    public static final By fileLocation=By.xpath("//*[@class='chooseFile']");
    public static final By upload=By.xpath("//*[@class='hideTextOverflow']");
    public static final By btnAmazonS3ConfigSave=By.xpath("(//*[@class='btn btn-primary'])[3]");

    public static final By groupAdd=By.xpath("//*[@id='add']");
    public static final By groupName=By.xpath("//*[@class='form-control ']");
    public static final By groupNameAdd=By.xpath("(//*[@class='modal-footer']/button)[1]");
    public static final By groupNameList=By.xpath("//*[@class='action-import']//following::div[4]/button");
    public static final By groupDelete=By.xpath("//*[@id='delete']");
    public static final By ddHostMediaRegion=By.xpath("//div[@id='tenantCompany']/div[10]/div[1]/div[2]/select");
    public static final By ddGuestMediaRegion=By.xpath("//div[@id='tenantCompany']/div[10]/div[2]/div[2]/select");

    public static final By ddHostProxy=By.xpath("//div[@id='tenantCompany']/div[10]/div[3]/div[2]/select");
    public static final By ddGuestProxy=By.xpath("//div[@id='tenantCompany']/div[10]/div[4]/div[2]/select");
    public static final By ddEncryption=By.xpath("//div[@id='tenantCompany']/div[10]/div[5]/div[2]/select");
    public static final By ddGuestJoinByUser=By.xpath("//div[@id='tenantCompany']/div[11]/div[1]/div[2]/select");
    public static final By ddGuestJoinBySmartGlass=By.xpath("//div[@id='tenantCompany']/div[11]/div[2]/div[2]/select");
    public static final By proxySave=By.xpath("(//*[@class='btn btn-primary'])[4]");
    public static final By cbxEnableVideoRecording=By.xpath("//div[@class='mediaGeofenceSettingContainer']/form/div[5]/div[2]/input");
    public static final By tbxServicenowAPIUname=By.xpath("(//*[@class='mediaGeofenceSettingContainer']/form/div/div[2]/input)[1]");
    public static final By tbxServicenowPWD=By.xpath("(//*[@class='mediaGeofenceSettingContainer']/form/div/div[2]/input)[2]");
    public static final By servicenowSave=By.xpath("(//*[@class='btn btn-primary'])[2]");
    public static final By unamePwdRequired=By.xpath("//*[@class='modal-body']/p");
    public static final By incompleteFormOk=By.xpath("(//*[@class='btn btn-primary'])[5]");

    //usage information
    public static final By Minutesused=By.xpath("//div[@id='tenantCompany']/div[5]/div[1]/div[1]/label/strong");
    public static final By SessionsUsed=By.xpath("//div[@id='tenantCompany']/div[5]/div[2]/div[1]/label/strong");
    public static final By InstructSessionsPurchased=By.xpath("//div[@id='tenantCompany']/div[5]/div[3]/div[1]/label/strong");
    public static final By InstructSessionsUsed=By.xpath("//div[@id='tenantCompany']/div[5]/div[4]/div[1]/label/strong");
    public static final By InstructSessionsAvailable=By.xpath("//div[@id='tenantCompany']/div[5]/div[5]/div[1]/label/strong");


    String groupSectionXpath = "//div[@id='tenantCompany']//div[@class='mediaGeofenceSettingContainer'][3]";
    public static final By signalingSectionXpath = By.xpath("//div[@id='tenantCompany']//div[@class='mediaGeofenceSettingContainer'][4]");
    public static final By joinControlsSectionXpath = By.xpath("//div[@id='tenantCompany']//div[@class='mediaGeofenceSettingContainer'][5]");
    public static final By clickMyCompany = By.cssSelector("div.sidebar ul.nav>li:nth-child(8)");
    public static final By firstGroupName = By.xpath("//button[@class=\"btn btn-secondary\"][1]");
    public static final By editGroup = By.id("edit");
    public static final By importGroups = By.xpath(groupSectionXpath + "//label[normalize-space()='Import']");
    public static final By exportGroups = By.id("sampleFile");

}
