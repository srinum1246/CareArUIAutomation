package webElements;

import org.openqa.selenium.By;

public interface DashboardPages {

	
	public static final By dashboardClick = By.cssSelector("div.sidebar ul.nav>li:nth-child(6)");
	public static final By dashboardUsers=By.xpath("//ul[@class='nav']/li[6]/ul/li[1]/span");
	public static final By dashboardUsage=By.xpath("//ul[@class='nav']/li[6]/ul/li[2]/span");
	public static final By dashboardKPI=By.xpath("//ul[@class='nav']/li[6]/ul/li[3]/span");
	
	//inside dashboard Users/usage
	public static final By totalActiveUsers=By.xpath("//div[@class='text-white bg-success card']/div[@class='card-body']/small");
	public static final By totalMinutesUsed=By.xpath("//div[@class='text-white bg-primary card']/div[@class='card-body']/small");
	
	//table check run from 1 to 3
	public static final String tableNav1="//div[@class='userCallerDetailsTableAndChart row']/div[1]/div/div/span/div[2]/span/div/table/thead/tr/th[";
	public static final String tableNav2="]/div";
	//only for dashboard users
	public static final By top10ActiveUsers=By.xpath("//div[@class='userCallerChart card-body']/div/div/h3");
	
	//dashboard KPI
	public static final By avgRatingScoreHost=By.xpath("//div[@class='row']/div/div[@class='card']/div/div[2]");
	public static final By totalRatingHost=By.xpath("//div[@class='row']/div/div[@class='card']/div/small/div[1]");
	//public static final By rateHost=By.xpath("//div[@class='row']/div/div[@class='card']/div/small/div[2]");
	

	public static final By avgRatingScoreGuest=By.xpath("//div[@class='row']/div[2]/div/div/div[2]");
	public static final By totalRatingGuest=By.xpath("//div[@class='row']/div[2]/div/div/small/div[1]");
	//public static final By rateGuest=By.xpath("//div[@class='row']/div[2]/div/div/small/div[2]");
	
	public static final By export=By.xpath("//div[@style='padding: 10px 0px 16px; display: flex; justify-content: flex-end;']/button");
	
	/*
	 * run from 1 to 5. KPI custom dates
	 */
	public static final String navCustom1="//div[@aria-label='First group']/button[";
	public static final String navCustom2="]";
	
	
	//-------------------------------------------------------------------------------------------
	//-------------------------------------------------------------------------------------------
	/*
	 * USER PORTAL DASHBOARD
	 */
	public static final By clickOnDashboard=By.xpath("//ul[@class='nav']/li[3]/span");
	public static final By sessionHeader=By.xpath("//div[@class='col-sm-5']/div");
	public static final By noOfRemoteSessions=By.xpath("//div[@class='pb-0 card-body']/div[2]");
	public static final By noOfMinutesUsed=By.xpath("//div[@class='row']/div[2]/div/div/div[2]");
}
