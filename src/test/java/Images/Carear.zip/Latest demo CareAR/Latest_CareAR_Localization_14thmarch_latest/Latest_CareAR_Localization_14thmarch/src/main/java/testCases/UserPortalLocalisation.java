package testCases;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import libraryFunctions.JSONRead;
import libraryFunctions.WebFunctions;
import webElements.Admin_WelcomePage;
import webElements.DashboardPages;
import webElements.LoginPage;
import webElements.MyProfilePage;
import webElements.SessionActivityPage;
import webElements.SessionMapPage;

public class UserPortalLocalisation {

	static int choice=0;
	static String jsonPath=null;
	
	public static void userPortalLocalisation(WebDriver driver, String jsonPathOfFile, int choiceOfLang) throws Exception
	{
	choice=choiceOfLang;
	jsonPath=jsonPathOfFile;
	
		driver.get("https://carear-development.web.app/#/user/login");
		//driver.get("https://carear-qa.web.app/#/user/login");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		driver.findElement(LoginPage.User_Email).sendKeys("aakashdev.sriv2@gmail.com");//aakashdev.sriv2@gmail.com
		driver.findElement(LoginPage.User_Password).sendKeys("Password1");
		driver.findElement(LoginPage.User_LoginButton).click();
		System.out.println("clicked on login button");
		
		System.out.println("\n\n"+"VALIDATING MY PROFILE PAGE"+"\n");
		userPortalMyProfile(driver);
		System.out.println("\n\n"+"VALIDATING DASHBOARD PAGE"+"\n");
		userPortalDashboard(driver);
		System.out.println("\n\n"+"VALIDATING SESSION MAP PAGE"+"\n");
		userPortalSessionMap(driver);
		System.out.println("\n\n"+"VALIDATING SESSION ACTIVITY PAGE"+"\n");
		userPortalSessionActivity(driver);
		
		System.out.println("\n-------VALIDATION CONCLUDED-------");

		driver.close();

	}
	
	public static void userPortalMyProfile(WebDriver driver) throws Exception
	{
		WebFunctions.explicitWait(driver, 20, "Clickable", MyProfilePage.saveButton);
		driver.findElement(Admin_WelcomePage.languageChange).click();
		Thread.sleep(2000);
		
		if(choice==1)
		{
			driver.findElement(Admin_WelcomePage.selectFrench).click();
		}
		else if(choice==2)
		{
			driver.findElement(Admin_WelcomePage.selectGerman).click();
		}
		else if(choice==3)
		{
			driver.findElement(Admin_WelcomePage.selectItalian).click();
		}
		else if(choice==4)
		{
			driver.findElement(Admin_WelcomePage.selectPortugese).click();
		}
		else if(choice==5)
		{
			driver.findElement(Admin_WelcomePage.selectSpanish).click();
		}
				
		Thread.sleep(2000);

		driver.findElement(Admin_WelcomePage.saveLanguage).click();
		Thread.sleep(3000);
		
		String elements[] = { "email", "name", "jobDescription", "phoneNumber" };

		for (int i = 1; i <= 4; i++) {
			String index = Integer.toString(i);
			String path = MyProfilePage.myProfileNav1 + index + MyProfilePage.myProfileNav2;
			String portalText = driver.findElement(By.xpath(path)).getText();
			String savedText = JSONRead.readJSON(jsonPath, elements[i - 1]);
			textValidation(portalText, savedText, elements[i - 1]);
		}
		String portalText = driver.findElement(MyProfilePage.saveButton).getText();
		String savedText = JSONRead.readJSON(jsonPath, "save");
		if(portalText.contains(savedText))
		textValidation(savedText, savedText, "Save");
		
		portalText = driver.findElement(MyProfilePage.versionButton).getText();
		savedText = JSONRead.readJSON(jsonPath, "version");
		if(portalText.contains(savedText))
		textValidation(savedText, savedText, "version");
		else
			textValidation(portalText, savedText, "version");

		
		portalText = driver.findElement(MyProfilePage.Userlogout).getText();
		savedText = JSONRead.readJSON(jsonPath, "logout");
		textValidation(portalText, savedText, "logout");
		
		portalText = driver.findElement(MyProfilePage.chooseFile).getText();
		savedText = JSONRead.readJSON(jsonPath, "chooseFile");
		textValidation(portalText, savedText, "chooseFile");
		
		/*
		 * portalText = driver.findElement(MyProfilePage.noFileChosen).getText();
		 * savedText = JSONRead.readJSON(jsonPath, "chooseFile");
		 * textValidation(portalText, savedText, "chooseFile");
		 */
		
		portalText = driver.findElement(MyProfilePage.upload).getText();
		savedText = JSONRead.readJSON(jsonPath, "upload");
		textValidation(portalText, savedText, "upload");
		
		validateFooter(driver);
	}
	
	public static void userPortalDashboard(WebDriver driver) throws Exception
	{
		 String portalText=null;
		 String savedText=null;
		driver.findElement(DashboardPages.clickOnDashboard).click();
		Thread.sleep(4000);
		WebFunctions.explicitWait(driver, 20, "VISIBILITY", DashboardPages.sessionHeader);
		
		 String elements2[] = {"lastSevenDays","lastThirtyDays","lastTwelveMonths","currentBillingCycle",
		  "customDate"}; 
			for (int i = 1; i <= 5; i++) { 
				String index = Integer.toString(i);
				String path = DashboardPages.navCustom1 + index + DashboardPages.navCustom2;
			 portalText = driver.findElement(By.xpath(path)).getText(); 
			savedText =JSONRead.readJSON(jsonPath, elements2[i - 1]);
			  textValidation(portalText,savedText, elements2[i - 1]); }
			
			portalText = driver.findElement(DashboardPages.noOfRemoteSessions).getText();
			savedText = JSONRead.readJSON(jsonPath, "remoteSessionsBetweenHostGuest");
			textValidation(portalText, savedText, "remoteSessionsBetweenHostGuest");
			
			portalText = driver.findElement(DashboardPages.noOfMinutesUsed).getText();
			savedText = JSONRead.readJSON(jsonPath, "numOfMinsUsed");
			textValidation(portalText, savedText, "numOfMinsUsed");
			
			portalText = driver.findElement(DashboardPages.sessionHeader).getText();
			savedText = JSONRead.readJSON(jsonPath, "sessionActivity");
			textValidation(portalText, savedText, "sessionActivity");
			
			validateFooter(driver);
	}
	
	public static void userPortalSessionMap(WebDriver driver) throws Exception
	{
		String portalText;
		String savedText;
		driver.findElement(SessionMapPage.clickOnSessionMapUser).click();
		Thread.sleep(4000);
		portalText = driver.findElement(SessionMapPage.sessionMap).getText();
		savedText = JSONRead.readJSON(jsonPath, "sessionMap");
		textValidation(portalText, savedText, "sessionMap");
		
		portalText = driver.findElement(SessionMapPage.seeActivityInTable).getText();
		savedText = JSONRead.readJSON(jsonPath, "seeActivityInTable");
		textValidation(portalText, savedText, "seeActivityInTable");
		
		portalText = driver.findElement(SessionMapPage.host).getText();
		savedText = JSONRead.readJSON(jsonPath, "host");
		textValidation(portalText, savedText, "host");
		
		portalText = driver.findElement(SessionMapPage.guest).getText();
		savedText = JSONRead.readJSON(jsonPath, "guest");
		textValidation(portalText, savedText, "guest");
		
		portalText = driver.findElement(SessionMapPage.groupMarkers).getText();
		savedText = JSONRead.readJSON(jsonPath, "groupMarkers");
		textValidation(portalText, savedText, "groupMarkers");
		
		//mapZoomInstruction
		
		portalText = driver.findElement(SessionMapPage.controlScrollText).getText();
		savedText = JSONRead.readJSON(jsonPath, "mapZoomInstruction");
		textValidation(portalText, savedText, "mapZoomInstruction");
		
		
		String elements[] = { "today","thisWeek","thisMonth","customDate"};
		for (int i = 1; i <= 4; i++) {
			String index = Integer.toString(i);
			String path = SessionMapPage.navTabs1 + index + SessionMapPage.navTabs2;
			portalText = driver.findElement(By.xpath(path)).getText();
			savedText = JSONRead.readJSON(jsonPath, elements[i - 1]);
			textValidation(portalText, savedText, elements[i - 1]);
		}
		Thread.sleep(3000);
		driver.findElement(SessionMapPage.custom).click();
		Thread.sleep(3000);
		
		portalText = driver.findElement(SessionMapPage.from).getText();
		savedText = JSONRead.readJSON(jsonPath, "from");
		textValidation(portalText, savedText, "from");
		
		portalText = driver.findElement(SessionMapPage.to).getText();
		savedText = JSONRead.readJSON(jsonPath, "to");
		textValidation(portalText, savedText, "to");
		
		
		String elements1[] = { "search","clear"};
		for (int i = 1; i <= 2; i++) {
			String index = Integer.toString(i);
			String path = SessionMapPage.searchClear1 + index + SessionMapPage.searchClear2;
			portalText = driver.findElement(By.xpath(path)).getText();
			savedText = JSONRead.readJSON(jsonPath, elements1[i - 1]);
			textValidation(portalText, savedText, elements1[i - 1]);
		}
		validateFooter(driver);
		
	}
	
	public static void userPortalSessionActivity(WebDriver driver) throws Exception
	{
		driver.findElement(SessionActivityPage.clickOnSessionActivityUser).click();
		Thread.sleep(4000);
		
		WebFunctions.explicitWait(driver, 20, "CLICKABLE", SessionActivityPage.userPortal);
		WebFunctions.explicitWait(driver, 20, "Visibility", SessionActivityPage.poweredByCareAr);
		Thread.sleep(3000);

		// navtabs validation : Today/This week/This Month/Custom Date
		String elements[] = { "today", "thisWeek", "thisMonth", "customDate" };

		for (int i = 1; i <= 4; i++) {
			String index = Integer.toString(i);
			String path = SessionActivityPage.navTabs1 + index + SessionActivityPage.navTabs2;
			String portalText = driver.findElement(By.xpath(path)).getText();
			String savedText = JSONRead.readJSON(jsonPath, elements[i - 1]);
			textValidation(portalText, savedText, elements[i - 1]);
		}

		String elements1[] = { "startTime", "duration", "host", "guests", "group" };
		for (int i = 2; i <= 6; i++) {
			String index = Integer.toString(i);
			String path = SessionActivityPage.tableHeader1 + index + SessionActivityPage.tableHeader2;
			String portalText = driver.findElement(By.xpath(path)).getText();
			String savedText = JSONRead.readJSON(jsonPath, elements1[i - 2]);
			textValidation(portalText, savedText, elements1[i - 2]);
		}

		String portalText = driver.findElement(SessionActivityPage.rowsPerPage).getText();
		String savedText = JSONRead.readJSON(jsonPath, "rowsPerPage");
		if(portalText.contains(savedText))
		textValidation(savedText, savedText, "rowsPerPage");

		portalText = driver.findElement(SessionActivityPage.termsOfService).getText();
		savedText = JSONRead.readJSON(jsonPath, "termsOfService");
		textValidation(portalText, savedText, "termsOfService");

		portalText = driver.findElement(SessionActivityPage.privacyPolicy).getText();
		savedText = JSONRead.readJSON(jsonPath, "privacyPolicy");
		textValidation(portalText, savedText, "privacyPolicy");

		portalText = driver.findElement(SessionActivityPage.poweredByCareAr).getText();
		savedText = JSONRead.readJSON(jsonPath, "poweredByCareAR");
		if(portalText.contains(savedText))
		textValidation(savedText, savedText, "poweredByCareAR");

		portalText = driver.findElement(SessionActivityPage.sessionImages).getText();
		savedText = JSONRead.readJSON(jsonPath, "sessionImages");
		textValidation(portalText, savedText, "sessionImages");

		

		/*
		 * validating CUSTOM DATE SECTION
		 * 
		 */

		System.out.println("\n");
		System.out.println("------------INITIATING VALIDATION FOR SESSION ACTIVITY > CUSTOM DATE SECTION----------");
		System.out.println("\n");
		driver.findElement(SessionActivityPage.CustomDate).click();
		Thread.sleep(3000);

		portalText = driver.findElement(SessionActivityPage.from).getText();
		savedText = JSONRead.readJSON(jsonPath, "from");
		textValidation(portalText, savedText, "from");

		portalText = driver.findElement(SessionActivityPage.to).getText();
		savedText = JSONRead.readJSON(jsonPath, "to");
		textValidation(portalText, savedText, "to");

		portalText = driver.findElement(SessionActivityPage.search).getText();
		savedText = JSONRead.readJSON(jsonPath, "search");
		textValidation(portalText, savedText, "search");

		portalText = driver.findElement(SessionActivityPage.clear).getText();
		savedText = JSONRead.readJSON(jsonPath, "clear");
		textValidation(portalText, savedText, "clear");

		portalText = driver.findElement(SessionActivityPage.seeActivityInMap).getText();
		savedText = JSONRead.readJSON(jsonPath, "seeActivityInMap");
		textValidation(portalText, savedText, "seeActivityInMap");

		Thread.sleep(2000);
		validateFooter(driver);
	}
	
	public static void validateFooter(WebDriver driver)
	{
		String portalText=null;
	String savedText=null;
	
	portalText = driver.findElement(SessionActivityPage.careAR).getText();
	savedText = "CAREAR";
	textValidation(portalText, savedText, "termsOfService");
	
		portalText = driver.findElement(SessionActivityPage.termsOfService).getText();
		savedText = JSONRead.readJSON(jsonPath, "termsOfService");
		textValidation(portalText, savedText, "termsOfService");

		portalText = driver.findElement(SessionActivityPage.privacyPolicy).getText();
		savedText = JSONRead.readJSON(jsonPath, "privacyPolicy");
		textValidation(portalText, savedText, "privacyPolicy");

		portalText = driver.findElement(SessionActivityPage.poweredByCareAr).getText();
		savedText = JSONRead.readJSON(jsonPath, "poweredByCareAR");
		if(portalText.contains(savedText))
		textValidation(savedText, savedText, "poweredByCareAR");
	}
	
public static void textValidation(String portalText, String savedText, String target) {
		
		if (portalText.equalsIgnoreCase(savedText)) {
			System.out.println("SUCCESSFUL. Portal text is-> " + portalText + " ||  Saved text is-> " + savedText);
		} else {
			System.out.println("UNSUCCESSFUL. Portal text is-> " + portalText + "||  Saved text is-> " + savedText);
		}

	}
}