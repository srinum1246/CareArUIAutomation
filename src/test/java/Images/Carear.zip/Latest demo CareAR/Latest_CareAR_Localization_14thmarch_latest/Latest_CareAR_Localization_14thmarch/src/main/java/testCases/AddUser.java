package testCases;

import java.util.ArrayList;
import java.util.List;

public class AddUser 
{
	String email="";
	String fname="";
	String lname="";
	String pphn="";
	String sphn="";
	String jd="";
	public AddUser(String email, String fname, String lname, String pphn, String sphn, String jd)
	{
		this.email=email;
		this.fname=fname;
		this.lname=lname;
		this.pphn=pphn;
		this.sphn=sphn;
		this.jd=jd;
		
	}
	
	public static void main(String args[])
	{
		AddUser au1=new AddUser("kp1@test.com","ab","bc","9876543215","8975642313","test");
		AddUser au2=new AddUser("kp2@test.com","ab","bc","9876543215","8975642313","test");
		AddUser au3=new AddUser("kp3@test.com","ab","bc","9876543215","8975642313","test");
		AddUser au4=new AddUser("kp4@test.com","ab","bc","9876543215","8975642313","test");
		AddUser au5=new AddUser("kp5@test.com","ab","bc","9876543215","8975642313","test");
		AddUser au6=new AddUser("kp6@test.com","ab","bc","9876543215","8975642313","test");
		AddUser au7=new AddUser("kp7@test.com","ab","bc","9876543215","8975642313","test");
		AddUser au8=new AddUser("kp8@test.com","ab","bc","9876543215","8975642313","test");
		AddUser au9=new AddUser("kp9@test.com","ab","bc","9876543215","8975642313","test");
		AddUser au10=new AddUser("kp10@test.com","ab","bc","9876543215","8975642313","test");
		
		List<AddUser> newUsers=new ArrayList<AddUser>();
		newUsers.add(au1);
		newUsers.add(au2);
		newUsers.add(au3);
		newUsers.add(au4);
		newUsers.add(au5);
		newUsers.add(au6);
		newUsers.add(au7);
		newUsers.add(au8);
		newUsers.add(au9);
		newUsers.add(au10);
		
		System.out.println(newUsers.get(0).email);
	}
	
}
