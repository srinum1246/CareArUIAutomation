package testCases;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;
import libraryFunctions.WebFunctions;
import webElements.Admin_WelcomePage;
import webElements.LoginPage;
import webElements.MyCompanyPage;

public class MyCompany {

	static String jsonPath =null;
	static String choice="";
	public static ExtentReports extent;
	public static ExtentTest test;
	public static void main(String args[]) throws Exception {

		String paths[]= {"./src//main//java//localizationVocabs//French.json", "./src//main//java//localizationVocabs//German.json","./src//main//java//localizationVocabs//Italian.json","./src//main//java//localizationVocabs//Portuguese.json","./src//main//java//localizationVocabs//Spanish.json","./src//main//java//localizationVocabs//Indonesian.json","./src//main//java//localizationVocabs//Japanese.json","./src//main//java//localizationVocabs//Malay.json","./src//main//java//localizationVocabs//Chinese.json" };
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Language name which you want to run");
		//int n=s.nextInt();
		String languageName=s.next();
		WebDriverManager.chromedriver().setup();
		ChromeOptions options= new ChromeOptions();
		options.addArguments("--no-sandbox");
		options.addArguments("--disable-dev-shm-usage");
		//options.addArguments("--headless");
		options.addArguments("--disable-gpu");
		options.addArguments("--allow-insecure-localhost");
		String reportPath = System.getProperty("user.dir")+"\\reports\\reports.html";
		ExtentSparkReporter es = new ExtentSparkReporter(reportPath);
		es.config().setDocumentTitle("CareAR");
		es.config().setReportName("Localization");
		extent = new ExtentReports();
		extent.attachReporter(es);
		int j=1, i=1;
		while(i<=j) {

		// if(i<=1) {
				//  jsonPath = paths[i - 1];
			 choice = languageName;

				  //System.setProperty("webdriver.chrome.driver","./src//main//java//configuration//chromedriver.exe");
				  WebDriver driver = new ChromeDriver(options);
				  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				  validateLocalization(driver, languageName,j);
				  System.out.println("\n\n\n\n" + "-X-X-X-X-X-X-X-X-X-X-X-X-X-X");
				  i++;
				  Thread.sleep(5000);
		  }
		 
		
		i=1;
		
	}

public static void validateLocalization(WebDriver driver, String langName,int j) throws Exception {
		
	switch (langName.toLowerCase()) {
	case "english":
		test = extent.createTest("English");
		break;
	
	case "french":
		test = extent.createTest("French");
		break;
	case "german":
		test = extent.createTest("German");
		break;
	case "italian":
		test = extent.createTest("Italian");
		break;
	case "portugese":
		test = extent.createTest("Portugese");
		break;
	case "spanish":
		test = extent.createTest("Spanish");
		break;
	case "indonesian":
		test = extent.createTest("Indonesian");
		break;
	case "japanese":
		test = extent.createTest("Japanese");
		break;
	case "malay":
		test = extent.createTest("Malay");
		break;
	case "chinese":
		test = extent.createTest("Chinese");
		break;
	
	}	
		//String elements[] = { "users", "kpis", "sessionActivity", "sessionMap", "dashboard", "myProfile", "myCompany" };

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get("https://carear-development.web.app/#/admin/login");
		Thread.sleep(3000);
		driver.manage().window().maximize();

		driver.findElement(LoginPage.Ad_Email).sendKeys("kumarvikramg16@gmail.com");   //alandev.sriv@xerox.com  // regressiontest@xerox.com
		driver.findElement(LoginPage.Ad_Password).sendKeys("@Pandu123");
		driver.findElement(LoginPage.Ad_LoginButton).click();
		System.out.println("clicked on login button");
		WebFunctions.explicitWait(driver, 20, "Visibility", Admin_WelcomePage.waitElement);
		Thread.sleep(8000);


		driver.findElement(Admin_WelcomePage.languageChange).click();
		Thread.sleep(2000);
		if(choice.equalsIgnoreCase("English"))
		{
			driver.findElement(Admin_WelcomePage.selectEnglish).click();
			System.out.println("\n\n\n Selected English \n\n");
		}
		
		else if(choice.equalsIgnoreCase("French"))
		{
			driver.findElement(Admin_WelcomePage.selectFrench).click();
			System.out.println("\n\n\n Selected FRENCH \n\n");
		}
		else if(choice.equalsIgnoreCase("German"))
		{
			driver.findElement(Admin_WelcomePage.selectGerman).click();
			System.out.println("\n\n\n Selected GERMAN \n\n");
		}
		else if(choice.equalsIgnoreCase("Italian"))
		{
			driver.findElement(Admin_WelcomePage.selectItalian).click();
			System.out.println("\n\n\n Selected ITALIAN \n\n");
		}
		else if(choice.equalsIgnoreCase("Portugese"))
		{
			driver.findElement(Admin_WelcomePage.selectPortugese).click();
			System.out.println("\n\n\n Selected PORTUGUESE \n\n");
		}
		else if(choice.equalsIgnoreCase("Spanish"))
		{
			driver.findElement(Admin_WelcomePage.selectSpanish).click();
			System.out.println("\n\n\n Selected SPANISH \n\n");
		}
		else if(choice.equalsIgnoreCase("Indonesian"))
		{
			driver.findElement(Admin_WelcomePage.selectIndonesian).click();
			System.out.println("\n\n\n Selected INDONESIAN \n\n");
		}
		else if(choice.equalsIgnoreCase("Japanese"))
		{
			driver.findElement(Admin_WelcomePage.selectJapanese).click();
			System.out.println("\n\n\n Selected JAPANESE \n\n");
		}
		else if(choice.equalsIgnoreCase("Malay"))
		{
			driver.findElement(Admin_WelcomePage.selectMalay).click();
			System.out.println("\n\n\n Selected MALAY \n\n");
		}
		else if(choice.equalsIgnoreCase("Chinese"))
		{
			driver.findElement(Admin_WelcomePage.selectChinese).click();
			System.out.println("\n\n\n Selected CHINESE \n\n");
		}
				
		Thread.sleep(2000);

		driver.findElement(Admin_WelcomePage.saveLanguage).click();
		Thread.sleep(3000);

		System.out.println("\n\n");
		System.out.println("------------INITIATING VALIDATION FOR My Company page fields----------");
		test.info("------------INITIATING VALIDATION FOR My Company page fields----------");
		System.out.println("\n");

		
		myCompanyValidation(driver);
		serviceNowControls(driver);
		Thread.sleep(2000);
		amzonS3ConfigValidation(driver);
		groups(driver);
		mediaGEOFencing(driver);
		
	
		System.out.println("-------VALIDATION CONCLUDED-------");
		test.info("-------VALIDATION CONCLUDED-------");

		driver.close();
		//if (langCount == j) {
			extent.flush();
		//}
	}

public static void myCompanyValidation(WebDriver driver)throws Exception {

	driver.findElement(MyCompanyPage.fileLocation).click();
	Thread.sleep(1000);
	fileUpload("C:\\Users\\pavan\\Downloads\\Latest_CareAR_NewLocalization\\Latest_CareAR_NewLocalization1\\Latest_CareAR_Localization\\src\\main\\java\\localizationVocabs\\logos1");
	Thread.sleep(8000);
	driver.findElement(MyCompanyPage.fileLocation).click();
	Thread.sleep(1000);
	
	fileUpload("C:\\Users\\pavan\\Downloads\\Latest_CareAR_NewLocalization\\Latest_CareAR_NewLocalization1\\Latest_CareAR_Localization\\src\\main\\java\\localizationVocabs\\logos.jpg");
	Thread.sleep(2000);
	driver.findElement(MyCompanyPage.upload).click();
	Thread.sleep(10000);
	
	/*WebDriverWait wait=new WebDriverWait(driver,60);
	if(wait.until(ExpectedConditions.alertIsPresent())==null)
	{
		test.info("-------VALIDATION CONCLUDED-------");
		test.fail("Alert is not present");
	}
	else
	{
		String alertMessage=driver.switchTo().alert().getText();
		portalText = driver.findElement(DashboardPages.totalActiveUsers).getText();
		savedText = JSONRead.readJSON(jsonPath, "imageUploadError");
		textValidation(alertMessage, savedText, "imageUploadError");
		
	}*/
	test.info("-------UPLOAD IMAGE VALIDATION CONCLUDED-------");
	
}

public static void fileUpload(String s)throws Exception
{
	StringSelection ss=new StringSelection(s);
	Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
	Robot r=new Robot();
	r.keyPress(KeyEvent.VK_ENTER);
	r.keyRelease(KeyEvent.VK_ENTER);
	r.keyPress(KeyEvent.VK_CONTROL);
	r.keyPress(KeyEvent.VK_V);
	r.keyRelease(KeyEvent.VK_V);
	r.keyRelease(KeyEvent.VK_CONTROL);
	Thread.sleep(2000);
	r.keyPress(KeyEvent.VK_ENTER);
	r.keyRelease(KeyEvent.VK_ENTER);

}

public static void serviceNowControls(WebDriver driver)throws Exception
{
	driver.findElement(MyCompanyPage.tbxServicenowAPIUname).sendKeys("carear");
	driver.findElement(MyCompanyPage.tbxServicenowPWD).sendKeys("Carear@1234");
	driver.findElement(MyCompanyPage.servicenowSave).click();
	Thread.sleep(3000);
	//String s=driver.findElement(MyCompanyPage.unamePwdRequired).getText();
	//String jsonTranslation=JSONRead.readJSON(jsonPath, "unamepwdrequired");
	//textValidation(s, jsonTranslation, "unamepwdrequired");
	Thread.sleep(5000);
	
}

public static void amzonS3ConfigValidation(WebDriver driver)throws Exception {
	
Thread.sleep(3000);	

if(driver.findElement(MyCompanyPage.cbxEnableVideoRecording).isSelected())
{
	driver.findElement(MyCompanyPage.tbxAmazonS3BucketName).click();
	driver.findElement(MyCompanyPage.tbxAmazonS3BucketName).clear();
	//	driver.findElement(By.xpath("(//*[@class='mediaGeofenceSettingContainer']/form/div/div[2]/input)[3]")).clear();
	
	Thread.sleep(3000);

	driver.findElement(MyCompanyPage.btnAmazonS3ConfigSave).click();
	Thread.sleep(8000);
	driver.findElement(By.xpath("(//*[@class='btn btn-primary'])[5]")).click();
}
else
{
	driver.findElement(MyCompanyPage.cbxEnableVideoRecording).click();
	Thread.sleep(3000);
	driver.findElement(MyCompanyPage.tbxAmazonS3BucketName).click();
	driver.findElement(MyCompanyPage.tbxAmazonS3BucketName).clear();
	//driver.findElement(By.xpath("(//*[@class='mediaGeofenceSettingContainer']/form/div/div[2]/input)[3]")).clear();
	
	Thread.sleep(3000);

	driver.findElement(MyCompanyPage.btnAmazonS3ConfigSave).click();
	Thread.sleep(8000);
	driver.findElement(By.xpath("(//*[@class='btn btn-primary'])[5]")).click();

}
System.out.println("Second Scenario completed");

driver.findElement(MyCompanyPage.tbxAmazonS3BucketName).clear();
driver.findElement(MyCompanyPage.tbxAmazonS3BucketName).sendKeys("Test");
if(driver.findElement(MyCompanyPage.cbxEnableVideoRecording).isSelected())
{
	driver.findElement(MyCompanyPage.cbxEnableVideoRecording).click();
	driver.findElement(MyCompanyPage.btnAmazonS3ConfigSave).click();
	Thread.sleep(12000);
}
else
{
	driver.findElement(MyCompanyPage.btnAmazonS3ConfigSave).click();
	Thread.sleep(12000);
}
System.out.println("First Scenario completed");


driver.findElement(MyCompanyPage.tbxAmazonS3BucketName).clear();
if(driver.findElement(MyCompanyPage.cbxEnableVideoRecording).isSelected())
{
	driver.findElement(MyCompanyPage.cbxEnableVideoRecording).click();
	driver.findElement(MyCompanyPage.btnAmazonS3ConfigSave).click();
	Thread.sleep(8000);
}
else
{
	driver.findElement(MyCompanyPage.btnAmazonS3ConfigSave).click();
	Thread.sleep(8000);
	
}

test.info("-------AMAZON S3 CONFIGURATION VALIDATION CONCLUDED-------");


}

public static void groups(WebDriver driver)throws Exception {
	
   String validText="T22";
   String errorText="&@";
   
    driver.findElement(MyCompanyPage.groupAdd).click();
	Thread.sleep(2000);
	driver.findElement(MyCompanyPage.groupName).sendKeys(errorText);
	driver.findElement(MyCompanyPage.groupNameAdd).click();
	Thread.sleep(5000);
	driver.findElement(MyCompanyPage.groupAdd).click();
	Thread.sleep(5000);
	driver.findElement(MyCompanyPage.groupName).sendKeys(validText);
	driver.findElement(MyCompanyPage.groupNameAdd).click();
	Thread.sleep(10000);
	List<WebElement> groupNameList=driver.findElements(MyCompanyPage.groupNameList);
	   
	for(int i=0;i<groupNameList.size();i++)
	{
		if(groupNameList.get(i).getText().equalsIgnoreCase(validText))
		{
			test.pass("New Group "+validText+" successfully added");
			groupNameList.get(i).click();
			driver.findElement(MyCompanyPage.groupDelete).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("(//*[@class='btn btn-primary'])[5]")).click();
			Thread.sleep(8000);
			
			break;
		}
	}
	
	List<WebElement> groupNameList1=driver.findElements(MyCompanyPage.groupNameList);
	
	   for(int i=0;i<groupNameList1.size();i++)
	{
	
	if(!groupNameList1.get(i).getText().equalsIgnoreCase("T22"))
	{
		if(i==groupNameList1.size()-1)
		{
		test.pass("New Group "+validText+" deleted successfully");
		}
	}
	else
	{
		test.fail("New Group "+validText+" not deleted successfully");
	}
	}
	test.info("-------GROUPS VALIDATION CONCLUDED-------");
	
    
}

public static void mediaGEOFencing(WebDriver driver)throws Exception {

	Thread.sleep(8000);
	Select s1=new Select(driver.findElement(MyCompanyPage.ddHostMediaRegion));
	Select s2=new Select(driver.findElement(MyCompanyPage.ddGuestMediaRegion));
	
	s1.selectByIndex(0);
	s2.selectByIndex(0);
	
	proxySelect(driver,0);
	driver.findElement(MyCompanyPage.proxySave).click();
	Thread.sleep(10000);
	
	proxySelect(driver,1);
	driver.findElement(MyCompanyPage.proxySave).click();
	Thread.sleep(5000);
	test.info("-------PROXY VALIDATION CONCLUDED-------");
	
}

public static void proxySelect(WebDriver driver,int i)throws Exception {

	Select hostProxy=new Select(driver.findElement(MyCompanyPage.ddHostProxy));
	Select guestProxy=new Select(driver.findElement(MyCompanyPage.ddGuestProxy));
	Select encryption=new Select(driver.findElement(MyCompanyPage.ddEncryption));
	Select guestJoinByUser=new Select(driver.findElement(MyCompanyPage.ddGuestJoinByUser));
	Select guestJoinBySmartGlass=new Select(driver.findElement(MyCompanyPage.ddGuestJoinBySmartGlass));
	
	hostProxy.selectByIndex(i);
	guestProxy.selectByIndex(i);
	encryption.selectByIndex(i);
	guestJoinByUser.selectByIndex(i);
	guestJoinBySmartGlass.selectByIndex(i);
	
	
	

}

public static void textValidation(String portalText, String savedText, String target) {
	
	String portalText1[] = portalText.split("\n");
	portalText = portalText1[0];
	portalText = portalText.trim();
	if (portalText.equalsIgnoreCase(savedText)) {
		System.out.println("SUCCESSFUL. Portal text is-> " + portalText + " ||  Saved text is-> " + savedText);
		//test.log(, "Portal text is-> " + portalText + " ||  Saved text is-> " + savedText);
		//test.info("SUCCESSFUL. Portal text is-> " + portalText + " ||  Saved text is-> " + savedText);
		test.pass("SUCCESSFUL. Portal text is-> " + portalText + " ||  Saved text is-> " + savedText);
		//test.log
	} else {
		System.out.println("UNSUCCESSFUL. Portal text is-> " + portalText + "||  Saved text is-> " + savedText);
		//test.info("UNSUCCESSFUL. Portal text is-> " + portalText + "||  Saved text is-> " + savedText);
		test.fail("UNSUCCESSFUL. Portal text is-> " + portalText + "||  Saved text is-> " + savedText);
	}

}

}
