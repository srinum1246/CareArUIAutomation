package webElements;

import org.openqa.selenium.By;

public interface KPIPage {

	public static final By clickKPI = By.cssSelector("div.sidebar ul.nav>li:nth-child(3)");
	public static final By addNewKPI=By.xpath("//span[@class='add-surveys ']/h4");
	//public static final By addNewKPIButton=By.xpath("//span[@id='linkToCreateUser']/a/i");
	
	public static final By addNewKPIButton=By.xpath("//*[@class='btn btn-link plus-button']/i");
	
	/*run from
	1 to 5
	*/
	public static final String labelsOnAddKPI1="//form[@class='needs-validation novalidate']/div/div/div[";
	public static final String labelsOnAddKPI2="]/label";
	/*
	submit and cancel button
	run from 1 to 2
	*/
	public static final String submitCancel1="//form[@class='needs-validation novalidate']/div/div/div[6]/div[";
	public static final String submitCancel2="]/button";
	
	/*
	Mandatory/optional
	run from 1 to 2
	*/
	public static final String mandatoryOptional1="//form[@class='needs-validation novalidate']/div/div/div[3]/div/label[";
	public static final String mandatoryOptional2="]";
	
	/*
	 * type=rating, dropdown, singleline,multiline run from 1 to 4
	 */
	public static final String type1="//form[@class='needs-validation novalidate']/div/div/div[4]/div/label[";
	public static final String type2="]";
	
	/*
	 * Host and guest Run from 1 to 2
	 */
	public static final String userType1="//form[@class='needs-validation novalidate']/div/div/div[5]/div/label[";
	public static final String userType2="]";
	
	
	/*
	 * table headers run 2 to 8
	 */
	public static final String tableHeaders1="//*[@id=\"tableHeader\"]/div/table/thead/tr/th[";
	public static final String tableHeaders2="]";

	public static final By questionInput = By.id("inputQuestion");
	public static final By userTypeDropDown = By.cssSelector("#surveysInfo #filterDropDown0");
	public static final By pagesDropDown = By.cssSelector("#surveysInfo .right-FilterContainer select");
	public static final By userTypeTableCell = By.cssSelector("#surveysInfo table tbody td:nth-child(3)");
	public static final By kpiDataRows = By.cssSelector("#surveysInfo table tbody>tr");
	public static final By searchKPIInput = By.cssSelector("form.add-user input");

}
