package webElements;

import org.openqa.selenium.By;

public interface FooterElements {

	public static final By careAR=By.xpath("//footer[@class='app-footer']/div/span[1]");
	public static final By termsOfService=By.xpath("//footer[@class='app-footer']/div/span[2]");
	public static final By privacyPolicy=By.xpath("//footer[@class='app-footer']/div/span[3]");
	public static final By poweredByCareAr=By.xpath("//span[@class='mobile-footer-responsive ml-auto']");
}
