package libraryFunctions;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class JSONRead {

	/*
	 * public static void main(String args[]) { System.out.println(JSONRead.
	 * readJSON("C:\\Open Source Softwares\\Workspace\\CareARWebPortalAutomation\\src\\main\\java\\localizationVocabs\\Spanishcommon.json"
	 * ,"march")); }
	 */
	public static String readJSON(String filepath, String find)
	{
		boolean search=false;
		String returnVal=null;
		try {
			JSONObject obj = (JSONObject) new JSONParser().parse(new FileReader(filepath));
			Set keyset =obj.keySet();
			Iterator itr=keyset.iterator();
			
			while(itr.hasNext())
			{
				String obj2= (String)itr.next();
				//System.out.println("XOXOXOXOXOXO--------Object picked :"+obj2);
				JSONObject insideObj= (JSONObject)obj.get(obj2);
				Set locator=insideObj.keySet();
				Iterator itr2=locator.iterator();
				while(itr2.hasNext())
				{
					String next=(String)itr2.next();
					if(next.toLowerCase().trim().equals(find.toLowerCase().trim()))
					{
						search=true;
						returnVal=(String)insideObj.get(find);
						break;
					}
				}
				if(search==true)
				{
					break;
				}
				
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return returnVal;
	}
}
