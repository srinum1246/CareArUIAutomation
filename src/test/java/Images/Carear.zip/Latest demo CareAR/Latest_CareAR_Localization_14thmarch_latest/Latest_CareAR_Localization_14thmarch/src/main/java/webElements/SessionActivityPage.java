package webElements;

import org.openqa.selenium.By;

public interface SessionActivityPage {

	public static final By sessionActivityNav = By.cssSelector("div.sidebar ul.nav>li:nth-child(4)");
	public static final By sessionActivity=By.xpath("//div[@class='headerContainerRow row']/div/span/h4");
	//from 1 to 4
	public static final String navTabs1="//ul[@class='nav nav-tabs']/li["; 
	public static final String navTabs2="]/a/h6";
	
	public static final By CustomDate=By.xpath("//ul[@class='nav nav-tabs']/li[4]/a/h6");
	
	public static final By rowsPerPage=By.xpath("//div[@class='right-FilterContainer']/span");
	public static final By exportAll=By.xpath("//div[@class='right-FilterContainer']/button");
	//from 2 to 6
	public static final String tableHeader1="//table[@class='table table-responsive-sm table-hover mb-0 table table-hover']/thead/tr/th[";
	public static final String tableHeader2="]/div";
			
	//7
	public static final By sessionImages=By.xpath("//table[@class='table table-responsive-sm table-hover mb-0 table table-hover']/thead/tr/th[7]");
			
	 public static final By userPortal=By.xpath("//ul[@class='ml-auto navbar-nav']/li[2]/button");
	 
	//footer
	public static final By careAR=By.xpath("//footer[@class='app-footer']/div/span[1]");
	public static final By termsOfService=By.xpath("//footer[@class='app-footer']/div/span[2]");
	public static final By privacyPolicy=By.xpath("//footer[@class='app-footer']/div/span[3]");
	public static final By poweredByCareAr=By.xpath("//span[@class='mobile-footer-responsive ml-auto']");
	
	//CustomDate
	public static final By from=By.xpath("//form[@class='customSearchContainer']/div/div[@class='col  mb-3  left-padding-0']/label");
	public static final By to=By.xpath("//form[@class='customSearchContainer']/div/div[@class='col  mb-3']/label");
	public static final By search=By.xpath("//form[@class='customSearchContainer']/div/div[3]/div[1]/button[@class='btn btn-primary  searchButton']");
	public static final By clear=By.xpath("//form[@class='customSearchContainer']/div/div[3]/div[1]/button[@class='btn btn-danger  searchButton']");
	public static final By seeActivityInMap=By.xpath("//form[@class='customSearchContainer']/div/div[3]/div[2]/button");
	
	/*
	 * 
	 * USER PORTAL SA
	 */
	public static final By clickOnSessionActivityUser=By.xpath("//ul[@class='nav']/li[1]/span");
	
}
