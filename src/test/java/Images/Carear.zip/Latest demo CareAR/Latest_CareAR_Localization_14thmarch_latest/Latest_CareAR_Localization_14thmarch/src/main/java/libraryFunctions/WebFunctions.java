package libraryFunctions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebFunctions {

	/*
	 * 
	 * This method is used to launch an automated session in Chrome, firefox and
	 * Edge
	 * 
	 */
	public WebDriver launch(String browser, String url) {
		WebDriver driver = null;
		switch (browser.toUpperCase()) {
		case "CHROME": {
			System.setProperty("webdriver.chrome.driver",
					"C:\\Open Source Softwares\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.get(url);
			break;
		}
		case "FIREFOX": {
			System.setProperty("webdriver.gecko.driver", "");
			driver = new FirefoxDriver();
			driver.get(url);
			break;
		}
		case "EDGE": {
			System.setProperty("webdriver.edge.driver", "C://EdgeDriver.exe");
			driver = new EdgeDriver();
			driver.get(url);
			break;
		}
		default: {
			System.out.println("The driver choice is not yet supported by us.");
		}
		}

		return driver;
	}

	/*
	 * this method is used to put custom wait time for a particular step to get
	 * executed
	 */
	public static void explicitWait(WebDriver driver, int time, String condition, By webElement) {
		WebDriverWait wait = new WebDriverWait(driver, time);
		condition = condition.toUpperCase();
		switch (condition) {
		case "VISIBILITY": {
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(webElement));
			break;
		}
		case "CLICKABLE": {
			wait.until(ExpectedConditions.elementToBeClickable(webElement));
			break;
		}
		default:

		}
	}
}
