package webElements;

import org.openqa.selenium.By;

public interface SessionMapPage {

	public static final By clickSessionMap = By.cssSelector("div.sidebar ul.nav>li:nth-child(5)");
	public static final By sessionMap=By.xpath("//div[@class='headerContainerRow row']/div/span/h4");
	public static final By seeActivityInTable=By.xpath("//div[@class='left-FilterContainer']/button");
	/*
	 * run from 1 to 4
	 */
	public static final String navTabs1="//ul[@class='nav nav-tabs']/li[";
	public static final String navTabs2="]/a/h6";
	
	public static final By host=By.xpath("//div[@class='legend-container']/span/span/label[1]");
	public static final By guest=By.xpath("//div[@class='legend-container']/span/span/label[2]");
	public static final By groupMarkers=By.xpath("//div[@class='legend-container']/span/span[2]/label");
	public static final By controlScrollText=By.xpath("//div[@class='legend-container']/span[2]/label");
	
	//custom Date section
	
	public static final By custom=By.xpath("//ul[@class='nav nav-tabs']/li[4]/a/h6");
	public static final By from=By.xpath("//form[@class='customSearchContainer']/div/div[1]/label");
	public static final By to=By.xpath("//form[@class='customSearchContainer']/div/div[2]/label");
	
	/*
	 * run from 1 to 2 Search /clear
	 */
	
	public static final String searchClear1="//div[@class='col  mb-3  text-left-align mt30 displaySearchBtn']/button[";		
	//public static final String searchClear1="//div[@class='col  mb-3  text-left-align']/button[";
	public static final String searchClear2="]";
	
	/*
	 * USER PORTAL SESSION MAP
	 */
	public static final By clickOnSessionMapUser=By.xpath("//ul[@class='nav']/li[2]/span");
	
}
