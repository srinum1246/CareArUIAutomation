package webElements;

import org.openqa.selenium.By;

public interface RoleManagementPage {

	public static final By clickRoleManagement = By.cssSelector("div.sidebar ul.nav>li:nth-child(2)");
	public static final By roleTableRows = By.cssSelector("#tableHeader table>tbody>tr");
	//Mownima code
	//link
	public static final By roleManagementLink=By.xpath("//div[@class='sidebar']/div/ul/li[2]/button");
	//Page Heading
	public static final By heading=By.xpath("//div[@class='container-fluid']/div/div/div/div/div/span/h4");
	//Table header elements
	public static final By role=By.xpath("//div[@class='table-responsive']/table/thead/tr/th[2]/div");
	public static final By allowsnapshot=By.xpath("//div[@class='table-responsive']/table/thead/tr/th[3]/div");
	public static final By allowmediadownload=By.xpath("//div[@class='table-responsive']/table/thead/tr/th[4]/div");
	public static final By allowrecording=By.xpath("//div[@class='table-responsive']/table/thead/tr/th[5]/div");
	//Role Names
	public static final By adminrole=By.xpath("//tbody/tr[1]/td[2]/div");
	public static final By analystrole=By.xpath("//tbody/tr[2]/td[2]/div");
	public static final By normalrole=By.xpath("//tbody/tr[3]/td[2]/div");
	public static final By guestrole=By.xpath("//tbody/tr[4]/td[2]/div");


}
