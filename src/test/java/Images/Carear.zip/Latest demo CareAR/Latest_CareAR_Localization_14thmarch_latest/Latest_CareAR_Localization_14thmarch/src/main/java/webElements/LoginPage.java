package webElements;
import org.openqa.selenium.By;
public interface LoginPage {

	//Super Admin
	public static final By SA_Email= By.xpath("//*[@id='userNameInput']");
	public static final By SA_Password= By.xpath("//*[@id='passwordInput']");
	public static final By SA_LoginButton=By.xpath("//*[@id='submitInput']");
	public static final By SA_ForgotPassword=By.xpath("//*[@id='forgetPasswordAnchor']");
	public static final String SA_url="https://carear-staging.web.app/#/super/login";
		
	//Admin
	public static final By Ad_Email= By.xpath("//*[@id='userNameInput']");
	public static final By Ad_Password= By.xpath("//*[@id='passwordInput']");
	public static final By Ad_LoginButton=By.xpath("//*[@id='submitInput']");
	public static final By Ad_ForgotPassword=By.xpath("//*[@id='forgetPasswordAnchor']");
	
	//ChangePassword-Admin page
	public static final By passwordOne_change=By.xpath("//input[@id='newPassword']");
	public static final By confirmPassword_change=By.xpath("//input[@id='confirmPassword']");
	public static final By createPassword=By.xpath("//button[@type='submit']");
	
	//User
	public static final By User_Email= By.xpath("//*[@id='userNameInput']");
	public static final By User_Password= By.xpath("//*[@id='passwordInput']");
	public static final By User_LoginButton=By.xpath("//*[@id='submitInput']");
	public static final By User_ForgotPassword=By.xpath("//*[@id='forgetPasswordAnchor']");
}
