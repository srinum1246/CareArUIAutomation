package org.mytests.uiobjects.example.entities;


import com.jdiai.tools.DataClass;

public class MarvelUserInfo extends DataClass<MarvelUserInfo> {
    public String number, type, user, description;
}
