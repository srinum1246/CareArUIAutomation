package testCases;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import io.github.bonigarcia.wdm.WebDriverManager;
import libraryFunctions.JSONRead;
import libraryFunctions.WebFunctions;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import webElements.*;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class LocalizationValidationNew {

    static String jsonPath =null;
    static int choice=0;
    public static ExtentReports extent;
    public static ExtentTest test;
    public static void main(String args[]) throws Exception {

        String paths[]= {"./src//main//java//localizationVocabs//Frenchnew.json", "./src//main//java//localizationVocabs//Germannew.json","./src//main//java//localizationVocabs//Italiannew.json","./src//main//java//localizationVocabs//Portuguesenew.json","./src//main//java//localizationVocabs//Spanishnew.json","./src//main//java//localizationVocabs//Indonesiannew.json","./src//main//java//localizationVocabs//Japanesenew.json","./src//main//java//localizationVocabs//Malaynew.json","./src//main//java//localizationVocabs//Chinesenew.json" };
        int i=1;
        WebDriverManager.chromedriver().setup();
        ChromeOptions options= new ChromeOptions();
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        //options.addArguments("--headless");
        options.addArguments("--disable-gpu");
        options.addArguments("--allow-insecure-localhost");
        String reportPath = System.getProperty("user.dir")+"\\reports\\reports.html";
        ExtentSparkReporter es = new ExtentSparkReporter(reportPath);
        es.config().setDocumentTitle("CareAR");
        es.config().setReportName("Localization");
        extent = new ExtentReports();
        extent.attachReporter(es);
        //extent.setSystemInfo("Tester", "XYZ");

        while(i<=9) {

            // if(i<=1) {
            jsonPath = paths[i - 1];
            choice = i;

            //System.setProperty("webdriver.chrome.driver","./src//main//java//configuration//chromedriver.exe");
            WebDriver driver = new ChromeDriver(options);
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            validateLocalization(driver, i);
            System.out.println("\n\n\n\n" + "-X-X-X-X-X-X-X-X-X-X-X-X-X-X");
            i++;
            Thread.sleep(5000);
			/*  }
			  else
			  {
				  break;
			  }*/
        }


        i=1;
        /*
         * while(i<=1) { jsonPath=paths[i-1]; choice=i;
         *
         * //System.setProperty("webdriver.chrome.driver",
         * "./src//main//java//configuration//chromedriver.exe"); WebDriver driver = new
         * ChromeDriver(options); driver.manage().timeouts().implicitlyWait(20,
         * TimeUnit.SECONDS);
         * UserPortalLocalisation.userPortalLocalisation(driver,jsonPath,choice);
         * System.out.println("\n\n\n\n"+"-X-X-X-X-X-X-X-X-X-X-X-X-X-X"); i++; }
         */

    }

    public static void validateMyProfile(WebDriver driver, int langCount)throws Exception
    {
        switch (langCount) {
            case 1:
                test = extent.createTest("French");
                break;
            case 2:
                test = extent.createTest("German");
                break;
            case 3:
                test = extent.createTest("Italian");
                break;
            case 4:
                test = extent.createTest("Portugese");
                break;
            case 5:
                test = extent.createTest("Spanish");
                break;
            case 6:
                test = extent.createTest("Indonesian");
                break;
            case 7:
                test = extent.createTest("Japanese");
                break;
            case 8:
                test = extent.createTest("Malay");
                break;
            case 9:
                test = extent.createTest("Chinese");
                break;
        }
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        driver.get("https://carear-hyperspace.web.app/#/admin/login");
        driver.manage().window().maximize();
        driver.findElement(LoginPage.Ad_Email).sendKeys("Mahesh.mastii@gmail.com");
        driver.findElement(LoginPage.Ad_Password).sendKeys("Password1");
        driver.findElement(LoginPage.Ad_LoginButton).click();
        System.out.println("clicked on login button");
        WebFunctions.explicitWait(driver, 20, "Visibility", Admin_WelcomePage.waitElement);
        Thread.sleep(8000);

        /*
         * WebElement l =driver.findElement(By.tagName("body"));
         * System.out.println("Text content: "+ l.getText());
         */

        driver.findElement(Admin_WelcomePage.languageChange).click();
        Thread.sleep(2000);

        if(choice==1)
        {
            driver.findElement(Admin_WelcomePage.selectFrench).click();
            System.out.println("\n\n\n Selected FRENCH \n\n");
        }
        else if(choice==2)
        {
            driver.findElement(Admin_WelcomePage.selectGerman).click();
            System.out.println("\n\n\n Selected GERMAN \n\n");
        }
        else if(choice==3)
        {
            driver.findElement(Admin_WelcomePage.selectItalian).click();
            System.out.println("\n\n\n Selected ITALIAN \n\n");
        }
        else if(choice==4)
        {
            driver.findElement(Admin_WelcomePage.selectPortugese).click();
            System.out.println("\n\n\n Selected PORTUGUESE \n\n");
        }
        else if(choice==5)
        {
            driver.findElement(Admin_WelcomePage.selectSpanish).click();
            System.out.println("\n\n\n Selected SPANISH \n\n");
        }
        else if(choice==6)
        {
            driver.findElement(Admin_WelcomePage.selectIndonesian).click();
            System.out.println("\n\n\n Selected SPANISH \n\n");
        }
        else if(choice==7)
        {
            driver.findElement(Admin_WelcomePage.selectJapanese).click();
            System.out.println("\n\n\n Selected SPANISH \n\n");
        }
        else if(choice==8)
        {
            driver.findElement(Admin_WelcomePage.selectMalay).click();
            System.out.println("\n\n\n Selected SPANISH \n\n");
        }
        else if(choice==9)
        {
            driver.findElement(Admin_WelcomePage.selectChinese).click();
            System.out.println("\n\n\n Selected SPANISH \n\n");
        }
        Thread.sleep(2000);

        driver.findElement(Admin_WelcomePage.saveLanguage).click();
        Thread.sleep(3000);

        System.out.println("\n\n");
        System.out.println("------------INITIATING VALIDATION FOR LEFT PANEL NAVIGATION BUTTONS----------");
        test.info("------------INITIATING VALIDATION FOR LEFT PANEL NAVIGATION BUTTONS----------");
        System.out.println("\n");
        driver.findElement(MyProfilePage.primaryPhoneNumber).clear();
        driver.findElement(MyProfilePage.primaryPhoneNumber).sendKeys("913333333333");
        driver.findElement(MyProfilePage.saveButton).click();

		/*
		error message validation code
		textValidation(portalText, savedText, elements[i - 1]);
		 */
        driver.findElement(MyProfilePage.primaryPhoneNumber).clear();
        driver.findElement(MyProfilePage.primaryPhoneNumber).sendKeys("+913333333333");
        driver.findElement(MyProfilePage.secondaryPhoneNumber).clear();
        driver.findElement(MyProfilePage.secondaryPhoneNumber).sendKeys("913333333333");

		/*
		error message validation code
		textValidation(portalText, savedText, elements[i - 1]);
		 */

        driver.findElement(MyProfilePage.primaryPhoneNumber).clear();
        driver.findElement(MyProfilePage.primaryPhoneNumber).sendKeys("+913333333333");
        driver.findElement(MyProfilePage.secondaryPhoneNumber).clear();
        driver.findElement(MyProfilePage.secondaryPhoneNumber).sendKeys("+913333333333");
		/*
		success message validation code
		textValidation(portalText, savedText, elements[i - 1]);
		 */

        //driver.findElement(By.xpath(MyProfilePage.chooseFile)).click();
        fileUpload("test.docx");
		/*
		error message validation code
		textValidation(portalText, savedText, elements[i - 1]);
		 */
        fileUpload("test.jpg");
		/*
		success message validation code
		textValidation(portalText, savedText, elements[i - 1]);
		 */
    }

    public static void fileUpload(String filename)throws Exception
    {
        StringSelection ss=new StringSelection(filename);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss,null);
        Robot r=new Robot();
        r.keyPress(KeyEvent.VK_CONTROL);
        r.keyPress(KeyEvent.VK_V);
        r.keyRelease(KeyEvent.VK_V);
        r.keyRelease(KeyEvent.VK_CONTROL);
        r.keyPress(KeyEvent.VK_ENTER);
        r.keyRelease(KeyEvent.VK_ENTER);

    }
    public static void validateLocalization(WebDriver driver, int langCount) throws Exception {

        switch (langCount) {
            case 1:
                test = extent.createTest("French");
                break;
            case 2:
                test = extent.createTest("German");
                break;
            case 3:
                test = extent.createTest("Italian");
                break;
            case 4:
                test = extent.createTest("Portugese");
                break;
            case 5:
                test = extent.createTest("Spanish");
                break;
            case 6:
                test = extent.createTest("Indonesian");
                break;
            case 7:
                test = extent.createTest("Japanese");
                break;
            case 8:
                test = extent.createTest("Malay");
                break;
            case 9:
                test = extent.createTest("Chinese");
                break;

        }


        String elements[] = { "users","roleManagement" ,"kpis", "sessionActivity", "sessionMap", "dashboard", "myProfile", "myCompany" };

        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        driver.get("https://carear-development.web.app/#/admin/login");
        //driver.get("https://carear-qa.web.app/#/admin/login");
        driver.manage().window().maximize();

        driver.findElement(LoginPage.Ad_Email).sendKeys("sanjay.parthasarathy@xerox.com");   //alandev.sriv@xerox.com  // regressiontest@xerox.com
        driver.findElement(LoginPage.Ad_Password).sendKeys("Password1");
        driver.findElement(LoginPage.Ad_LoginButton).click();
        System.out.println("clicked on login button");
        WebFunctions.explicitWait(driver, 20, "Visibility", Admin_WelcomePage.waitElement);
        Thread.sleep(8000);

        /*
         * WebElement l =driver.findElement(By.tagName("body"));
         * System.out.println("Text content: "+ l.getText());
         */

        driver.findElement(Admin_WelcomePage.languageChange).click();
        Thread.sleep(2000);

        if(choice==1)
        {
            driver.findElement(Admin_WelcomePage.selectFrench).click();
            System.out.println("\n\n\n Selected FRENCH \n\n");
        }
        else if(choice==2)
        {
            driver.findElement(Admin_WelcomePage.selectGerman).click();
            System.out.println("\n\n\n Selected GERMAN \n\n");
        }
        else if(choice==3)
        {
            driver.findElement(Admin_WelcomePage.selectItalian).click();
            System.out.println("\n\n\n Selected ITALIAN \n\n");
        }
        else if(choice==4)
        {
            driver.findElement(Admin_WelcomePage.selectPortugese).click();
            System.out.println("\n\n\n Selected PORTUGUESE \n\n");
        }
        else if(choice==5)
        {
            driver.findElement(Admin_WelcomePage.selectSpanish).click();
            System.out.println("\n\n\n Selected SPANISH \n\n");
        }
        else if(choice==6)
        {
            driver.findElement(Admin_WelcomePage.selectIndonesian).click();
            System.out.println("\n\n\n Selected INDONESIAN \n\n");
        }
        else if(choice==7)
        {
            driver.findElement(Admin_WelcomePage.selectJapanese).click();
            System.out.println("\n\n\n Selected JAPANESE \n\n");
        }
        else if(choice==8)
        {
            driver.findElement(Admin_WelcomePage.selectMalay).click();
            System.out.println("\n\n\n Selected MALAY \n\n");
        }
        else if(choice==9)
        {
            driver.findElement(Admin_WelcomePage.selectChinese).click();
            System.out.println("\n\n\n Selected CHINESE \n\n");
        }

        Thread.sleep(2000);

        driver.findElement(Admin_WelcomePage.saveLanguage).click();
        Thread.sleep(3000);

        System.out.println("\n\n");
        System.out.println("------------INITIATING VALIDATION FOR LEFT PANEL NAVIGATION BUTTONS----------");
        test.info("------------INITIATING VALIDATION FOR LEFT PANEL NAVIGATION BUTTONS----------");
        System.out.println("\n");

        for (int i = 1; i <= 8; i++) {
            String index = Integer.toString(i);
            String path = Admin_WelcomePage.navigate1 + index + Admin_WelcomePage.navigate2;
            String portalText = driver.findElement(By.xpath(path)).getText();

            String savedText = JSONRead.readJSON(jsonPath, elements[i - 1]);
            textValidation(portalText, savedText, elements[i - 1]);
        }
        //extent.flush();
        validateFooter(driver);
        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR MY COMPANY PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR MY COMPANY PAGE----------"+"\n");

        //testUsersScreen(driver);


        myCompanyValidation(driver);

        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR USERS PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR USERS PAGE----------"+"\n");
        testUsersScreen(driver);

        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR RoleManagement PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR RoleManagement PAGE----------"+"\n");
        roleManagement(driver);

        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR KPI PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR KPI PAGE----------"+"\n");
        validateKPI(driver);

        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR SESSION ACTIVITY PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR SESSION ACTIVITY PAGE----------"+"\n");
        sessionActivityValidation(driver);

        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR SESSION MAP PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR SESSION MAP PAGE----------"+"\n");
        sessionMapValiation(driver);


        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR DASHBOARD ITEMS----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR DASHBOARD ITEMS----------"+"\n");
        dashboardValidation(driver);

        System.out.println("\n\n"+"------------INITIATING VALIDATION FOR MY PROFILE PAGE----------"+"\n");
        test.info("\n\n"+"------------INITIATING VALIDATION FOR MY PROFILE PAGE----------"+"\n");
        myProfileValidation(driver);



        System.out.println("-------VALIDATION CONCLUDED-------");
        test.info("-------VALIDATION CONCLUDED-------");

        driver.close();
        if (langCount == 9) {
            extent.flush();
        }
    }

    public static void deleteUserValidation(WebDriver driver)throws Exception{

        //driver.findElement(UsersPage.users).click();
        Thread.sleep(2000);
        String jsonTranslation="";
        String alertMessage="";
        String requiredText="";

        driver.findElement(UsersPage.addNewUserButton).click();
        Thread.sleep(2000);
        driver.findElement(UsersPage.createButton).click();
        Thread.sleep(3000);

        requiredText=driver.findElement(UsersPage.emailRequired).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "emailRequired");
        textValidation(requiredText, jsonTranslation, "emailRequired");

        requiredText=driver.findElement(UsersPage.firstNameRequired).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "firstNameRequired");
        textValidation(requiredText, jsonTranslation, "firstNameRequired");

        requiredText=driver.findElement(UsersPage.lastNameRequired).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "lastNameRequired");
        textValidation(requiredText, jsonTranslation, "lastNameRequired");
        driver.findElement(UsersPage.cancelButton1).click();
        Thread.sleep(2000);


        driver.findElement(UsersPage.imgDelete).click();
        Thread.sleep(2000);


        alertMessage=driver.findElement(By.xpath("//*[@class='modal-body']//div")).getText().split("\\n")[0];
        jsonTranslation=JSONRead.readJSON(jsonPath, "confirmDeleteUser");
        textValidation(alertMessage, jsonTranslation, "confirmDeleteUser");
        driver.findElement(UsersPage.btnCancel).click();

        driver.findElement(UsersPage.imgDisable).click();
        Thread.sleep(1000);
        alertMessage=driver.findElement(By.xpath("//*[@class='modal-body']//div")).getText().split("\\n")[0];
        jsonTranslation=JSONRead.readJSON(jsonPath, "confirmDisableUser");
        textValidation(alertMessage, jsonTranslation, "confirmDisableUser");
        Thread.sleep(2000);
        driver.findElement(UsersPage.confirm).click();

        driver.findElement(UsersPage.imgEnable).click();
        Thread.sleep(1000);

        alertMessage=driver.findElement(By.xpath("//*[@class='modal-body']//div")).getText().split("\\n")[0];
        jsonTranslation=JSONRead.readJSON(jsonPath, "confirmEnableUser");
        textValidation(alertMessage, jsonTranslation, "confirmEnableUser");
        driver.findElement(UsersPage.confirm).click();


    }
    public static void myCompanyValidation(WebDriver driver) {
        String elements[] = { "companyName", "joinDate", "expirationDate", "tierLevel","maximumSubscribers","noOfVideoRecordingUsers","createdBy",
                "customerStatus","tenantPhysicalAddress","customerCRMID","resellerOfRecord","customerSuccessManager","zQuoteID",
                "referralCode", "servicenowControl","amazonS3Configuration","tenantAdmin", "groups"};
        //,"hostRegion", "guestRegion", "hostProxy", "guestProxy", "encryption" };
        String portalTranslation="";
        String jsonTranslation="";
        String path;
        WebFunctions.explicitWait(driver, 20, "Visibility", MyCompanyPage.lastTextWait1);

		/*for (int i = 1; i <= 18; i++) {
			String index = Integer.toString(i);
			if(i>=5 && i<=14) {
				//continue;
				path = MyCompanyPage.myCompanyNav1 + index + MyCompanyPage.myCompanyNav2;

			}
			if (i>=15 && i<17) {
				path = MyCompanyPage.myCompanyNav1 + index + MyCompanyPage.myCompanyNav3;
			}
			else if (i>=17) {
				index = Integer.toString(i+1);
				path = MyCompanyPage.myCompanyNav1 + index + MyCompanyPage.myCompanyNav2;
			}
			else {
			    path = MyCompanyPage.myCompanyNav1 + index + MyCompanyPage.myCompanyNav2;

			}

			String portalText = driver.findElement(By.xpath(path)).getText();
			String savedText = JSONRead.readJSON(jsonPath, elements[i - 1]);
			textValidation(portalText, savedText, elements[i - 1]);
		}*/
        //portalTranslation=driver.findElement(MyCompanyPage.maximumSubscribers).getText();
        //jsonTranslation=JSONRead.readJSON(jsonPath, "maximumSubscribers");
        //textValidation(portalTranslation, jsonTranslation, "maximumSubscribers");

        //Mownima code
        portalTranslation=driver.findElement(MyCompanyPage.company).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "company");
        textValidation(portalTranslation, jsonTranslation, "company");

        portalTranslation=driver.findElement(MyCompanyPage.date).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "date");
        textValidation(portalTranslation, jsonTranslation, "date");

        portalTranslation=driver.findElement(MyCompanyPage.expirationDate).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "expirationDate");
        textValidation(portalTranslation, jsonTranslation, "expirationDate");

        portalTranslation=driver.findElement(MyCompanyPage.maximumSubscribers).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "maximumSubscribers");
        textValidation(portalTranslation, jsonTranslation, "maximumSubscribers");

        portalTranslation=driver.findElement(MyCompanyPage.createdBy).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "createdBy");
        textValidation(portalTranslation, jsonTranslation, "createdBy");

        portalTranslation=driver.findElement(MyCompanyPage.tenantPhysicalAddress).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "tenantPhysicalAddress");
        textValidation(portalTranslation, jsonTranslation, "tenantPhysicalAddress");

        portalTranslation=driver.findElement(MyCompanyPage.customerCRMID).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "customerCRMID");
        textValidation(portalTranslation, jsonTranslation, "customerCRMID");

        portalTranslation=driver.findElement(MyCompanyPage.resellerOfRecord).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "resellerOfRecord");
        textValidation(portalTranslation, jsonTranslation, "resellerOfRecord");

        portalTranslation=driver.findElement(MyCompanyPage.customerSuccessManager).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "customerSuccessManager");
        textValidation(portalTranslation, jsonTranslation, "customerSuccessManager");

        portalTranslation=driver.findElement(MyCompanyPage.referralCode).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "referralCode");
        textValidation(portalTranslation, jsonTranslation, "referralCode");


        portalTranslation=driver.findElement(MyCompanyPage.serviceNowAPIUsername).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "serviceNowAPIUsername");
        textValidation(portalTranslation, jsonTranslation, "serviceNowAPIUsername");

        portalTranslation=driver.findElement(MyCompanyPage.serviceNowAPIPassword).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "serviceNowAPIPassword");
        textValidation(portalTranslation, jsonTranslation, "serviceNowAPIPassword");

        portalTranslation=driver.findElement(MyCompanyPage.amazonAccessKeyId).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "amazonAccessKeyId");
        textValidation(portalTranslation, jsonTranslation, "amazonAccessKeyId");

        portalTranslation=driver.findElement(MyCompanyPage.amazonSecretAccessKey).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "amazonSecretAccessKey");
        textValidation(portalTranslation, jsonTranslation, "amazonSecretAccessKey");

        portalTranslation=driver.findElement(MyCompanyPage.amazonS3BucketName).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "amazonS3BucketName");
        textValidation(portalTranslation, jsonTranslation, "amazonS3BucketName");

        portalTranslation=driver.findElement(MyCompanyPage.bucketRegion).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "bucketRegion");
        textValidation(portalTranslation, jsonTranslation, "bucketRegion");

        portalTranslation=driver.findElement(MyCompanyPage.enableVideoRecording).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "enableVideoRecording");
        textValidation(portalTranslation, jsonTranslation, "enableVideoRecording");

        portalTranslation=driver.findElement(MyCompanyPage.encryption).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "encryption");
        textValidation(portalTranslation, jsonTranslation, "encryption");

        portalTranslation=driver.findElement(MyCompanyPage.guestJoinByBrowser).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "guestJoinByBrowser");
        textValidation(portalTranslation, jsonTranslation, "guestJoinByBrowser");

        portalTranslation=driver.findElement(MyCompanyPage.guestJoinBySmartGlasses).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "guestJoinBySmartGlasses");
        textValidation(portalTranslation, jsonTranslation, "guestJoinBySmartGlasses");
//usage info new Mownima code
        portalTranslation=driver.findElement(MyCompanyPage.Minutesused).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "Minutesused");
        textValidation(portalTranslation, jsonTranslation, "Minutesused");

        portalTranslation=driver.findElement(MyCompanyPage.SessionsUsed).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "SessionsUsed");
        textValidation(portalTranslation, jsonTranslation, "SessionsUsed");

        portalTranslation=driver.findElement(MyCompanyPage.InstructSessionsPurchased).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "InstructSessionsPurchased");
        textValidation(portalTranslation, jsonTranslation, "InstructSessionsPurchased");

        portalTranslation=driver.findElement(MyCompanyPage.InstructSessionsUsed).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "InstructSessionsUsed");
        textValidation(portalTranslation, jsonTranslation, "InstructSessionsUsed");

        portalTranslation=driver.findElement(MyCompanyPage.InstructSessionsAvailable).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "InstructSessionsAvailable");
        textValidation(portalTranslation, jsonTranslation, "InstructSessionsAvailable");
        textValidation(portalTranslation, jsonTranslation, "InstructSessionsAvailable");



        portalTranslation=driver.findElement(MyCompanyPage.hostMediaRegion).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "hostMediaRegion");
        textValidation(portalTranslation, jsonTranslation, "hostMediaRegion");

        portalTranslation=driver.findElement(MyCompanyPage.guestMediaRegion).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "guestMediaRegion");
        textValidation(portalTranslation, jsonTranslation, "guestMediaRegion");

        portalTranslation=driver.findElement(MyCompanyPage.hostProxy).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "hostProxy");
        textValidation(portalTranslation, jsonTranslation, "hostProxy");

        portalTranslation=driver.findElement(MyCompanyPage.guestProxy).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "guestProxy");
        textValidation(portalTranslation, jsonTranslation, "guestProxy");


        List<WebElement> hostReg=driver.findElements(MyCompanyPage.ddHostMediaRegion);
        int j=0;
        for(j=0;j<hostReg.size();j++) {
            String txt=hostReg.get(j).getText();
            System.out.println(txt);
        }
        //String countries[]= {"global","asia","china","europe","india","japan","northAmerica"};
        String countries[]= {"global","asia","europe","india","japan","northAmerica"};
        for(int i=0;i<hostReg.size();i++)
        {
            String nameFromPortal=hostReg.get(i).getText();
            String savedText = JSONRead.readJSON(jsonPath, countries[i]);
            textValidation(nameFromPortal, savedText, countries[i]);
        }
//guest media region
        List<WebElement> gstReg=driver.findElements(MyCompanyPage.ddGuestMediaRegion);
        int k=0;
        for(k=0;k<gstReg.size();k++) {
            String txt1=gstReg.get(k).getText();
            System.out.println(txt1);
        }
        //String countries[]= {"global","asia","china","europe","india","japan","northAmerica"};
        String countriesn[]= {"global","asia","europe","india","japan","northAmerica"};
        for(int i=0;i<gstReg.size();i++)
        {
            String nameFromPortal=gstReg.get(i).getText();
            String savedText = JSONRead.readJSON(jsonPath, countriesn[i]);
            textValidation(nameFromPortal, savedText, countriesn[i]);
        }
        List<WebElement> guestReg=driver.findElements(MyCompanyPage.ddGuestJoinByUser);
        for(int i=0;i<guestReg.size();i++)
        {
            String nameFromPortal=guestReg.get(i).getText();
            String savedText = JSONRead.readJSON(jsonPath, countries[i]);
            textValidation(nameFromPortal, savedText, countries[i]);
        }

        String entries[]= {"on","off"};
        List<WebElement> hostProxy=driver.findElements(MyCompanyPage.ddHostProxy);
        List<WebElement> guestProxy=driver.findElements(MyCompanyPage.ddGuestProxy);
        //List<WebElement> encryption=driver.findElements(MyCompanyPage.encryption);

        for(int i=0;i<hostProxy.size();i++)
        {
            String nameFromPortal=hostProxy.get(i).getText();
            String savedText = JSONRead.readJSON(jsonPath, entries[i]);
            textValidation(nameFromPortal, savedText, entries[i]);

            nameFromPortal=guestProxy.get(i).getText();
            savedText = JSONRead.readJSON(jsonPath, entries[i]);
            textValidation(nameFromPortal, savedText, entries[i]);

            /*
             * nameFromPortal=encryption.get(i).getText(); savedText =
             * JSONRead.readJSON(jsonPath, entries[i]); textValidation(nameFromPortal,
             * savedText, entries[i]);
             */
        }

        //reloginToRefresh
        String nameFromPortal=driver.findElement(MyCompanyPage.lastTextWait1).getText();
        String savedText = JSONRead.readJSON(jsonPath, "reloginToRefresh");
        if(nameFromPortal.contains(savedText))
            textValidation(savedText, savedText,"reloginToRefresh");
        else
            textValidation(nameFromPortal, savedText,"reloginToRefresh");

        validateFooter(driver);
    }
    public static void roleManagement(WebDriver driver) throws Exception {
        driver.findElement(RoleManagementPage.clickRoleManagement).click();
        WebFunctions.explicitWait(driver, 20, "CLICKABLE", RoleManagementPage.clickRoleManagement);
        Thread.sleep(5000);
        String elements[] = { "Role Management", "Role", "Allow Snapshot", "Allow Media Download","Allow Recording","Admin","Analyst","Normal","Guest" };
        String portalTranslation="";
        String jsonTranslation="";

        portalTranslation=driver.findElement(RoleManagementPage.heading).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "heading");
        textValidation(portalTranslation, jsonTranslation, "heading");

        portalTranslation=driver.findElement(RoleManagementPage.role).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "role");
        textValidation(portalTranslation, jsonTranslation, "role");

        portalTranslation=driver.findElement(RoleManagementPage.allowsnapshot).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "allowsnapshot");
        textValidation(portalTranslation, jsonTranslation, "allowsnapshot");


        portalTranslation=driver.findElement(RoleManagementPage.allowmediadownload).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "allowmediadownload");
        textValidation(portalTranslation, jsonTranslation, "allowmediadownload");

        portalTranslation=driver.findElement(RoleManagementPage.allowrecording).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "allowrecording");
        textValidation(portalTranslation, jsonTranslation, "allowrecording");

        portalTranslation=driver.findElement(RoleManagementPage.adminrole).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "adminrole");
        textValidation(portalTranslation, jsonTranslation, "adminrole");

        portalTranslation=driver.findElement(RoleManagementPage.analystrole).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "analystrole");
        textValidation(portalTranslation, jsonTranslation, "analystrole");

        portalTranslation=driver.findElement(RoleManagementPage.normalrole).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "normalrole");
        textValidation(portalTranslation, jsonTranslation, "normalrole");

        portalTranslation=driver.findElement(RoleManagementPage.guestrole).getText();
        jsonTranslation=JSONRead.readJSON(jsonPath, "guestrole");
        textValidation(portalTranslation, jsonTranslation, "guestrole");


    }

    public static void myProfileValidation(WebDriver driver) throws Exception {
        driver.findElement(MyProfilePage.myprofileLink).click();
        WebFunctions.explicitWait(driver, 20, "CLICKABLE", MyProfilePage.myprofileLink);
        //WebFunctions.explicitWait(driver, 20, "CLICKABLE", MyProfilePage.saveButton);
        Thread.sleep(3000);
        String elements[] = { "email", "name", "jobDescription", "phoneNumber","secondaryPhoneNumber" };

        for (int i = 1; i <= 5; i++) {
            String index = Integer.toString(i);
            //String path = MyProfilePage.myProfileNav1 + index + MyProfilePage.myProfileNav2;
            String path=MyProfilePage.myProfileNav3+ index+MyProfilePage.myProfileNav4;
            String portalText = driver.findElement(By.xpath(path)).getText();
            String savedText = JSONRead.readJSON(jsonPath, elements[i - 1]);
            textValidation(portalText, savedText, elements[i - 1]);
        }
        String portalText = driver.findElement(MyProfilePage.saveButton).getText();
        String savedText = JSONRead.readJSON(jsonPath, "save");
        if(portalText.contains(savedText))
            textValidation(savedText, savedText, "Save");

        portalText = driver.findElement(MyProfilePage.versionButton).getText();
        savedText = JSONRead.readJSON(jsonPath, "version");
        if(portalText.contains(savedText))
            textValidation(savedText, savedText, "version");
        else
            textValidation(portalText, savedText, "version");

        portalText = driver.findElement(MyProfilePage.userPortal).getText();
        savedText = JSONRead.readJSON(jsonPath, "userPortal");
        textValidation(portalText, savedText, "userPortal");

        portalText = driver.findElement(MyProfilePage.logout).getText();
        savedText = JSONRead.readJSON(jsonPath, "logout");
        textValidation(portalText, savedText, "logout");

        portalText = driver.findElement(MyProfilePage.chooseFile).getText();
        savedText = JSONRead.readJSON(jsonPath, "chooseFile");
        textValidation(portalText, savedText, "chooseFile");

        /*
         * portalText = driver.findElement(MyProfilePage.noFileChosen).getText();
         * savedText = JSONRead.readJSON(jsonPath, "chooseFile");
         * textValidation(portalText, savedText, "chooseFile");
         */

        portalText = driver.findElement(MyProfilePage.upload).getText();
        savedText = JSONRead.readJSON(jsonPath, "upload");
        textValidation(portalText, savedText, "upload");
        validateFooter(driver);
    }

    public static void sessionActivityValidation(WebDriver driver) throws Exception {
        driver.findElement(SessionActivityPage.sessionActivityNav).click();
        WebFunctions.explicitWait(driver, 20, "CLICKABLE", SessionActivityPage.userPortal);
        WebFunctions.explicitWait(driver, 20, "Visibility", SessionActivityPage.poweredByCareAr);
        Thread.sleep(3000);

        // navtabs validation : Today/This week/This Month/Custom Date
        String elements[] = { "today", "thisWeek", "thisMonth", "customDate" };

        for (int i = 1; i <= 4; i++) {
            String index = Integer.toString(i);
            String path = SessionActivityPage.navTabs1 + index + SessionActivityPage.navTabs2;
            String portalText = driver.findElement(By.xpath(path)).getText();
            String savedText = JSONRead.readJSON(jsonPath, elements[i - 1]);
            textValidation(portalText, savedText, elements[i - 1]);
        }

        String elements1[] = { "startTime", "duration", "host", "guests", "group" };
        for (int i = 2; i <= 6; i++) {
            String index = Integer.toString(i);
            String path = SessionActivityPage.tableHeader1 + index + SessionActivityPage.tableHeader2;
            String portalText = driver.findElement(By.xpath(path)).getText();
            String savedText = JSONRead.readJSON(jsonPath, elements1[i - 2]);
            textValidation(portalText, savedText, elements1[i - 2]);
        }

        String portalText = driver.findElement(SessionActivityPage.rowsPerPage).getText();
        String savedText = JSONRead.readJSON(jsonPath, "rowsPerPage");
        if(portalText.contains(savedText))
            textValidation(savedText, savedText, "rowsPerPage");

        portalText = driver.findElement(SessionActivityPage.termsOfService).getText();
        savedText = JSONRead.readJSON(jsonPath, "termsOfService");
        textValidation(portalText, savedText, "termsOfService");

        portalText = driver.findElement(SessionActivityPage.privacyPolicy).getText();
        savedText = JSONRead.readJSON(jsonPath, "privacyPolicy");
        textValidation(portalText, savedText, "privacyPolicy");

        portalText = driver.findElement(SessionActivityPage.poweredByCareAr).getText();
        savedText = JSONRead.readJSON(jsonPath, "poweredByCareAR");
        if(portalText.contains(savedText))
            textValidation(savedText, savedText, "poweredByCareAR");

        portalText = driver.findElement(SessionActivityPage.sessionImages).getText();
        savedText = JSONRead.readJSON(jsonPath, "sessionImages");
        textValidation(portalText, savedText, "sessionImages");

        // userPortal
        portalText = driver.findElement(SessionActivityPage.userPortal).getText();
        savedText = JSONRead.readJSON(jsonPath, "userPortal");
        textValidation(portalText, savedText, "userPortal");

        /*
         * validating CUSTOM DATE SECTION
         *
         */

        System.out.println("\n");
        System.out.println("------------INITIATING VALIDATION FOR SESSION ACTIVITY > CUSTOM DATE SECTION----------");
        System.out.println("\n");
        driver.findElement(SessionActivityPage.CustomDate).click();
        Thread.sleep(3000);

        portalText = driver.findElement(SessionActivityPage.from).getText();
        savedText = JSONRead.readJSON(jsonPath, "from");
        textValidation(portalText, savedText, "from");

        portalText = driver.findElement(SessionActivityPage.to).getText();
        savedText = JSONRead.readJSON(jsonPath, "to");
        textValidation(portalText, savedText, "to");

        portalText = driver.findElement(SessionActivityPage.search).getText();
        savedText = JSONRead.readJSON(jsonPath, "search");
        textValidation(portalText, savedText, "search");

        portalText = driver.findElement(SessionActivityPage.clear).getText();
        savedText = JSONRead.readJSON(jsonPath, "clear");
        textValidation(portalText, savedText, "clear");

        portalText = driver.findElement(SessionActivityPage.seeActivityInMap).getText();
        savedText = JSONRead.readJSON(jsonPath, "seeActivityInMap");
        textValidation(portalText, savedText, "seeActivityInMap");

        Thread.sleep(2000);
        validateFooter(driver);
    }

    public static void validateKPI(WebDriver driver) throws InterruptedException {
        driver.findElement(KPIPage.clickKPI).click();
        WebFunctions.explicitWait(driver, 20, "Visibility", KPIPage.addNewKPI);
        WebFunctions.explicitWait(driver, 20, "Clickable", KPIPage.addNewKPIButton);
        Thread.sleep(3000);
        // tableValidation
        String elements1[] = { "kpiId", "index", "userType", "kpiQuestions", "required", "type", "action" };
        for (int i = 1; i <8; i++) {
            String index = Integer.toString(i);
            String path = KPIPage.tableHeaders1 + index + KPIPage.tableHeaders2;
            String portalText = driver.findElement(By.xpath(path)).getText();
            String savedText = JSONRead.readJSON(jsonPath, elements1[i - 1]);
            textValidation(portalText, savedText, elements1[i - 1]);
        }

        String portalText = driver.findElement(KPIPage.addNewKPI).getText();
        String savedText = JSONRead.readJSON(jsonPath, "addNewKPI");
        textValidation(portalText, savedText, "addNewKPI");

        // clicking on add new KPI button

        driver.findElement(KPIPage.addNewKPIButton).click();
        Thread.sleep(3000);

        String elements2[] = { "index", "kpiQuestion", "required", "type", "userType" };
        for (int i = 1; i <= 5; i++) {
            String index = Integer.toString(i);
            String path = KPIPage.labelsOnAddKPI1 + index + KPIPage.labelsOnAddKPI2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements2[i - 1]);
            if(portalText.contains(savedText))
                textValidation(savedText, savedText, elements2[i - 1]);
            else
                textValidation(portalText, savedText, elements2[i - 1]);
        }

        String elements3[] = { "submit", "cancel" };
        for (int i = 1; i <= 2; i++) {
            String index = Integer.toString(i);
            String path = KPIPage.submitCancel1 + index + KPIPage.submitCancel2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements3[i - 1]);
            textValidation(portalText, savedText, elements3[i - 1]);
        }

        String elements4[] = { "mandatory", "optional" };
        for (int i = 1; i <= 2; i++) {
            String index = Integer.toString(i);
            String path = KPIPage.mandatoryOptional1 + index + KPIPage.mandatoryOptional2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements4[i - 1]);
            textValidation(portalText, savedText, elements4[i - 1]);
        }

        String elements5[] = { "rating", "dropdown", "singleline", "multiline" };
        for (int i = 1; i <= 4; i++) {
            String index = Integer.toString(i);
            String path = KPIPage.type1 + index + KPIPage.type2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements5[i - 1]);
            textValidation(portalText, savedText, elements5[i - 1]);
        }

        String elements6[] = { "host", "guest" };
        for (int i = 1; i <= 2; i++) {
            String index = Integer.toString(i);
            String path = KPIPage.userType1 + index + KPIPage.userType2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements6[i - 1]);
            textValidation(portalText, savedText, elements6[i - 1]);
        }
        validateFooter(driver);
    }

    public static void testUsersScreen(WebDriver driver) throws Exception
    {
        Thread.sleep(3000);
        /*
         * Actions action =new Actions(driver);
         * action.moveToElement(driver.findElement(UsersPage.clickUsers)).click().build(
         * ).perform();
         */
        driver.findElement(UsersPage.clickUsers).click();
        WebFunctions.explicitWait(driver, 20, "Visibility", UsersPage.exportAll);
        WebFunctions.explicitWait(driver, 20, "Clickable", UsersPage.addNewUserButton);
        Thread.sleep(5000);

        //pavan code starts
        deleteUserValidation(driver);
        //pavan code ends


        String portalText = driver.findElement(UsersPage.addNewUser).getText();
        String savedText = JSONRead.readJSON(jsonPath, "addNewUser");
        textValidation(portalText, savedText, "addNewUser");

        portalText = driver.findElement(UsersPage.exportAll).getText();
        savedText = JSONRead.readJSON(jsonPath, "exportAll");
        textValidation(portalText, savedText, "exportAll");

        portalText = driver.findElement(UsersPage.importButton).getText();
        savedText = JSONRead.readJSON(jsonPath, "import");
        textValidation(portalText, savedText, "import");

        String elements[] = { "name","email","role","group","status","phoneNumber","secondaryPhoneNumber","joinedDate","lastLoggedIn" };
        for (int i = 3; i <= 11; i++) {
            String index = Integer.toString(i);
            String path = UsersPage.userTableHeader1 + index + UsersPage.userTableHeader2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements[i - 3]);
            textValidation(portalText, savedText, elements[i - 3]);
        }

        portalText = driver.findElement(UsersPage.actionColumn).getText();
        savedText = JSONRead.readJSON(jsonPath, "action");
        textValidation(portalText, savedText, "action");

        driver.findElement(UsersPage.addNewUserButton).click();
        WebFunctions.explicitWait(driver, 20, "Visibility", UsersPage.cancelButton);

        List<WebElement> webElements=driver.findElements(UsersPage.elementsOnAddUser);
        String elements1[] = { "email","firstName","lastName","phoneNumber","secondaryPhoneNumber","jobDescription","group"};
        int j=0;
        Iterator listItr=webElements.iterator();
        while(listItr.hasNext())
        {
            WebElement e1=(WebElement) listItr.next();
            portalText =e1.getText();
            savedText=JSONRead.readJSON(jsonPath, elements1[j]);
            if(portalText.contains("*") && portalText.contains(savedText))
                textValidation(savedText, savedText, elements[j]);
            else
                textValidation(portalText, savedText, elements[j]);
            j++;
        }

        portalText = driver.findElement(UsersPage.createButton).getText();
        savedText = JSONRead.readJSON(jsonPath, "create");
        textValidation(portalText, savedText, "create");

        portalText = driver.findElement(UsersPage.cancelButton).getText();
        savedText = JSONRead.readJSON(jsonPath, "cancel");
        textValidation(portalText, savedText, "cancel");
        driver.findElement(UsersPage.cancelButton).click();

        WebFunctions.explicitWait(driver, 20, "VISIBILITY",UsersPage.disableEnable);
        //driver.findElement(UsersPage.disableEnable).click();
        WebElement togg = driver.findElement(UsersPage.disableEnable);
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("arguments[0].click();", togg);
        WebFunctions.explicitWait(driver, 20, "VISIBILITY", UsersPage.attention);

        portalText = driver.findElement(UsersPage.attention).getText();
        savedText = JSONRead.readJSON(jsonPath, "caution");
        textValidation(portalText, savedText, "caution");

        portalText = driver.findElement(UsersPage.message).getText();
        savedText = JSONRead.readJSON(jsonPath, "confirmDisableUser");
        textValidation(portalText, savedText, "confirmDisableUser");

        portalText = driver.findElement(UsersPage.confirm).getText();
        savedText = JSONRead.readJSON(jsonPath, "yes");
        textValidation(portalText, savedText, "yes");

        portalText = driver.findElement(UsersPage.cancel).getText();
        savedText = JSONRead.readJSON(jsonPath, "cancel");
        textValidation(portalText, savedText, "cancel");

        driver.findElement(UsersPage.cancel).click();
        Thread.sleep(2000);
        validateFooter(driver);
    }

    public static void sessionMapValiation(WebDriver driver) throws Exception
    {
        String portalText;
        String savedText;

        driver.findElement(SessionMapPage.clickSessionMap).click();
        /*
         * WebFunctions.explicitWait(driver, 20, "Visibility",
         * SessionMapPage.seeActivityInTable); WebFunctions.explicitWait(driver, 20,
         * "Clickable", SessionMapPage.custom);
         */
        Thread.sleep(3000);


        portalText = driver.findElement(SessionMapPage.sessionMap).getText();
        savedText = JSONRead.readJSON(jsonPath, "sessionMap");
        textValidation(portalText, savedText, "sessionMap");

        portalText = driver.findElement(SessionMapPage.seeActivityInTable).getText();
        savedText = JSONRead.readJSON(jsonPath, "seeActivityInTable");
        textValidation(portalText, savedText, "seeActivityInTable");

        portalText = driver.findElement(SessionMapPage.host).getText();
        savedText = JSONRead.readJSON(jsonPath, "host");
        textValidation(portalText, savedText, "host");

        portalText = driver.findElement(SessionMapPage.guest).getText();
        savedText = JSONRead.readJSON(jsonPath, "guest");
        textValidation(portalText, savedText, "guest");

        portalText = driver.findElement(SessionMapPage.groupMarkers).getText();
        savedText = JSONRead.readJSON(jsonPath, "groupMarkers");
        textValidation(portalText, savedText, "groupMarkers");

        //mapZoomInstruction

        portalText = driver.findElement(SessionMapPage.controlScrollText).getText();
        savedText = JSONRead.readJSON(jsonPath, "mapZoomInstruction");
        textValidation(portalText, savedText, "mapZoomInstruction");


        String elements[] = { "today","thisWeek","thisMonth","customDate"};
        for (int i = 1; i <= 4; i++) {
            String index = Integer.toString(i);
            String path = SessionMapPage.navTabs1 + index + SessionMapPage.navTabs2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements[i - 1]);
            textValidation(portalText, savedText, elements[i - 1]);

            if(i==4)
            {
                driver.findElement(By.xpath(path)).click();
            }
        }

        //driver.findElement(SessionMapPage.custom).click();
        Thread.sleep(3000);

        portalText = driver.findElement(SessionMapPage.from).getText();
        savedText = JSONRead.readJSON(jsonPath, "from");
        textValidation(portalText, savedText, "from");

        portalText = driver.findElement(SessionMapPage.to).getText();
        savedText = JSONRead.readJSON(jsonPath, "to");
        textValidation(portalText, savedText, "to");


        String elements1[] = { "search","clear"};
        for (int i = 1; i <= 2; i++) {
            String index = Integer.toString(i);
            String path = SessionMapPage.searchClear1 + index + SessionMapPage.searchClear2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements1[i - 1]);
            textValidation(portalText, savedText, elements1[i - 1]);
        }
        validateFooter(driver);
    }

    public static void dashboardValidation(WebDriver driver) throws Exception
    {
        String portalText;
        String savedText;
        driver.findElement(DashboardPages.dashboardClick).click();
        driver.findElement(DashboardPages.dashboardUsers).click();
        WebFunctions.explicitWait(driver, 20, "Visibility", DashboardPages.totalActiveUsers);


        portalText = driver.findElement(DashboardPages.totalActiveUsers).getText();
        savedText = JSONRead.readJSON(jsonPath, "totalActiveUsers");
        textValidation(portalText, savedText, "totalActiveUsers");

        portalText = driver.findElement(DashboardPages.totalMinutesUsed).getText();
        savedText = JSONRead.readJSON(jsonPath, "totalMinutesUsed");
        textValidation(portalText, savedText, "totalMinutesUsed");

        portalText = driver.findElement(DashboardPages.top10ActiveUsers).getText().trim();
        savedText = JSONRead.readJSON(jsonPath, "topTenActiveUsers");
        textValidation(portalText, savedText.trim(), "topTenActiveUsers");

        String elements1[] = { "host","totalNumOfCalls","totalNumOfMins"};
        for (int i = 1; i <= 3; i++) {
            String index = Integer.toString(i);
            String path = DashboardPages.tableNav1 + index + DashboardPages.tableNav2;
            portalText = driver.findElement(By.xpath(path)).getText();
            savedText = JSONRead.readJSON(jsonPath, elements1[i - 1]);
            textValidation(portalText, savedText, elements1[i - 1]);
        }

        driver.findElement(DashboardPages.dashboardUsage).click();
        Thread.sleep(3000);

        /*
         * portalText = driver.findElement(DashboardPages.totalActiveUsers).getText();
         * savedText = JSONRead.readJSON(jsonPath, "totalActiveUsers");
         * textValidation(portalText, savedText, "totalActiveUsers");
         */

        portalText = driver.findElement(DashboardPages.totalMinutesUsed).getText();
        savedText = JSONRead.readJSON(jsonPath, "totalMinutesUsed");
        textValidation(portalText, savedText, "totalMinutesUsed");


        driver.findElement(DashboardPages.dashboardKPI).click();
        Thread.sleep(3000);

        //host

        /*
         * portalText = driver.findElement(DashboardPages.avgRatingScoreHost).getText();
         * savedText =JSONRead.readJSON(jsonPath, "avgRatingsScore");
         * if(portalText.toUpperCase().contains(savedText.toUpperCase()))
         * textValidation(savedText,savedText, "avgRatingsScore"); else
         * textValidation(portalText,savedText, "avgRatingsScore");
         *
         *
         * portalText = driver.findElement(DashboardPages.totalRatingHost).getText();
         * savedText = JSONRead.readJSON(jsonPath, "totalRatings");
         * if(portalText.toUpperCase().contains(savedText.toUpperCase()))
         * textValidation(savedText, savedText, "totalRatings"); else
         * textValidation(portalText, savedText, "totalRatings");
         *
         * //guest
         * portalText=driver.findElement(DashboardPages.avgRatingScoreGuest).getText();
         * savedText =JSONRead.readJSON(jsonPath, "avgRatingsScore");
         * if(portalText.toUpperCase().contains(savedText.toUpperCase()))
         * textValidation(savedText,savedText, "avgRatingsScore"); else
         * textValidation(portalText,savedText, "avgRatingsScore");
         *
         * portalText = driver.findElement(DashboardPages.totalRatingGuest).getText();
         * savedText = JSONRead.readJSON(jsonPath, "totalRatings");
         * if(portalText.toUpperCase().contains(savedText.toUpperCase()))
         * textValidation(savedText, savedText, "totalRatings"); else
         * textValidation(portalText, savedText, "totalRatings");
         *
         *
         *
         * portalText = driver.findElement(DashboardPages.export).getText(); savedText =
         * JSONRead.readJSON(jsonPath, "export"); textValidation(portalText, savedText,
         * "export");
         */

        String elements2[] = {"lastSevenDays","lastThirtyDays","lastTwelveMonths","currentBillingCycle",
                "customDate"};
        for (int i = 1; i <= 5; i++) {
            String index = Integer.toString(i);
            String path = DashboardPages.navCustom1 + index + DashboardPages.navCustom2;
            portalText = driver.findElement(By.xpath(path)).getText(); savedText =
                    JSONRead.readJSON(jsonPath, elements2[i - 1]);
            textValidation(portalText,savedText, elements2[i - 1]); }

        validateFooter(driver);
    }

    /*
     * public static void iterativeValidation(int start, int end, String
     * elements[],int subtract, String first, String last, WebDriver driver) {
     *
     * for (int i = start; i <= end; i++) { String index = Integer.toString(i);
     * String path = first + index + last; String portalText =
     * driver.findElement(By.xpath(path)).getText();
     * //portalText=removeEndChar(portalText); String savedText =
     * JSONRead.readJSON(jsonPath, elements[i - subtract]);
     * textValidation(portalText, savedText, elements[i - subtract]); } }
     */

    public static void textValidation(String portalText, String savedText, String target) {

        String portalText1[] = portalText.split("\n");
        portalText = portalText1[0];
        portalText = portalText.trim();
        if (portalText.equalsIgnoreCase(savedText)) {
            System.out.println("SUCCESSFUL. Portal text is-> " + portalText + " ||  Saved text is-> " + savedText);
            //test.log(, "Portal text is-> " + portalText + " ||  Saved text is-> " + savedText);
            //test.info("SUCCESSFUL. Portal text is-> " + portalText + " ||  Saved text is-> " + savedText);
            test.pass("SUCCESSFUL. Portal text is-> " + portalText + " ||  Saved text is-> " + savedText);
            //test.log
        } else {
            System.out.println("UNSUCCESSFUL. Portal text is-> " + portalText + "||  Saved text is-> " + savedText);
            //test.info("UNSUCCESSFUL. Portal text is-> " + portalText + "||  Saved text is-> " + savedText);
            test.fail("UNSUCCESSFUL. Portal text is-> " + portalText + "||  Saved text is-> " + savedText);
        }

    }

    public static void validateFooter(WebDriver driver)
    {
        String portalText=null;
        String savedText=null;

        portalText = driver.findElement(SessionActivityPage.careAR).getText();
        savedText = "CAREAR";
        textValidation(portalText, savedText, "termsOfService");

        portalText = driver.findElement(SessionActivityPage.termsOfService).getText();
        savedText = JSONRead.readJSON(jsonPath, "termsOfService");
        textValidation(portalText, savedText, "termsOfService");

        portalText = driver.findElement(SessionActivityPage.privacyPolicy).getText();
        savedText = JSONRead.readJSON(jsonPath, "privacyPolicy");
        textValidation(portalText, savedText, "privacyPolicy");

        portalText = driver.findElement(SessionActivityPage.poweredByCareAr).getText();
        savedText = JSONRead.readJSON(jsonPath, "poweredByCareAR");
        if(portalText.contains(savedText))
            textValidation(savedText, savedText, "poweredByCareAR");
    }

    public static String removeEndChar(String a)
    {
        if (a.endsWith("*") || a.endsWith(":"))
        {
            a=a.substring(0, a.length()-1);		}
        return a;
    }

}

