package testCases;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.security.KeyException;
import java.util.*;
import java.util.List;
import java.util.concurrent.TimeUnit;

import com.aventstack.extentreports.Status;
import io.github.bonigarcia.wdm.managers.SeleniumServerStandaloneManager;
import org.junit.Assert;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import io.github.bonigarcia.wdm.WebDriverManager;
import libraryFunctions.WebFunctions;
import webElements.*;

public class Functional_analyst_role {

    static String choice = "";
    public static ExtentReports extent;
    public static ExtentTest test;
    public static WebDriverWait driverWait;
    public static String localizationVocabsPath = "./src//main//java//localizationVocabs//";
    public static String searchEmail;
    public static String searchKPIQuestion;
    public static String emailId = "Mahesh.mastii@gmail.com";
    static String URL,uname,passwd=null;
    public static void main(String[] args) throws Exception {

        String[] paths = {
                localizationVocabsPath + "French.json",
                localizationVocabsPath + "German.json",
                localizationVocabsPath + "Italian.json",
                localizationVocabsPath + "Portuguese.json",
                localizationVocabsPath + "Spanish.json",
                localizationVocabsPath + "Indonesian.json",
                localizationVocabsPath + "Japanese.json",
                localizationVocabsPath + "Malay.json",
                localizationVocabsPath + "Chinese.json"
        };

        Scanner scanner = new Scanner(System.in);
        //  prompt for the URL
        System.out.print("Enter your URL: ");
        // get their input as a String
        URL = scanner.next();
        Scanner un = new Scanner(System.in);
        System.out.print("Enter your username: ");
        uname = un.next();
        Scanner pwd = new Scanner(System.in);
        System.out.print("Enter your password: ");
        passwd = pwd.next();
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the Language name which you want to run");
        //int n=s.nextInt();
        String languageName = s.next();

        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        //options.addArguments("--headless");
        options.addArguments("--disable-gpu");
        options.addArguments("--allow-insecure-localhost");
        String reportPath = System.getProperty("user.dir")+"\\reports\\reports.html";
        ExtentSparkReporter es = new ExtentSparkReporter(reportPath);
        es.config().setDocumentTitle("CareAR");
        es.config().setReportName("Localization");
        extent = new ExtentReports();
        extent.attachReporter(es);
        int j=1, i=1;
        while(i<=j) {
            choice = languageName;
            WebDriver driver = new ChromeDriver(options);
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            validateLocalization(driver, languageName,j);
            System.out.println("\n\n\n\n" + "-X-X-X-X-X-X-X-X-X-X-X-X-X-X");
            i++;
            Thread.sleep(5000);
        }
        i = 1;
    }


    public static void validateLocalization(WebDriver driver, String langName,int j) throws Exception {

        switch (langName.toLowerCase()) {
            case "english":
                test = extent.createTest("English");
                break;
            case "french":
                test = extent.createTest("French");
                break;
            case "german":
                test = extent.createTest("German");
                break;
            case "italian":
                test = extent.createTest("Italian");
                break;
            case "portugese":
                test = extent.createTest("Portugese");
                break;
            case "spanish":
                test = extent.createTest("Spanish");
                break;
            case "indonesian":
                test = extent.createTest("Indonesian");
                break;
            case "japanese":
                test = extent.createTest("Japanese");
                break;
            case "malay":
                test = extent.createTest("Malay");
                break;
            case "chinese":
                test = extent.createTest("Chinese");
                break;
        }

        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        driver.get(URL);
        Thread.sleep(3000);
        driver.manage().window().maximize();
        driverWait = new WebDriverWait(driver,60);
        driver.findElement(LoginPage.Ad_Email).sendKeys(uname);
        driver.findElement(LoginPage.Ad_Password).sendKeys(passwd);
        driver.findElement(LoginPage.Ad_LoginButton).click();
        System.out.println("clicked on login button");
        WebFunctions.explicitWait(driver, 20, "Visibility", Admin_WelcomePage.waitElement);
        Thread.sleep(8000);
        test.pass("User logged in successfully with email id: " + uname);

        driver.findElement(Admin_WelcomePage.languageChange).click();
        Thread.sleep(2000);
        Dictionary languageLocator = new Hashtable();
        languageLocator.put("english", Admin_WelcomePage.selectEnglish);
        languageLocator.put("french", Admin_WelcomePage.selectFrench);
        languageLocator.put("german", Admin_WelcomePage.selectGerman);
        languageLocator.put("italian", Admin_WelcomePage.selectItalian);
        languageLocator.put("portugese", Admin_WelcomePage.selectPortugese);
        languageLocator.put("spanish", Admin_WelcomePage.selectSpanish);
        languageLocator.put("indonesian", Admin_WelcomePage.selectIndonesian);
        languageLocator.put("japanese", Admin_WelcomePage.selectJapanese);
        languageLocator.put("malay", Admin_WelcomePage.selectMalay);
        languageLocator.put("chinese", Admin_WelcomePage.selectChinese);

        if(languageLocator.get(choice.toLowerCase()) != null){
            driver.findElement((By) languageLocator.get(choice.toLowerCase())).click();
            System.out.println("\n\n\n Selected " + choice.toUpperCase() + " language \n\n");
        }
        else{
            throw new KeyException(choice.toUpperCase() + " language not configured");
        }

        Thread.sleep(2000);
        test.pass(choice + " Language selected");

        driver.findElement(Admin_WelcomePage.saveLanguage).click();
        Thread.sleep(3000);

        System.out.println("\n\n");
        //System.out.println("------------INITIATING VALIDATION FOR Users, Role Management, KPIs ,Session Activity, Session Map,Dashboard Modules, My Profile , My Company---------");
        System.out.println("\n");

        FileInputStream fis=new FileInputStream(localizationVocabsPath + "NewUserModified.xlsx");
        XSSFWorkbook wb = new XSSFWorkbook(fis);
        XSSFSheet sheet = wb.getSheetAt(0);

        //USER PAGE TEST
        System.out.println("------------INITIATING VALIDATION FOR Users, KPIs ,Session Activity, Session Map,Dashboard Modules----------");
        testUsersPage(driver, sheet);

        //ROLE MANAGEMENT
        testRoleManagementPage(driver);

        //KPI PAGE TEST
        testKPIPage(driver);

        //SESSION ACTIVITY PAGE TEST
        sessionActivity(driver);

        //SESSION MAPS PAGE TEST
        sessionMaps(driver);

        //MY PROFILE PAGE
        testMyProfilePage(driver);

        //MY COMPANY PAGE
        testMyCompanyPage(driver);

        //DASHBOARD PAGE TEST
        dashboards(driver);

        System.out.println("-------USERS VALIDATION CONCLUDED-------");
        test.info("------- CONCLUDED VALIDATION FOR Users, Role Management, KPIs ,Session Activity, Session Map,Dashboard Modules, My Profile , My Company -------");
        driver.close();

        //if (langCount == j) {
        extent.flush();
        //}
    }


    public static void testUsersPage(WebDriver driver, XSSFSheet sheet) throws Exception {
        test.info("------------------------- USER PAGE VALIDATION INITIATED -------------------------");
        testUserEdit(driver);
        test.info("------------- USER PAGE VALIDATION CONCLUDED -------------");
    }


    public static void testKPIPage(WebDriver driver) throws Exception {
        test.info("------------------------- KPI PAGE VALIDATION INITIATED -------------------------");
        testFilterKPIDataByUserType(driver);
        testKPIEdit(driver);
        test.info("------------- KPI PAGE VALIDATION CONCLUDED-------------");
    }


    public static void testRoleManagementPage(WebDriver driver) throws Exception{

        test.info("------------------------- ROLE MANAGEMENT PAGE VALIDATION INITIATED-------------------------");
        testRoleManagementCheckAndUncheck(driver);
        test.info("------------------------- ROLE MANAGEMENT PAGE VALIDATION CONCLUDED-------------------------");
    }


    public static void testMyProfilePage(WebDriver driver) throws Exception{

        test.info("------------------------- MY PROFILE PAGE VALIDATION INITIATED-------------------------");
        testMyProfilePictureUpload(driver);
        testMyProfileInfo(driver);
        test.info("------------------------- MY PROFILE PAGE VALIDATION CONCLUDED-------------------------");
    }


    public static void testMyCompanyPage(WebDriver driver) throws Exception{

        test.info("------------------------- MY COMPANY PAGE VALIDATION INITIATED -------------------------");
        testMyCompanySignalingSection(driver);
        testMyCompanyJoinControlsSection(driver);
        test.info("------------------------- MY COMPANY PAGE VALIDATION CONCLUDED -------------------------");
    }


    public static void testNewUserCreation(WebDriver driver, XSSFSheet sheet) throws Exception {

        test.info("-------------------- Test:  New User Creation --------------------");
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        Random random = new Random();
        String reportMsg;
        for(int row=1; row<sheet.getLastRowNum() + 1; row++)
        {
            String email = "test" + random.nextInt(9999999) + sheet.getRow(row).getCell(0).getStringCellValue().trim();
            String firstName = sheet.getRow(row).getCell(1).getStringCellValue().trim();
            String lastName = sheet.getRow(row).getCell(2).getStringCellValue().trim();
            String phoneNumber = sheet.getRow(row).getCell(3).getStringCellValue().trim();
            String secondaryNumber = sheet.getRow(row).getCell(4).getStringCellValue().trim();
            String description = sheet.getRow(row).getCell(5).getStringCellValue().trim();
            String group = sheet.getRow(row).getCell(6).getStringCellValue().trim();

            driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.addNewUserButton)).click();
            driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.emailInput)).sendKeys(email);
            driver.findElement(UsersPage.firstNameInput).sendKeys(firstName);
            driver.findElement(UsersPage.lastNameInput).sendKeys(lastName);
            driver.findElement(UsersPage.phoneNumberInput).sendKeys(phoneNumber);
            driver.findElement(UsersPage.secondaryNumberInput).sendKeys(secondaryNumber);
            driver.findElement(UsersPage.descriptionInput).sendKeys(description);
            driver.findElement(UsersPage.groupInput).sendKeys(group);
            driver.findElement(UsersPage.createButton).click();
            driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
            Thread.sleep(2000);
            List<WebElement> emailError = driver.findElements(UsersPage.emailError);
            List<WebElement> alertTitle = driver.findElements(UsersPage.alertTitle);
            List<WebElement> errors = driver.findElements(UsersPage.errorMsg);
            if (emailError.size() >0 && emailError.get(0).isDisplayed()) {
                reportMsg = String.format("User with first name '%s' is unable to add due to invalid email format", firstName);
                driver.findElement(UsersPage.cancelButton).click();
            }
            else if (alertTitle.size() > 0) {
                String title = alertTitle.get(0).getText().trim();
                driver.findElement(UsersPage.alertOkButton).click();
                Thread.sleep(1000);
                driver.findElement(UsersPage.cancelButton).click();
                reportMsg = String.format("User with email ID '%s' is unable to add due to %s", firstName, title.toLowerCase());
            }
            else if(errors.size() > 0 && errors.get(0).isDisplayed()){
                reportMsg = "Unable to add new user due to invalid data";
                driver.findElement(UsersPage.cancelButton).click();
            }
            else{
                searchEmail = email;
                reportMsg = String.format("User with email ID '%s' is added successfully", email);
            }
            driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
            test.pass(reportMsg);
        }

        //Test User group with invalid data
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driver.findElement(UsersPage.addNewUserButton).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.groupInput)).click();
        driver.findElement(UsersPage.groupInput).sendKeys("InvalidGroup");
        String msg = driver.findElement(By.cssSelector("div[role='list'].react-dropdown-select-dropdown")).getText().trim();
        Assert.assertEquals("No data", msg);
        test.pass("Entered 'InvalidGroup' group is not available for selection");
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
    }


    public static void testSearchUserAndDisable(WebDriver driver) throws Exception {
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.searchUserInput)).click();
        driver.findElement(UsersPage.searchUserInput).clear();
        driver.findElement(UsersPage.searchUserInput).sendKeys(searchEmail);
        driver.findElement(By.id("disableUser_0")).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertOkButton)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(String.format("User '%s' got disabled successfully by search", searchEmail));
        Thread.sleep(1000);
    }


    public static void testSearchUserAndEnable(WebDriver driver) throws Exception {
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.searchUserInput)).click();
        driver.findElement(UsersPage.searchUserInput).clear();
        driver.findElement(UsersPage.searchUserInput).sendKeys(searchEmail);
        driver.findElement(By.id("enableUser_0")).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertOkButton)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(String.format("User '%s' got disabled successfully by search", searchEmail));
        Thread.sleep(1000);
    }


    public static void testSearchUserAndDelete(WebDriver driver) throws Exception{
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.searchUserInput)).click();
        driver.findElement(UsersPage.searchUserInput).clear();
        driver.findElement(UsersPage.searchUserInput).sendKeys(searchEmail);
        driver.findElement(By.id("deleteUser_0")).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertOkButton)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(String.format("User '%s' got deleted successfully by search", searchEmail));
        Thread.sleep(1000);
    }


    public static void testUserDisable(WebDriver driver) throws Exception {
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.users)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#userInfo i[id^='disableUser']"))).click();
        String[] message = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertMessage)).getText().split("user?");
        driver.findElement(UsersPage.alertOkButton).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(message[1].replace('?', ' ').trim() + " User got disabled successfully");
    }


    public static void testUserEnable(WebDriver driver) throws Exception {
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#userInfo i[id^='enableUser']"))).click();
        String[] message = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertMessage)).getText().split("user?");
        driver.findElement(UsersPage.alertOkButton).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(message[1].replace('?', ' ').trim() + " User got enabled successfully");
    }


    public static void testUserDelete(WebDriver driver) throws Exception{
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#userInfo i[id^='deleteUser']"))).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.notificationMsg));
        String[] message = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertMessage)).getText().split("user?");
        driver.findElement(UsersPage.alertOkButton).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(message[1].replace('?', ' ').trim() + " User got deleted successfully");
    }


    public static void testRowsPerPageForUserData(WebDriver driver) throws Exception{
        test.info("------------- Test: Rows Per Page Selection Functionality For Users Data -------------");
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        String pages[] = {"10", "25", "50", "100"};
        for(String page: pages){
            Select rowPage = new Select(driver.findElement(By.xpath("//*[@class='form-control dropDown-select']")));
            rowPage.selectByVisibleText(page);
            Thread.sleep(2000);
            List<WebElement> totalUsers = driver.findElements(UsersPage.userDataRows);
            int expectedRows = Integer.valueOf(page);
            Assert.assertEquals(expectedRows, totalUsers.size());
            test.pass("Rows per page " + page + " is selected and actual user data rows are " + page);
        }
        driver.findElement(UsersPage.importButton).isDisplayed();
        driver.findElement(UsersPage.bulkEdit).isDisplayed();
        Thread.sleep(2000);
    }


    public static void testUserEdit(WebDriver driver) throws Exception{
        test.info("------------- Test : User Edit Functionality -------------");
        String searchEmail=uname;
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        Boolean addButton=existsElement_byXpath(driver,"//*[@id='linkToCreateUser']");
        Boolean bulkEdit=existsElement_byXpath(driver,"//*[@id='bulkEditBtn']");
        Boolean imPort=existsElement_byXpath(driver,"//*[contains(text(),'Import')]");
        if(addButton)
        {
            test.fail("Add user button is displayed");
        }
        else
        {
            test.pass("Add user button is not displayed");
        }
        if(bulkEdit)
        {
            test.fail("Bulk Edit Button is displayed");
        }
        else
        {
            test.pass("Bulk Edit Button is not displayed");
        }
        if(!imPort)
        {
            test.pass("Import Button is not displayed");
        }
        else
        {
            test.fail("Import Button is displayed");
        }
        if(driver.findElement(By.xpath("//*[contains(text(),'Export All')]")).isEnabled())
        {
            test.pass("Export All is displayed and enabled");
        }
        else
        {
            test.fail("Export All is not displayed and enabled");
        }
        List<WebElement> deLet=driver.findElements(By.xpath("//*[contains(@id,'deleteUser')]"));
        try {
            Assert.assertTrue(deLet.size() == 0);
            test.pass("delete user icon is not displayed and enabled");
        }
        catch (AssertionError e){
            //Assert.assertFalse(deLet.size() != 0);
            test.fail("delete user icon is displayed and enabled");
        }
        List<WebElement> disUser=driver.findElements(By.xpath("//*[contains(@id,'disableUser')]"));
        try {
            Assert.assertTrue(disUser.size() == 0);
            test.pass("disabled user icon is not displayed");
        }
        catch (AssertionError e){
            //Assert.assertFalse(disUser.size() != 0);
            test.fail("disabled user icon is displayed");
        }
        List<WebElement> enUser=driver.findElements(By.xpath("//*[contains(@id,'enableUser')]"));
        try {
            Assert.assertTrue(enUser.size() == 0);
            test.pass("Enable user icon is not displayed");
        }
        catch (AssertionError e){
            //Assert.assertFalse(enUser.size() != 0);
            test.fail("Enable user icon is displayed");
        }
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.searchUserInput)).clear();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.searchUserInput)).sendKeys(searchEmail);
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.editUser)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        Thread.sleep(2000);
        int leftLimit = 97; // letter 'a'
        int rightLimit = 122; // letter 'z'
        int targetStringLength = 5;
        Random random = new Random();
        String firstName = random.ints(leftLimit, rightLimit + 1)
                .limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.firstNameInput)).click();
        Thread.sleep(2000);
        driver.findElement(UsersPage.firstNameInput).clear();
        driver.findElement(UsersPage.firstNameInput).sendKeys(firstName);
        int tarG=5;
        String lastName = random.ints(leftLimit, rightLimit + 1)
                .limit(tarG)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.lastNameInput)).click();
        Thread.sleep(2000);
        driver.findElement(UsersPage.lastNameInput).clear();
        driver.findElement(UsersPage.lastNameInput).sendKeys(lastName);
        long phoneNo=(long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L;
        String phNumber="+" +phoneNo;
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.phoneNumberInput)).click();
        Thread.sleep(2000);
        driver.findElement(UsersPage.phoneNumberInput).clear();
        driver.findElement(UsersPage.phoneNumberInput).sendKeys(phNumber);
        long sphoneNo=(long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L;
        String sphNumber="+" +sphoneNo;
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.secondaryNumberInput)).click();
        Thread.sleep(2000);
        driver.findElement(UsersPage.secondaryNumberInput).clear();
        driver.findElement(UsersPage.secondaryNumberInput).sendKeys(sphNumber);
        String description = "Test Description " + new Random().nextInt(55555);
        if(!(driver.findElement(By.id("inputRole")).isEnabled()))
        {
            test.pass("Role change option is disabled");
        }
        else
        {
            test.fail("Role change option is enabled");
        }
        if(!(driver.findElement(UsersPage.groupInput).isEnabled()))
        {
            test.pass("Group change option is disabled");
        }
        else
        {
            test.fail("Group change option is enabled");
        }
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.descriptionInput)).click();
        Thread.sleep(2000);
        driver.findElement(UsersPage.descriptionInput).clear();
        driver.findElement(UsersPage.descriptionInput).sendKeys(description);
        driver.findElement(UsersPage.createButton).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(String.format("Updated '%s' user description as '%s'", searchEmail, description));
    }


    public static void testUserSearchAndEdit(WebDriver driver) throws Exception{

        test.info("------------- TEST: USER SEARCH, EDIT AND ROLE CHANGE FUNCTIONALITIES -------------");

        String email = "test2022portal@gmail.com";
        String password = "Password1";

        driver.findElement(UsersPage.users).click();
        changeUserRole(driver, email, "Normal");
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.userLogout)).click();
        driver.findElement(LoginPage.Ad_Email).sendKeys(email);
        driver.findElement(LoginPage.Ad_Password).sendKeys(password);
        driver.findElement(LoginPage.Ad_LoginButton).click();
        String errorMsg = driver.findElement(By.cssSelector("p.errorMessage")).getText().trim();
        Assert.assertEquals("User is not a Tenant Admin", errorMsg);
        test.pass(email + " is Normal user since can not be logged in admin page");
        driver.get("https://carear-development.web.app/#/admin/login");
        driver.findElement(LoginPage.Ad_Email).sendKeys("kumarvikramg16@gmail.com");
        driver.findElement(LoginPage.Ad_Password).sendKeys("@Pandu123");
        driver.findElement(LoginPage.Ad_LoginButton).click();
        driver.findElement(UsersPage.users).click();
        changeUserRole(driver, email, "Administrator");
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.userLogout)).click();
        driver.findElement(LoginPage.Ad_Email).sendKeys(email);
        driver.findElement(LoginPage.Ad_Password).sendKeys(password);
        driver.findElement(LoginPage.Ad_LoginButton).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.userLogout)).click();
        test.pass(email + " user successfully logged as Administrator");
        driver.findElement(LoginPage.Ad_Email).sendKeys("kumarvikramg16@gmail.com");
        driver.findElement(LoginPage.Ad_Password).sendKeys("@Pandu123");
        driver.findElement(LoginPage.Ad_LoginButton).click();
    }


    public static  void changeUserRole(WebDriver driver, String user, String role) throws Exception{

        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.users)).click();
        Thread.sleep(3000);
        driver.findElement(UsersPage.searchInput).sendKeys(user);
        Thread.sleep(2000);
        driver.findElement(UsersPage.editUser).click();
        Thread.sleep(3000);
        Select roleElement = new Select(driver.findElement(UsersPage.userRole));
        String currentRole = roleElement.getFirstSelectedOption().getText();
        roleElement.selectByVisibleText(role);
        if(currentRole.equals(user)) {
            test.info(user + " User already in " + role);
        }
        else{
            driver.findElement(UsersPage.updateUser).click();
            test.pass(user + " User successfully switched from " + currentRole + " to " + role);
        }
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.notificationMsg));
        Thread.sleep(9000);
    }


    public static void testNewKPICreation(WebDriver driver) throws Exception{

        test.info("------------- Test: New KPI Creation Functionality -------------");

        String[] required = {"Mandatory", "Optional", "Mandatory", "Optional"};
        String[] type = {"Rating", "Dropdown", "Singleline", "Multiline"};
        String[] userType = {"Host", "Guest", "Host", "Guest"};

        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));

        //Positive data
        for(int index=0; index<required.length; index++){
            driver.findElement(KPIPage.addNewKPIButton).click();
            String questionIndex = driver.findElement(By.id("inputIndex")).getAttribute("value").trim();
            String question = "Test Question " + questionIndex;
            driver.findElement(KPIPage.questionInput).sendKeys(question);
            driver.findElement(By.cssSelector("input[name='RequiredType'][value='" + required[index].toLowerCase() + "']")).click();
            driver.findElement(By.cssSelector("input[name='answerType'][value='" + type[index].toLowerCase() + "']")).click();
            if(type[index].equals("Dropdown")){
                driver.findElement(By.id("additionalData")).sendKeys("Test addition data");
            }
            driver.findElement(By.cssSelector("input[name='userType'][value='" + userType[index].toLowerCase() + "']")).click();
            driver.findElement(By.cssSelector("#surveyForm button.btn-primary")).click();
            driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
            Thread.sleep(3000);
            String reportMsg = String.format("New KPI question added with [Question=%s; Required=%s; Type=%s; User Type=%s]",
                    question, required[index], type[index], userType[index]);
            test.pass(reportMsg);
            searchKPIQuestion = question;
        }

        //Negative Data - Without question
        driver.findElement(KPIPage.addNewKPIButton).click();
        driver.findElement(By.cssSelector("input[name='answerType'][value='rating']")).click();
        driver.findElement(By.cssSelector("#surveyForm button.btn-primary")).click();
        Thread.sleep(2000);
        String errorMsg = driver.findElement(By.cssSelector("#inputQuestion + div.invalid-feedback")).getText().trim();
        Assert.assertEquals(errorMsg, "Please enter the question");
        test.pass("New KPI question not added due to no question entered");

        //Negative Data - Without question
        driver.findElement(KPIPage.questionInput).sendKeys("Test Question");
        driver.findElement(By.cssSelector("input[name='answerType'][value='dropdown']")).click();
        driver.findElement(By.cssSelector("#surveyForm button.btn-primary")).click();
        Thread.sleep(2000);
        errorMsg = driver.findElement(By.cssSelector("#additionalData + div.invalid-feedback")).getText().trim();
        Assert.assertEquals(errorMsg, "Please enter the choices separated by comma");
        test.pass("New KPI question not added due to no addition data entered for Type");
        driver.findElement(By.cssSelector("#surveyForm button.btn-danger")).click();
    }


    public static void testFilterKPIDataByUserType(WebDriver driver) throws Exception{
        test.info("------------- Test: KPI Data Filter Functionality By User Types -------------");
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        String [] userTypes = {"Host", "Guest"};
        Select pages = new Select(driver.findElement(KPIPage.pagesDropDown));
        pages.selectByVisibleText("10");
        for(String type: userTypes){
            Select userType = new Select(driver.findElement(KPIPage.userTypeDropDown));
            userType.selectByVisibleText(type);
            Thread.sleep(3000);
            List<WebElement> typeCellElements = driver.findElements(KPIPage.userTypeTableCell);
            for(WebElement cell: typeCellElements){
                Assert.assertEquals(cell.getText().trim(), type);
            }
            test.pass(String.format("%s option selected from user type dropdown and only Host KPI data filtered", type));
        }
        //Select Host and Guest
        Select userType = new Select(driver.findElement(KPIPage.userTypeDropDown));
        userType.selectByVisibleText("Host / Guest");
        Thread.sleep(3000);
        List<WebElement> typeCellElements = driver.findElements(KPIPage.userTypeTableCell);
        Assert.assertTrue(typeCellElements.size() > 0);
        test.pass("Host / Guest option selected from user type dropdown and Host and Guest KPI data listed");
    }

    public static boolean existsElement_byXpath(WebDriver driver, String xpath) {
        try {
            driver.findElement(By.xpath(xpath));
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
        return true;
    }

    public static void testKPIEdit(WebDriver driver) throws Exception{
        test.info("------------- Test: New KPI Edit Functionality -------------");
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        Boolean addButton=existsElement_byXpath(driver,"//*[@id='linkToCreateUser']");
        if(addButton)
        {
            test.fail("Add KPI button is displayed");
        }
        else
        {
            test.pass("Add KPI button is not displayed");
        }
        List<WebElement> deletButton=driver.findElements(By.xpath("//*[contains(@id,'deleteSurvey')]"));
        try {
            Assert.assertTrue(deletButton.size() == 0);
            test.pass("Delete KPI icon is not displayed");
        }
        catch(AssertionError e)
        {

            //Assert.assertFalse(deletButton.size() != 0);
            test.fail("Survey user icon is displayed");
        }

        List<WebElement> enbButton=driver.findElements(By.xpath("//*[contains(@id,'enableSurvey')]"));
        try {
            Assert.assertTrue(enbButton.size() == 0);
            test.pass("Enable KPI switch is not displayed");
        }
        catch(AssertionError e)
        {
            //Assert.assertFalse(enbButton.size() != 0);
            test.fail("Enable Survey icon is displayed");
        }
        List<WebElement> disButton=driver.findElements(By.xpath("//*[contains(@id,'disableSurvey')]"));
        try {
            Assert.assertTrue(disButton.size() == 0);
            test.pass("Disable Survey icon is not displayed");
        }
        catch(AssertionError e)
        {
            //Assert.assertFalse(disButton.size() != 0);
            test.fail("Disable Survey icon is displayed");
        }
        driver.findElement(By.cssSelector("#surveysInfo input[placeholder='Search']")).sendKeys("where");
        Thread.sleep(2000);
        if(!(driver.findElement(By.xpath("//*[@id='tableHeader']/div/table/tbody/tr")).isEnabled()))
        {
            test.fail("KPI Tables are disabled");
        }
        else
        {
            test.pass("KPI Tables are not Active");
        }

    }


    public static void testSearchKPIAndDisable(WebDriver driver) throws Exception{
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(KPIPage.searchKPIInput)).click();
        driver.findElement(KPIPage.searchKPIInput).clear();
        driver.findElement(KPIPage.searchKPIInput).sendKeys(searchKPIQuestion);
        driver.findElement(By.id("disableSurvey_0")).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertOkButton)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(String.format("KPI question '%s' got disabled successfully by search", searchKPIQuestion));
        Thread.sleep(1000);
    }


    public static void testSearchKPIAndEnable(WebDriver driver) throws Exception{
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(KPIPage.searchKPIInput)).click();
        driver.findElement(KPIPage.searchKPIInput).clear();
        driver.findElement(KPIPage.searchKPIInput).sendKeys(searchKPIQuestion);
        driver.findElement(By.id("enableSurvey_0")).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertOkButton)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(String.format("KPI question '%s' got enabled successfully by search", searchKPIQuestion));
        Thread.sleep(1000);
    }


    public static void testSearchKPIAndDelete(WebDriver driver) throws Exception{
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(KPIPage.searchKPIInput)).click();
        driver.findElement(KPIPage.searchKPIInput).clear();
        driver.findElement(KPIPage.searchKPIInput).sendKeys(searchKPIQuestion);
        driver.findElement(By.id("deleteSurvey_0")).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertOkButton)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(String.format("KPI question '%s' got deleted successfully by search", searchKPIQuestion));
        Thread.sleep(1000);
    }


    public static void testKPIDisable(WebDriver driver) throws Exception{
        driver.findElement(UsersPage.users).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driver.findElement(By.cssSelector("[id^='disableSurvey']")).click();
        String[] message = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertMessage)).getText().split("survey?");
        driver.findElement(UsersPage.alertOkButton).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(String.format("KPI question '%s' got disabled successfully", message[1].replace('?', ' ').trim()));
    }


    public static void testKPIEnable(WebDriver driver) throws Exception{
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driver.findElement(By.cssSelector("[id^='enableSurvey_']")).click();
        String[] message = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertMessage)).getText().split("survey?");
        driver.findElement(UsersPage.alertOkButton).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(String.format("KPI question '%s' got enabled successfully", message[1].replace('?', ' ').trim()));
    }


    public static void testKPIDelete(WebDriver driver) throws Exception{
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driver.findElement(By.id("deleteSurvey_0")).click();
        String[] message = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertMessage)).getText().split("survey?");
        driver.findElement(UsersPage.alertOkButton).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(String.format("KPI question '%s' got deleted successfully", message[1].replace('?', ' ').trim()));
    }


    public static void testRowsPerPageForKPIData(WebDriver driver) throws Exception{
        test.info("------------- Test: Rows Per Page Selection Functionality For KPI's Data -------------");
        driver.findElement(KPIPage.clickKPI).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("div.block-ui-overlay")));
        String[] pages = {"10", "25", "50", "100"};
        for(String page: pages){
            Select rowPage = new Select(driver.findElement(By.xpath("//*[@class='form-control dropDown-select']")));
            rowPage.selectByVisibleText(page);
            Thread.sleep(2000);
            List<WebElement> total_data = driver.findElements(KPIPage.kpiDataRows);
            int expectedRows = Integer.parseInt(page);
            Assert.assertEquals(expectedRows, total_data.size());
            test.pass("Rows per page " + page + " is selected and actual KPI data rows are " + page);
        }
    }


    public static void sessionActivity(WebDriver driver)throws Exception {
        driver.findElement(SessionActivityPage.sessionActivityNav).click();
        test.pass("Session Activity page open successfully");

        for(int i=1;i<=4;i++)
        {
            if(i>1)
            {
                driver.findElement(By.xpath("//*[@class='nav nav-tabs']/li["+i+"]/a")).click();
            }

            String s="(//*[@class='form-control dropDown-select'])["+2*i+"]";
            rowPerPage(driver,s);
            driver.findElement(By.xpath("(//*[@class='btn btn-primary button-leftMargin'])["+i+"]")).click();
            test.pass("Exported All successfully");
            Thread.sleep(3000);
        }
        driver.findElement(By.xpath("(//*[@class='btn btn-primary  searchButton'])[2]")).click();
        test.pass("Activity on Map Selected successfully");
    }


    public static void sessionMaps(WebDriver driver)throws Exception {
        driver.findElement(SessionMapPage.clickSessionMap).click();
        test.pass("Session Map page open successfully");
        for(int i=1;i<=4;i++)
        {
            if(i>1)
            {
                driver.findElement(By.xpath("//*[@class='nav nav-tabs']/li["+i+"]/a")).click();
            }
            String s="(//*[@class='form-control dropDown-select'])["+i+"]";
            Thread.sleep(3000);
            Select s1=new Select(driver.findElement(By.xpath(s)));
            s1.selectByIndex(0);
        }
        driver.findElement(By.xpath("(//*[@class='fa fa-calendar'])[1]")).click();

        driver.findElement(By.xpath("//*[contains(@class,' react-datepicker__day--keyboard-selected react-datepicker__day--today')]")).click();
        test.pass("From Date  Selected successfully");
        driver.findElement(By.xpath("(//*[@class='fa fa-calendar'])[2]")).click();
        driver.findElement(By.xpath("//*[contains(@class,' react-datepicker__day--keyboard-selected react-datepicker__day--today')]")).click();
        test.pass("To Date  Selected successfully");
        driver.findElement(By.xpath("(//*[@class='btn btn-primary  searchButton'])[4]")).click();
        test.pass("See Activity Selected successfully");
    }


    public static void cancelFE()throws Exception {
        Robot r = new Robot();
        r.keyPress(KeyEvent.VK_ALT);
        r.keyPress(KeyEvent.VK_SPACE);
        r.keyPress(KeyEvent.VK_C);
        r.keyRelease(KeyEvent.VK_ALT);
        r.keyRelease(KeyEvent.VK_SPACE);
        r.keyRelease(KeyEvent.VK_C);
    }


    public static void rowPerPage(WebDriver driver,String s)throws Exception {
        Select s1=new Select(driver.findElement(By.xpath(s)));
        s1.selectByVisibleText("10");
        test.pass("10 rows per page got selected successfully");
        Thread.sleep(2000);
        s1.selectByVisibleText("25");
        test.pass("25 rows per page got selected successfully");
        Thread.sleep(2000);
        s1.selectByVisibleText("50");
        Thread.sleep(2000);
        test.pass("50 rows per page got selected successfully");
        s1.selectByVisibleText("100");
        Thread.sleep(2000);
        test.pass("100 rows per page got selected successfully");

    }


    public static void dashboards(WebDriver driver)throws Exception {
        test.info("------------------------- DASHBOARD PAGE VALIDATION INITIATED-------------------------");
        driver.findElement(DashboardPages.dashboardClick).click();
        test.pass("Dashboard page open successfully");
        for(int j=1;j<=3;j++)
        {
            if(j==1)
            {
                driver.findElement(DashboardPages.dashboardUsers).click();
                test.pass("Dashboard users page open successfully");
                Thread.sleep(3000);
            }
            if(j==2)
            {
                driver.findElement(DashboardPages.dashboardUsage).click();
                test.pass("Dashboard usage page open successfully");
                Thread.sleep(3000);
            }
            if(j==3)
            {
                driver.findElement(DashboardPages.dashboardKPI).click();
                test.pass("Dashboard kpi page open successfully");
                Thread.sleep(3000);

            }
            for(int i=1;i<5;i++)
            {
                Thread.sleep(3000);
                driver.findElement(By.xpath("(//*[@class='dashboardSessionRadio btn btn-outline-secondary'])["+i+"]")).click();
                test.pass(driver.findElement(By.xpath("(//*[@class='dashboardSessionRadio btn btn-outline-secondary'])["+i+"]")).getText()+" selected successfully");
                List<WebElement> ele=driver.findElements(By.xpath("//*[@class='fa fa-arrow-right common-button-theme']"));
                if(ele.size()>0)
                {
                    if(ele.get(0).isDisplayed())
                    {
                        driver.findElement(By.xpath("//*[@class='fa fa-arrow-right common-button-theme']")).click();
                        Thread.sleep(3000);
                    }
                }

            }
        }
        test.info("------------------------- DASHBOARD PAGE VALIDATION CONCLUDED-------------------------");



    }


    public static void testRoleManagementCheckAndUncheck(WebDriver driver) throws Exception{
        test.info("------------------------- Test Role Management Check and Uncheck -------------------------");
        driverWait.until(ExpectedConditions.elementToBeClickable(RoleManagementPage.clickRoleManagement)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(RoleManagementPage.roleTableRows));
        List<WebElement> roleRows = driver.findElements(RoleManagementPage.roleTableRows);
        for (WebElement roleRow: roleRows) {
            String roleName = roleRow.findElement(By.cssSelector("td:nth-child(2)")).getText().trim();
            test.info("Role:" + roleName);
            //Uncheck the role checkbox if already checked
            WebElement roleCheckBox = roleRow.findElement(By.cssSelector("td:nth-child(1) input[type='checkbox']"));
            if(!roleCheckBox.isEnabled()){
                test.pass("roleCheckBox is not enabled");
            }
            else{
                test.fail("roleCheckBox is enabled");
            }
            //uncheck the role and verify role checkbox is unchecked
            // roleCheckBox.click();
            Thread.sleep(2000);
            //Click on Allow Snapshot check and Allow Snapshot permission should be enabled
            WebElement allowSnapshot = roleRow.findElement(By.cssSelector("td:nth-child(3) input[type='checkbox']"));
            if(!allowSnapshot.isEnabled()){
                test.pass("allowSnapshot is not enabled");
            }
            else
            {
                test.fail("allowSnapshot is enabled");
            }
            //test.pass(reportMsg);

            //Click on Allow Media Download check and Allow Media Download permission should be enabled
            WebElement allowMediaDownload = roleRow.findElement(By.cssSelector("td:nth-child(4) input[type='checkbox']"));
            if(!allowMediaDownload.isEnabled()){
                test.pass("allowMediaDownload is not enabled");
            }
            else
            {
                test.fail("allowMediaDownload is enabled");
            }
            //Skip Allow Recording functionality for Gust role.
            if(roleName.equals("Guest")){
                continue;
            }

            //Click on Allow Recording check and Allow Recording permission should be disabled
            WebElement allowRecording = roleRow.findElement(By.cssSelector("td:nth-child(5) input[type='checkbox']"));
            if(!allowRecording.isEnabled()){
                test.pass("allowRecording is not enabled");
            }
            else
            {
                test.fail("allowRecording is enabled");
            }
        }
        if(!(driver.findElement(By.xpath("//*[contains(text(),'Save')]"))).isEnabled())
        {
            test.pass("Save button is disabled");
        }
        else
        {
            test.fail("Save Button is enabled");
        }

    }


    public static void testMyProfilePictureUpload(WebDriver driver) throws Exception{

        driverWait.until(ExpectedConditions.elementToBeClickable(MyProfilePage.myprofileLink)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        Thread.sleep(5000);
        fileUpload(System.getProperty("user.dir")+"/src/main/java/configuration/user.jpg",driver);
        Thread.sleep(5000);
        driver.findElement(MyProfilePage.upload).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass("New profile picture uploaded successfully");
    }


    public static void testMyProfileInfo(WebDriver driver) throws Exception{

        driverWait.until(ExpectedConditions.elementToBeClickable(MyProfilePage.myprofileLink)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        String emailId = driver.findElement(MyProfilePage.userEmailID).getText().trim();
        emailId = emailId.replace(":", "").replace("\n", "");
        Assert.assertEquals("Verify user email ID in my profile page", emailId, emailId);
        test.pass(String.format("User email ID %s is displayed in My Profile page", emailId));
        List<String> expectedLabels = new ArrayList<>();
        expectedLabels.add("Email");
        expectedLabels.add("Name");
        expectedLabels.add("Job Description");
        expectedLabels.add("Primary Phone Number");
        expectedLabels.add("Secondary Phone Number");
        List<String> actualLabels = new ArrayList<>();
        List<WebElement> userLabels = driver.findElements(MyProfilePage.userInfoLabels);
        for (WebElement label: userLabels) {
            actualLabels.add(label.getText().trim());
        }
        Assert.assertEquals(expectedLabels, actualLabels);
        test.pass("Verify Email, Name, Job Description, Primary Phone Number, Secondary Phone Number labels are displayed in My Profile page");
    }


    public static void testMyCompanyLogoUpload(WebDriver driver) throws Exception{

        test.info("------------- Test My Company Logo Upload Functionality -------------");

        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.clickMyCompany)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        Thread.sleep(5000);
        fileUpload(System.getProperty("user.dir")+"/src/main/java/configuration/company.jpg",driver);
        Thread.sleep(5000);
        driver.findElement(MyCompanyPage.upload).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass("New company logo uploaded successfully");
    }


    public static void testMyCompanyAddGroup(WebDriver driver) throws Exception{

        test.info("------------- Test Add New Group Functionality -------------");

        Random random = new Random();
        String groupName = "TestGroup" + random.nextInt(9999);
        String expectedMsg = "Group name should start with alphanumeric character and should contain only alphanumeric characters, underscore and hyphen";
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.clickMyCompany)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));

        //Negative input1: Empty group
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupAdd)).click();
        driver.findElement(MyCompanyPage.groupNameAdd).click();
        String alertMsg = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.notificationMsg)).getText().trim();
        Assert.assertEquals("Cannot add empty group", alertMsg);
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass("New group not added due to empty group name");

        //Negative input2: Group Name with space
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupAdd)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupName)).sendKeys("Test Group123");
        driver.findElement(MyCompanyPage.groupNameAdd).click();
        alertMsg = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.notificationMsg)).getText().trim();
        Assert.assertEquals(expectedMsg, alertMsg);
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass("New group [Test Group123] not added due to space in name");

        //Negative input3: Group Name start with special character
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupAdd)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupName)).sendKeys("#TestGroup");
        driver.findElement(MyCompanyPage.groupNameAdd).click();
        alertMsg = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.notificationMsg)).getText().trim();
        Assert.assertEquals(expectedMsg, alertMsg);
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass("New group [#TestGroup] not added due to name start with special character");

        //Positive input: Group Name: TestGroup
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupAdd)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupName)).sendKeys(groupName);
        driver.findElement(MyCompanyPage.groupNameAdd).click();
        alertMsg = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.notificationMsg)).getText().trim();
        Assert.assertEquals("Group has been added successfully", alertMsg);
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(String.format("New group [%s] has been added successfully", groupName));

        //Negative input: Duplicate group name
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupAdd)).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupName)).sendKeys(groupName);
        driver.findElement(MyCompanyPage.groupNameAdd).click();
        alertMsg = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.notificationMsg)).getText().trim();
        Assert.assertEquals("Group names should not be repeated", alertMsg);
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(String.format("New group [%s] not added due to duplicate name", groupName));
    }


    public static void testMyCompanyGroupEdit(WebDriver driver) throws Exception {

        test.info("------------- Test Edit Group Functionality -------------");

        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.clickMyCompany)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.firstGroupName)).click();
        driver.findElement(MyCompanyPage.editGroup).click();
        String groupName = driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.groupName)).getAttribute("value");
        driver.findElement(MyCompanyPage.groupName).clear();
        driver.findElement(MyCompanyPage.groupName).sendKeys(groupName +  "0");
        driver.findElement(MyCompanyPage.groupNameAdd).click();
        String alertMsg = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.notificationMsg)).getText().trim();
        Assert.assertTrue(alertMsg.startsWith("Group has been updated successfully"));
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(String.format("Group [%s] has been updated successfully as [%s]", groupName, groupName + "0"));
    }


    public static void testMyCompanyGroupDelete(WebDriver driver) throws Exception {

        test.info("------------- Test Delete Group Functionality -------------");

        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.clickMyCompany)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.firstGroupName)).click();
        String groupName = driver.findElement(MyCompanyPage.firstGroupName).getText().trim();
        driver.findElement(MyCompanyPage.groupDelete).click();
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.alertOkButton)).click();
        String alertMsg = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.notificationMsg)).getText().trim();
        Assert.assertTrue(alertMsg.startsWith("Group has been deleted successfully"));
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass(String.format("Group [%s] has been deleted successfully", groupName));
    }


    public static void testMyCompanyGroupImportExport(WebDriver driver) throws Exception {

        test.info("------------- Test Groups Import And Export Functionality -------------");

        //Import Groups
        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.clickMyCompany)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        Thread.sleep(5000);
        fileUpload(System.getProperty("user.dir") + "/src/main/java/configuration/Template_Import_Groups.csv",driver);
        String alertMsg = driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.notificationMsg)).getText().trim();
        Assert.assertEquals("Groups has been imported successfully", alertMsg);
        driverWait.until(ExpectedConditions.elementToBeClickable(UsersPage.closeNotification)).click();
        test.pass("Groups has been imported successfully");

        //Export Groups
        driver.findElement(MyCompanyPage.exportGroups).click();
        Thread.sleep(5000);
        test.pass("Groups has been exported successfully");
    }


    public static void testMyCompanySignalingSection(WebDriver driver) throws Exception{

        test.info("------------- Test Signaling And Media Controls Section-------------");

        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.clickMyCompany)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        String labels[] = {"Host Media Region *", "Guest Media Region *", "Host Proxy *", "Guest Proxy *", "Encryption *"};
        List<String> expectedLabels = Arrays.asList(labels);
        WebElement signalingSection = driver.findElement(By.xpath("//div[@id='tenantCompany']//div[@class='mediaGeofenceSettingContainer'][6]"));
        List<WebElement> labelElements = signalingSection.findElements(By.cssSelector(".form-group label"));
        List<String> actualLabels = new ArrayList<>();
        for (WebElement label: labelElements) {
            actualLabels.add(label.getText().trim().replace("\n", ""));
        }
        Assert.assertEquals(expectedLabels, actualLabels);
        test.pass("Verify [Host Media Region *, Guest Media Region *, Host Proxy *, Guest Proxy *, Encryption *] dropdowns are displayed in Signaling and Media Controls section");
    }


    public static void testMyCompanyJoinControlsSection(WebDriver driver) throws Exception{

        test.info("------------- Test Join Controls Section-------------");

        driverWait.until(ExpectedConditions.elementToBeClickable(MyCompanyPage.clickMyCompany)).click();
        driverWait.until(ExpectedConditions.invisibilityOfElementLocated(UsersPage.overlay));
        String labels[] = {"Guest join by browser", "Guest join by smart glasses"};
        List<String> expectedLabels = Arrays.asList(labels);
        WebElement joinControlsSection = driver.findElement(By.xpath("//div[@id='tenantCompany']//div[@class='mediaGeofenceSettingContainer'][7]"));
        List<WebElement> labelElements = joinControlsSection.findElements(By.cssSelector(".form-group label"));
        List<String> actualLabels = new ArrayList<>();
        for (WebElement label: labelElements) {
            actualLabels.add(label.getText().trim().replace("\n", ""));
        }
        Assert.assertEquals(expectedLabels, actualLabels);
        test.pass("Verify [Guest join by browser, Guest join by smart glasses] dropdowns are displayed in Join Controls section");
    }


    public static void fileUpload(String filePath,WebDriver driver) throws Exception {

        System.out.println("path for upload"+filePath);
        WebElement element = driver.findElement(By.id("logoUploaderRef"));
        element.sendKeys(filePath);
    }

}

