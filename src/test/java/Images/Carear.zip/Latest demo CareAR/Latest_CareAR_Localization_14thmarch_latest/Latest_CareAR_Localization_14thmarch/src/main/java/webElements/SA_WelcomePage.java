package webElements;

import org.openqa.selenium.By;

public interface SA_WelcomePage {

	public static final By SA_logout=By.xpath("//button[@class='btn btn-outline-primary']");
	//public static final By SA_AddNewTenant= By.xpath("//i[@class='fa fa-plus fa-lg']");
	public static final By SA_AddNewTenant= By.xpath("//*[@class='add-user']/a");
	public static final By SA_FirstName=By.xpath("//*[@id='inputFirstName']");
	public static final By SA_LastName=By.xpath("//*[@id='inputLastName']");
	public static final By SA_EmailReg=By.xpath("//*[@id='inputEmail']");
	public static final By SA_CompanyName=By.xpath("//*[@id='inputCompanyName']");
	public static final By SA_PlanType=By.xpath("//label[contains(text(),'Plan Type')]//following::div/select");
	public static final By SA_TierLevel=By.xpath("//label[contains(text(),'Tier Level')]//following::div/select");
	public static final By SA_MaxSubs=By.xpath("//*[@id='inputMAxSubscribers']");
	public static final By SA_ExpirationDate=By.xpath("//label[contains(text(),'Expiration Date')]//following::div/select");
	public static final By SA_Create=By.xpath("//button[@type='submit']");
	public static final By SA_Cancel=By.xpath("//button[@class='btn btn-danger']");
	
	/*
	 * After creation first entry to be checked
	 */
	
	public static final By SA_FirstEntry=By.xpath("//div[@class='scroll-Table-container']/div/table/tbody/tr[1]");
	public static final By SA_CheckCompanyName=By.xpath("//div[@class='scroll-Table-container']/div/table/tbody/tr[1]/td[1]");
	public static final By SA_CheckTenantName=By.xpath("//div[@class='scroll-Table-container']/div/table/tbody/tr[1]/td[2]");
	
}
