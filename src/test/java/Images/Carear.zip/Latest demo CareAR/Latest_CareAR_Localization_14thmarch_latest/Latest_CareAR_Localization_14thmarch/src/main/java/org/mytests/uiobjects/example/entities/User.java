package org.mytests.uiobjects.example.entities;


import com.jdiai.tools.DataClass;

public class User extends DataClass<User> {
    public String name = "Roman";
    public String password = "Jdi1234";
}
