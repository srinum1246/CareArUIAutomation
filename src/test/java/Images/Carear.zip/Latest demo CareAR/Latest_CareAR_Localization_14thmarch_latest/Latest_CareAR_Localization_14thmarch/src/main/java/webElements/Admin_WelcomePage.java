package webElements;

import org.openqa.selenium.By;

public interface Admin_WelcomePage {

	
	public static final String navigate1="//ul[@class='nav']/li[";
	public static final String navigate2="]/span";
	
	public static final By waitElement= By.xpath("//div[@id='readOnly'][5]");
	public static final By languageChange=By.xpath("//button[@class='btn btn-outline-secondary lang-btn']");
	
	public static final By selectEnglish=By.xpath("//div[@class='language-list-group']/button[1]");
	public static final By selectFrench=By.xpath("//div[@class='language-list-group']/button[2]");
	public static final By selectGerman=By.xpath("//div[@class='language-list-group']/button[3]");
	public static final By selectItalian=By.xpath("//div[@class='language-list-group']/button[4]");
	public static final By selectPortugese=By.xpath("//div[@class='language-list-group']/button[5]");
	public static final By selectSpanish=By.xpath("//div[@class='language-list-group']/button[6]");
	
	public static final By selectIndonesian=By.xpath("//div[@class='language-list-group']/button[7]");
	public static final By selectJapanese=By.xpath("//div[@class='language-list-group']/button[8]");
	public static final By selectMalay=By.xpath("//div[@class='language-list-group']/button[9]");
	public static final By selectChinese=By.xpath("//div[@class='language-list-group']/button[10]");
	
	
	public static final By saveLanguage=By.xpath("//div[@class='modal-footer']/button[1]");
}
