package testCases;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import libraryFunctions.WebFunctions;
import webElements.LoginPage;
import webElements.SA_WelcomePage;
public class UserAddition  {

	static WebFunctions objweb=new WebFunctions();
	public static String email="JasonJack@gmail.com";

	//when need to do it, un-comment the below code
	/*
	 * public static void main(String args[]) throws Exception {
	 * System.setProperty("webdriver.chrome.driver",
	 * "C:\\Open Source Softwares\\chromedriver_win32\\chromedriver.exe"); WebDriver
	 * driver=new ChromeDriver(); createTenantAdmin(driver);
	 * //ChangePasswordTenant(driver); }
	 */
	public static void createTenantAdmin(WebDriver driver) throws Exception
	{
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get("https://carear-staging.web.app/#/super/login");  
		driver.manage().window().maximize();
		driver.findElement(LoginPage.SA_Email).sendKeys("super@carear.com");
		driver.findElement(LoginPage.SA_Password).sendKeys("Testing1");
		driver.findElement(LoginPage.SA_LoginButton).click();
		System.out.println("clicked on login button");
		objweb.explicitWait(driver, 10, "CLIckable", SA_WelcomePage.SA_AddNewTenant);
		Thread.sleep(5000);
		driver.findElement(SA_WelcomePage.SA_AddNewTenant).click();
		driver.findElement(SA_WelcomePage.SA_FirstName).sendKeys("Emily");
		driver.findElement(SA_WelcomePage.SA_LastName).sendKeys("Stuart");
		driver.findElement(SA_WelcomePage.SA_EmailReg).sendKeys(email);
		driver.findElement(SA_WelcomePage.SA_CompanyName).sendKeys("ThinkTank Inc.");
		
		Select s=new Select(driver.findElement(SA_WelcomePage.SA_PlanType));
		s.selectByValue("core");
		s=new Select(driver.findElement(SA_WelcomePage.SA_TierLevel));
		s.selectByValue("1000");
		/*
		 * s=new Select(driver.findElement(SA_WelcomePage.SA_ExpirationDate));
		 * s.selectByValue("6 Month");
		 */
		
		driver.findElement(SA_WelcomePage.SA_MaxSubs).sendKeys("10000");
		driver.findElement(SA_WelcomePage.SA_Create).click();
		
		WebDriverWait wait=new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(SA_WelcomePage.SA_logout));
		
		//validate the data from the previously fed input
		String CompanyName=driver.findElement(SA_WelcomePage.SA_CheckCompanyName).getText().trim();
		if(CompanyName.equals("ThinkTank Inc."))
			System.out.println("Company Name validated successfully");
		else
			System.out.println("Company Name validation failed");
		
		String tenantAdmin=driver.findElement(SA_WelcomePage.SA_CheckTenantName).getText().trim();
		if(tenantAdmin.equals("Emily Stuart"))
			System.out.println("Tenant Admin name validated successfully");
		else
			System.out.println("Tenant Admin name validation failed");
		
		  Thread.sleep(7000); 
		  //driver.findElement(SA_WelcomePage.SA_logout).click();
		 
		//driver.close();
			}
	
	public static void ChangePasswordTenant(WebDriver driver) {
		driver.get("https://carear-staging.web.app/#/admin/login");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.findElement(LoginPage.Ad_Email).sendKeys(email);
		driver.findElement(LoginPage.Ad_Password).sendKeys("Changeme!");
		driver.findElement(LoginPage.Ad_LoginButton).click();
		objweb.explicitWait(driver, 10, "Clickable", LoginPage.passwordOne_change);
		driver.findElement(LoginPage.passwordOne_change).sendKeys("Password1");
		driver.findElement(LoginPage.confirmPassword_change).sendKeys("Password1");
		driver.findElement(LoginPage.createPassword).click();
		
		
		
	}
	
}
