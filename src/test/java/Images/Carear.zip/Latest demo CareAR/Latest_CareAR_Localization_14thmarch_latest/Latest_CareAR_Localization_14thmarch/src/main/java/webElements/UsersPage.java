package webElements;

import org.openqa.selenium.By;

public interface UsersPage {

	public static final By clickUsers=By.cssSelector("div.sidebar ul.nav>li:nth-child(1)");   ////ul[@class='nav']/li[1]/span
	public static final By addNewUser=By.xpath("//div[@id='userInfo']/div/div/span/h4");
	public static final By addNewUserButton=By.xpath("//div[@id='userInfo']/div/div/span/span/a/i");
	public static final By exportAll=By.xpath("//div[@class='button-leftMargin']/button");
	public static final By importButton=By.xpath("//div[@class='button-leftMargin']/label");
	public static final By bulkEdit=By.xpath("(//div[@class='button-leftMargin']/label)[2]");
	//changed last th[11] to th[12]
	public static final By actionColumn=By.xpath("//table[@class='table table-responsive-sm table-hover mb-0 table table-hover']/thead/tr/th[13]");
	
	/*
	 * run from 3 to 11
	 */
	public static final String userTableHeader1="//*[@id=\"tableHeader\"]/div/table/thead/tr/th[";
	public static final String userTableHeader2 ="]/div";
	
	
	
	/*
	 * after clicking on add user button
	 */
	public static final By elementsOnAddUser=By.xpath("//form[@class='needs-validation novalidate label-minwidth-151']/div/div/div/label");
	//public static final By createButton=By.xpath("//form[@class='needs-validation novalidate label-minwidth-151']/div/div/div[7]/div[1]/button");
	//public static final By createButton=By.xpath("//form[@class='needs-validation novalidate label-minwidth-151']/div/div/div[8]/div[1]/button");
	//public static final By cancelButton=By.xpath("//form[@class='needs-validation novalidate label-minwidth-151']/div/div/div[7]/div[2]/button");
	//public static final By cancelButton=By.xpath("//form[@class='needs-validation novalidate label-minwidth-151']/div/div/div[8]/div[2]/button");
	public static final By cancelButton1=By.xpath("//form[@class='needs-validation was-validated novalidate label-minwidth-151']/div/div/div[8]/div[2]/button");
	
	//Changed td[11] to td[13]
	public static final By disableEnable=By.xpath("//*[@id='stickyHeaderTable']/div[2]/span/div/table/tbody/tr[1]/td[13]/div/span[1]/i");
	
	public static final By attention=By.xpath("//div[@class='modal-content']/div/h5");
	public static final By message=By.xpath("//div[@class='modal-content']/div[2]");
	public static final By confirm=By.xpath("//div[@class='modal-content']/div[3]/button[1]");
	public static final By cancel=By.xpath("//div[@class='modal-content']/div[3]/button[2]");
	
	//web elements added
	
	public static final By imgDelete=By.xpath("//*[@id='deleteUser_0']");
	public static final By users=By.xpath("(//*[@class='nav']/li)[1]");
	public static final By btnCancel=By.xpath("//*[@class='btn btn-secondary']");
	public static final By imgDisable=By.xpath("//*[@id='disableUser_0']");
	public static final By btnOk=By.xpath("//*[@class='btn btn-primary']");
	public static final By imgEnable=By.xpath("//*[@id='enableUser_0']");
	
	public static final By firstNameRequired=By.xpath("//*[@id='inputFirstName']//following-sibling::div");
	public static final By lastNameRequired=By.xpath("//*[@id='inputLastName']//following-sibling::div");
	public static final By emailRequired=By.xpath("//*[@id='inputEmail']//following-sibling::div");

	public static final By searchInput=By.cssSelector("input[placeholder='Search']");
	public static final By editUser=By.id("editUserLink_0");
	public static final By userRole=By.id("inputRole");
	public static final By updateUser=By.cssSelector("form button.btn-primary");
	public static final By userLogout=By.cssSelector("i.cui-account-logout");
	public static final By notificationMsg=By.xpath("//*[contains(@id,'dialogTitle')]");
	public static final By userDataRows=By.cssSelector("#userInfo table tbody>tr");
	public static final By userEmailTableCell = By.cssSelector("#userInfo table tbody tr:nth-child(1) >td:nth-child(4)");


	//
	public static final By overlay = By.cssSelector("div.block-ui-overlay");
	public static final By emailInput = By.id("inputEmail");
	public static final By firstNameInput = By.id("inputFirstName");
	public static final By lastNameInput = By.id("inputLastName");
	public static final By phoneNumberInput = By.id("inputPhoneNumber");
	public static final By secondaryNumberInput = By.id("inputSecondaryPhoneNumber");
	public static final By descriptionInput = By.id("inputDescription");
	public static final By groupInput = By.cssSelector("div.react-dropdown-select input");
	public static final By createButton = By.cssSelector("form.needs-validation button.btn-primary");
	public static final By cancelButton = By.cssSelector("form.needs-validation button.btn-danger");
	public static final By emailError = By.cssSelector("#inputEmail + div.invalid-feedback");
	public static final By alertTitle = By.cssSelector("div.modal-header");
	public static final By errorMsg = By.cssSelector("form.needs-validation div.invalid-feedback");
	public static final By closeNotification = By.cssSelector("div.close-toastr");
	public static final By alertOkButton = By.cssSelector("div.modal-dialog button.btn-primary");
	public static final By alertMessage = By.cssSelector("div.modal-body");
	public static final By searchUserInput = By.cssSelector("form.add-user input");
}
