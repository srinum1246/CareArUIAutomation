package webElements;

import org.openqa.selenium.By;

public interface MyProfilePage {

	
	public static final By myprofileLink = By.cssSelector("div.sidebar ul.nav>li:nth-child(7)");
	// from 1 to 4
	public static final String myProfileNav1="//div[@class='profileDetailsContainer2 row']/div/div/div/div["; 
    public static final String myProfileNav2="]/span/strong";
    public static final String myProfileNav3="//div[@class='profileDetailsContainer2 row']/div/div/div/div[";
    public static final String myProfileNav4="]/div"; 
    
    
    public static final By saveButton=By.xpath("//div[@class='profileDetailsContainer2 row']/div/div/div/div[6]/button");
    //public static final By saveButton=By.xpath("//div[@class='profileDetailsContainer2 row']/div/div/div/div[4]/div/button");
    
       public static final By versionButton=By.xpath("//ul[@class='ml-auto navbar-nav']/li/div/div/div/div");
   public static final By userPortal=By.xpath("//ul[@class='ml-auto navbar-nav']/li[2]/button");
   public static final By logout=By.xpath("//ul[@class='ml-auto navbar-nav']/li[4]/button");
   public static final By Userlogout=By.xpath("//*[@class='btn btn-outline-primary']");
   
   public static final By chooseFile=By.xpath("//label[@for='logoUploaderRef']");
   public static final By noFileChosen=By.xpath("//div[@class='logoUploadButtonContainer']/span");
   public static final By upload=By.xpath("//div[@class='logoUploadButtonContainer']/button");

    public static final By primaryPhoneNumber=By.xpath("(//*[@id='inputPhoneNumber'])[1]");
    public static final By secondaryPhoneNumber=By.xpath("(//*[@id='inputPhoneNumber'])[2]");

    public static final By userEmailID = By.cssSelector("#personalProfile div[title='Email'] + div");
    public static final By userInfoLabels = By.cssSelector("#personalProfile .row>div[title]:nth-child(1)");

   
}
